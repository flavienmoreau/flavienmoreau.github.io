%% Computes model moments for both competitive and collusion models

%% ============================================================
%  Detect Model Type
%  ============================================================
is_collusion = exist('cartel', 'var') && any(cartel(:) > 0);

if is_collusion
    fprintf('\nComputing moments for COLLUSION model...\n');
else
    fprintf('\nComputing moments for COMPETITIVE model...\n');
end

%% ============================================================
%  Block #1: Aggregate Markup
%  ============================================================
Block1 = muagg;

%% ============================================================
%  Block #2: Median Number of Cartel Members (Collusion only)
%  ============================================================
if is_collusion
    median_members = median(n_c(n_c > 0));
    Block2 = median_members;
else
    Block2 = 0;  % Not applicable for competitive model
end

%% ============================================================
%  Block #3: Median Number of Firms per Sector
%  ============================================================
median_number_firms = sum(phi, 'omitnan');
median_number_firms = median(median_number_firms(median_number_firms > 0), 'omitnan');
Block3 = median_number_firms;

%% ============================================================
%  Block #4: Concentration Ratios Within Industries (CR4, CR20)
%  ============================================================
if is_collusion
    sales = p_i_cartel .* yy_cartel .* phi;
else
    sales = p_i .* yy .* phi;
end

total_sales = sum(sales, 'omitnan');
m_share = sales ./ repmat(total_sales, N, 1);

% Top 4 and Top 20 concentration ratios
concentration_ratio4 = sum(m_share(1:4, :), 1, 'omitnan');
concentration_ratio4(concentration_ratio4 == 0) = NaN;

concentration_ratio20 = sum(m_share(1:20, :), 1, 'omitnan');
concentration_ratio20(concentration_ratio20 == 0) = NaN;

% Weight by sales share (Domar weights)
total_sales_economy = sum(total_sales, 'omitnan') * ones(1, S);
industry_domar_weights = total_sales ./ total_sales_economy;
industry_domar_weights(industry_domar_weights == 0) = NaN;

concentration_ratio4_product = concentration_ratio4 .* industry_domar_weights;
concentration_ratio4_final = sum(concentration_ratio4_product, 'omitnan');

concentration_ratio20_product = concentration_ratio20 .* industry_domar_weights;
concentration_ratio20_final = sum(concentration_ratio20_product, 'omitnan');

Block4 = [concentration_ratio4_final, concentration_ratio20_final];

%% ============================================================
%  Block #5: Concentration Ratios Across Sectors (CR4, CR20)
%  ============================================================
industry_domar_weights_cr_sectors = industry_domar_weights';
industry_domar_weights_cr_sectors = sort(industry_domar_weights_cr_sectors, 1, 'descend');
industry_domar_weights_cr_sectors = industry_domar_weights_cr_sectors(~isnan(industry_domar_weights_cr_sectors));

cr4_across_sectors_final = sum(industry_domar_weights_cr_sectors(1:4, :), 1, 'omitnan');
cr20_across_sectors_final = sum(industry_domar_weights_cr_sectors(1:20, :), 1, 'omitnan');

Block5 = [cr4_across_sectors_final, cr20_across_sectors_final];

%% ============================================================
%  Block #6: Regression Slope Coefficients
%  ============================================================
if is_collusion
    % Collusion model: sum of own + total coefficients
    sum_ms_cartel = cartel .* market_share_imperfect_collusion;
    sum_ms_cartel = nansum(sum_ms_cartel);
    sum_ms_cartel = repmat(sum_ms_cartel, n_f, 1);
    sum_ms_cartel = sum_ms_cartel .* cartel;
    sum_ms_cartel(sum_ms_cartel == 0) = NaN;
    sum_ms_cartel = sum_ms_cartel(:);
    sum_ms_cartel = sum_ms_cartel(all(~isnan(sum_ms_cartel), 2), :);
    
    tempX = cartel(:);
    tempX(tempX == 0) = NaN;
    market_share_economy_cartel = market_share_imperfect_collusion(:);
    market_share_economy_cartel = market_share_economy_cartel .* tempX;
    market_share_economy_cartel = market_share_economy_cartel(all(~isnan(market_share_economy_cartel), 2), :);
    
    temp_intercept_cartel = ones(size(market_share_economy_cartel(:, 1)));
    tempX_final_cartel = [temp_intercept_cartel market_share_economy_cartel sum_ms_cartel];
    
    tempY_ = cartel .* mu_cartel;
    tempY_(tempY_ == 0) = NaN;
    tempY_ = tempY_(:);
    tempY_ = tempY_(all(~isnan(tempY_), 2), :);
    tempY_ = 1 ./ tempY_;
    
    temp_beta_cartel = inv(tempX_final_cartel' * tempX_final_cartel) * tempX_final_cartel' * tempY_;
    
    slope_own_cartel = temp_beta_cartel(2);
    slope_total_cartel = temp_beta_cartel(3);
    sum_coefficients_cartel = slope_own_cartel + slope_total_cartel;
    
    Block6 = sum_coefficients_cartel;
    
else
    % Competitive model: only own slope
    market_share_economy = omega(:);
    market_share_economy = market_share_economy(all(~isnan(market_share_economy), 2), :);
    
    temp_intercept_ = ones(size(market_share_economy(:, 1)));
    tempX_final_ = [temp_intercept_ market_share_economy];
    
    tempY_ = mu_no_cartel;
    tempY_ = tempY_(:);
    tempY_ = tempY_(all(~isnan(tempY_), 2), :);
    tempY_ = 1 ./ tempY_;
    
    temp_beta_ = inv(tempX_final_' * tempX_final_) * tempX_final_' * tempY_;
    
    slope_own = temp_beta_(2);
    Block6 = slope_own;
end

%% ============================================================
%  Block #7: Cartel Overcharge (Collusion only)
%  ============================================================
if is_collusion
    cartel_moment = cartel;
    cartel_moment(cartel_moment == 0) = NaN;
    
    overcharge_sample = cartel_moment.*markup_increase;
    overcharge_sample = overcharge_sample(:);
    overcharge_sample = overcharge_sample(all(~isnan(overcharge_sample),2),:); % Remove NAN rows
    mean_overcharge_sample = mean(overcharge_sample);

    Block7 = mean_overcharge_sample;
else
    Block7 = 0;  % Not applicable for competitive model
end

%% ============================================================
%  Compile and Display Results
%  ============================================================
Block1 = round(Block1, 3);
Block2 = round(Block2, 3);
Block3 = round(Block3, 0);
Block4 = round(Block4, 2);
Block5 = round(Block5, 2);
Block6 = round(Block6, 2);
Block7 = round(Block7, 2);

% Load data moments
load data_moments_baseline.mat;

if is_collusion
    % Collusion model: all moments
    all_model_moments = [Block1 Block6 Block4 Block5 Block3 Block2]';
    
    fprintf('\n');
    fprintf('========================================\n');
    fprintf('Table 4: Baseline Calibration (Targets)\n');
    fprintf('========================================\n\n');
    
    MomName = {'Aggregate Markup'; 'Slope'; 'CR4 within'; 'CR20 within';...
               'CR4 across'; 'CR20 across';'Median Nbr. Firms Sector';'Median Nbr. Members Cartel'};
    Model = [all_model_moments(1); all_model_moments(2); all_model_moments(3); ...
             all_model_moments(4); all_model_moments(5); all_model_moments(6); ...
             all_model_moments(7); all_model_moments(8)];
    Targets = [all_data_moments(1); all_data_moments(2); all_data_moments(3); ...
               all_data_moments(4); all_data_moments(5); all_data_moments(6); ...
               all_data_moments(7); all_data_moments(8)];
    
else
    % Competitive model: subset of moments
    all_model_moments = [Block1 Block6 Block4 Block5 Block3 Block2]';
    
    fprintf('\n');
    fprintf('========================================\n');
    fprintf('Table 4: Baseline Calibration (Targets)\n');
    fprintf('========================================\n\n');

    MomName = {'Aggregate Markup'; 'Slope'; 'CR4 within'; 'CR20 within';...
               'CR4 across'; 'CR20 across';'Median Nbr. Firms Sector';'Median Nbr. Members Cartel'};
    Model = [all_model_moments(1); all_model_moments(2); all_model_moments(3); ...
            all_model_moments(4); all_model_moments(5); all_model_moments(6); ...
            all_model_moments(7); all_model_moments(8)];
    Targets = [all_data_moments(1); all_data_moments(2); all_data_moments(3); ...
               all_data_moments(4); all_data_moments(5); all_data_moments(6); ...
               all_data_moments(7); all_data_moments(8)];
end

% Display results table
T = table(Targets, Model, 'RowNames', MomName);
disp(T);

%% ============================================================
%  Display Parameter Table
%  ============================================================
fprintf('\n');
fprintf('========================================\n');
fprintf('Table 4: Baseline Calibration (Parameters)\n');
fprintf('========================================\n\n');

ParamName = {'Substitution within sectors (rho)'; 
             'Substitution between sectors (eta)'; 
             'Pareto shape, firms (xi)'; 
             'Pareto shape, sectors (xi_s)'; 
             'Geometric, firms (zeta_f)'; 
             'Geometric, cartel members (zeta)'; 
             'Collusion intensity (beta)'; 
             'Inverse Frisch elasticity (nu)'};

if strcmp(model_type, 'collusion')
    ParamValue = [round(rho, 2); round(eta, 2); round(xi, 2); round(xi_s, 2); 
                  round(zeta_f, 3); round(zeta, 2); round(beta, 2); round(nu, 2)];
else
    ParamValue = [round(rho, 2); round(eta, 2); round(xi, 2); round(xi_s, 2); 
                  round(zeta_f, 3); NaN; round(beta, 2); round(nu, 2)];
end

T_params = table(ParamValue, 'RowNames', ParamName);
disp(T_params);


%% ============================================================
%  Untargeted Moments (Collusion Model Only)
%  ============================================================
if is_collusion
    fprintf('\n');
    fprintf('========================================\n');
    fprintf('Table 5: Untargeted Moments\n');
    fprintf('========================================\n\n');
    
    % Compute cartel premia within cartelized industries
    cartel_id = phi .* cartel;
    
    Y_variables = {log(p_i_cartel .* yy_cartel .* phi), log(ll .* phi), ...
                   log(yy_cartel ./ ll), (market_share_imperfect_collusion * 100) .* phi};
    
    variable_names = {'Sales', 'Employment', 'TFPL', 'Market Share'};
    cartel_premiums_all = cell(size(Y_variables));
    
    for v = 1:length(Y_variables)
        cartel_premiums = [];
        
        for s = 1:S
            if collusive_ind_final(s, 1) == 1
                Y_dep = Y_variables{v}(:, s);
                X = [phi(:, s), cartel_id(:, s)];
                
                non_nan_rows_Y = ~isnan(Y_dep);
                non_nan_rows_X = ~any(isnan(X), 2);
                
                Y_dep = Y_dep(non_nan_rows_Y);
                X = X(non_nan_rows_X, :);
                
                [common_rows_Y, common_rows_X] = intersect(find(non_nan_rows_Y), find(non_nan_rows_X));
                Y_dep = Y_dep(common_rows_Y);
                X = X(common_rows_X, :);
                
                beta_reg = inv(X' * X) * X' * Y_dep;
                cartel_premium_ = beta_reg(2);
                cartel_premiums = [cartel_premiums, cartel_premium_];
            end
        end
        
        cartel_premiums(isinf(cartel_premiums)) = NaN;
        cartel_premiums_all{v} = cartel_premiums;
    end
    
    mean_cartel_premiums = cellfun(@nanmean, cartel_premiums_all, 'UniformOutput', false);
    
    % Standard deviations
    sales = p_i_cartel .* yy_cartel .* phi;
    tempY_sales = log(sales(:));
    tempY_sales = tempY_sales(all(~isnan(tempY_sales), 2), :);
    
    tempY_employment = log(ll .* phi);
    tempY_employment = tempY_employment(:);
    tempY_employment = tempY_employment(all(~isnan(tempY_employment), 2), :);
    
    % Cross-sectoral regression
    temp_ = ones(1, S);
    tempX_industry = [temp_' collusive_ind];
    tempY_domar_industry = industry_domar_weights' * 100;
    coef_reg = inv(tempX_industry' * tempX_industry) * tempX_industry' * tempY_domar_industry;
    
    % Display untargeted moments table
    UntargetedMoments = {'Cartelized industry slope'; 'Average cartel premium (sales)'; ...
                         'Average cartel premium (employment)'; 'Average cartel premium (labor productivity)'; ...
                         'Average cartel premium (market share)'; 'Standard deviation of log sales'; ...
                         'Standard deviation of log employment'; 'Average overcharge (in %)'};
    
    % Load untargeted data moments
    load data_untargeted_moments.mat;
    
    % Round model values
    coef_reg_rounded = round(coef_reg(2), 2);
    cartel_premium_sales = round(mean_cartel_premiums{1}, 2);
    cartel_premium_employment = round(mean_cartel_premiums{2}, 2);
    cartel_premium_tfpl = round(mean_cartel_premiums{3}, 2);
    cartel_premium_market_share = round(mean_cartel_premiums{4}, 2);
    std_sales_rounded = round(std(tempY_sales), 2);
    std_employment_rounded = round(std(tempY_employment), 2);
    mean_overcharge_rounded = round(mean_overcharge_sample, 2);
    
    % Display untargeted moments table
    UntargetedMoments = {'Cartelized industry slope'; 'Average cartel premium (sales)'; ...
                         'Average cartel premium (employment)'; 'Average cartel premium (labor productivity)'; ...
                         'Average cartel premium (market share)'; 'Standard deviation of log sales'; ...
                         'Standard deviation of log employment'; 'Average overcharge (in %)'};
    
    Data_Values = all_data_untargeted_moments;  % Assumes the .mat file contains this variable
    Model_Values = [coef_reg_rounded; cartel_premium_sales; cartel_premium_employment; ...
                    cartel_premium_tfpl; cartel_premium_market_share; std_sales_rounded; ...
                    std_employment_rounded; mean_overcharge_rounded];
    
    T_untargeted = table(Data_Values, Model_Values, 'RowNames', UntargetedMoments);
    disp(T_untargeted);
               
    fprintf('\n');
end