%% AEJ Macro Replication Package (Moreau and Panon, forthcoming)
% This script reproduces 
% 1) Table 4: Baseline Calibration (with all three columns: Data, Collusion, Competitive)
% 2) Table 5: Untargeted Moments 
% 3) Table 6: Aggregate Gains from Breaking Down Cartels

% Modified version: Automatically runs both 'collusion' and 'competitive' models
% and produces consolidated tables as in the paper

tic
clear;
clc;
diary tables_4_5_6.txt
rng('default');  % For reproducibility

%% ============================================================
%  Initialize storage for results from both models
%  ============================================================
results_collusion = struct();
results_competitive = struct();

%% ============================================================
%  Run both models sequentially
%  ============================================================
model_types = {'collusion', 'competitive'};

for model_idx = 1:length(model_types)
    model_type = model_types{model_idx};
    
    % Reset random number generator for each model to ensure reproducibility
    % (each model should use the same random draws as when run independently)
    rng('default');
    
    %% ============================================================
    %  Model Parameters
    %  ============================================================
    n_f = 500;                  % Max number of firms within each sector
    S = 670;                    % Number of sectors
    L = 1;                      % Inelastic labor supply
    nu = 2;                     % Inverse Frisch elasticity of labor supply
    
    % Set parameters based on model type
    if strcmp(model_type, 'collusion')
        fprintf('\n========================================\n');
        fprintf('Running COLLUSION Model (Table 6, Column 1)\n');
        fprintf('========================================\n\n');
        
        rho = 12.0564816759752;         % Within-sector elasticity of substitution
        eta = 3.10040889831152;         % Between-sector elasticity of substitution
        xi = 10.2378007453196;          % Firm productivity Pareto shape parameter
        xi_s = 2.80881084697840;        % Sector productivity Pareto shape parameter
        zeta = 0.161187916362012;       % Cartel size parameter (geometric distribution)
        zeta_f = 0.00407313218542430;   % Number of firms parameter (geometric distribution)
        beta = 0.41;                    % Collusion intensity
        share_cartels = 90;             % Share of cartelized industries
        
    elseif strcmp(model_type, 'competitive')
        fprintf('\n========================================\n');
        fprintf('Running COMPETITIVE Model (Table 6, Column 2)\n');
        fprintf('========================================\n\n');
        
        rho = 11.0933175447545;
        eta = 3.03200703759676;
        xi = 9.84760898962594;
        xi_s = 2.79025748652605;
        zeta_f = 0.00435454961956673;
        zeta = NaN;                     % Not applicable for competitive model
        beta = 0.0;                     % No collusion
        share_cartels = 0;              % No cartelized industries
        
    else
        error('Invalid model_type. Must be either ''competitive'' or ''collusion''');
    end
    
    %% ============================================================
    %  Generate Productivity Distribution
    %  ============================================================
    N = n_f;
    M = S;
    alpha = xi;
    b = 1;
    
    % Firm-level productivity draws
    P = randp(N, M, alpha, b);
    z = sort(P, 'descend');
    
    % Sectoral productivity draws
    M_s = S;
    alpha_s = xi_s;
    P_s = randp(1, M_s, alpha_s, b);
    z_s = P_s;
    
    % Combined productivity: firm � sector
    z = bsxfun(@times, z, z_s);
    
    %% ============================================================
    %  Generate Firm Distribution Across Sectors
    %  ============================================================
    nn = geornd(zeta_f, S, 1);      % Number of firms per sector
    nn(nn == 0) = 178;              % Replace 0s with median
    nn(nn > n_f) = n_f;             % Cap at maximum
    
    if strcmp(model_type, 'collusion')
        nn(nn == 1) = 2;            % Minimum of 2 firms for potential collusion
    end
    
    % Create firm activity matrix
    phi = zeros(N, S);
    for i = 1:S
        temp = zeros(N, 1);
        temp(1:nn(i)) = 1;
        temp = temp(randperm(N));
        phi(:, i) = temp;
    end
    
    phi = sort(phi, 1, 'descend');
    z = z .* phi + eps .* (1 - phi);
    z = sort(z, 1, 'descend');
    phi(phi == 0) = NaN;
    
    %% ============================================================
    %  Generate Cartel Structure (if collusion model)
    %  ============================================================
    if strcmp(model_type, 'collusion')
        % Identify cartelized industries (top X%)
        treated_ind_threshold = prctile(z_s, share_cartels);
        treated_ind_top = z_s >= treated_ind_threshold;
        collusive_ind = double(treated_ind_top');
        
        % Determine number of cartel members per industry
        n_c = zeros(S, 1);
        for s = 1:S
            if collusive_ind(s, 1) == 1
                n_c(s) = geornd(zeta, 1, 1);
            end
        end
        
        n_c((n_c == 0) & (collusive_ind == 1)) = 4;  % Median cartel size
        n_c(n_c == 1) = 2;                            % Minimum 2 members
        
        % Ensure cartel size doesn't exceed number of firms
        dummy = n_c > nn;
        n_c(dummy) = nn(dummy);
        
        collusive_ind_final = n_c > 0;
        
        % Create cartel membership matrix
        cartel = zeros(n_f, S);
        for i = 1:S
            cartel_temp = ones(n_c(i, 1), 1);
            cartel_temp(n_f, 1) = 0;
            cartel(:, i) = cartel_temp;
        end
        
    else
        % No cartels in competitive model
        n_c = zeros(S, 1);
        cartel = zeros(n_f, S);
        collusive_ind_final = zeros(S, 1);
        collusive_ind = zeros(S, 1);
    end
    
    %% ============================================================
    %  Compute Benchmark Equilibrium (No Cartels)
    %  ============================================================
    fprintf('\n');
    display('Computing Benchmark Equilibrium (No Cartels)')
    fprintf('\n');
    
    equilibrium_benchmark;
    
    mu_no_cartel = mu;
    p_i_no_cartel = p_i;
    p_s_no_cartel = p_s;
    A_no_cartel = A;
    muagg_no_cartel = muagg;
    omega_no_cartel = omega;
    
    save no_cartel mu_no_cartel p_i_no_cartel p_s_no_cartel A_no_cartel muagg_no_cartel omega_no_cartel profit_no_cartel
    
    % Efficient allocation benchmark
    A_s_eff = nanmean(z.^(rho-1)).^(1/(rho-1));
    A_eff = nanmean(A_s_eff.^(eta-1)).^(1/(eta-1));
    
    %% ============================================================
    %  Compute Collusion Equilibrium (if applicable)
    %  ============================================================
    if strcmp(model_type, 'collusion')
        fprintf('\n');
        display('Computing Equilibrium with Cartels')
        fprintf('\n');
        
        equilibrium_imperfect_collusion;
        
        mu_cartel = mu;
        p_i_cartel = p_i;
        A_cartel = A;
        p_s_cartel = p_s;
        yy_cartel = yy;
        clear mu p_i A p_s
        
        load no_cartel
        delete no_cartel.mat
        
        % Compute welfare metrics
        A_loss_cartel = (A_cartel / A_no_cartel - 1) * 100;
        A_loss_efficient = (A_cartel / A_eff - 1) * 100;
        distance_to_efficient = (A_loss_cartel / A_loss_efficient) * 100;
    
        welfare_static = ((A_cartel / A_no_cartel) .* (muagg / muagg_no_cartel).^(-1/(1+nu)) - 1) .* 100;
        welfare_efficient = ((A_cartel / A_eff) .* (muagg).^(-1/(1+nu)) - 1) .* 100;
        
        markup_increase = ((mu_cartel ./ mu_no_cartel) - 1) * 100;
        check_shares = sum(market_share_imperfect_collusion, 'omitnan');
        check_shares(check_shares == 0) = NaN;
        
        %% ============================================================
        %  Compute Moments for Collusion Model (inline)
        %  ============================================================
        warning('off', 'MATLAB:singularMatrix');
        
        % Block #1: Aggregate Markup
        Block1 = muagg;
        
        % Block #2: Median Number of Cartel Members
        median_members = median(n_c(n_c > 0));
        Block2 = median_members;
        
        % Block #3: Median Number of Firms per Sector
        median_number_firms = sum(phi, 'omitnan');
        median_number_firms = median(median_number_firms(median_number_firms > 0), 'omitnan');
        Block3 = median_number_firms;
        
        % Block #4: Concentration Ratios Within Industries (CR4, CR20)
        sales = p_i_cartel .* yy_cartel .* phi;
        total_sales = sum(sales, 'omitnan');
        m_share = sales ./ repmat(total_sales, N, 1);
        
        concentration_ratio4 = sum(m_share(1:4, :), 1, 'omitnan');
        concentration_ratio4(concentration_ratio4 == 0) = NaN;
        
        concentration_ratio20 = sum(m_share(1:20, :), 1, 'omitnan');
        concentration_ratio20(concentration_ratio20 == 0) = NaN;
        
        total_sales_economy = sum(total_sales, 'omitnan') * ones(1, S);
        industry_domar_weights = total_sales ./ total_sales_economy;
        industry_domar_weights(industry_domar_weights == 0) = NaN;
        
        concentration_ratio4_product = concentration_ratio4 .* industry_domar_weights;
        concentration_ratio4_final = sum(concentration_ratio4_product, 'omitnan');
        
        concentration_ratio20_product = concentration_ratio20 .* industry_domar_weights;
        concentration_ratio20_final = sum(concentration_ratio20_product, 'omitnan');
        
        Block4 = [concentration_ratio4_final, concentration_ratio20_final];
        
        % Block #5: Concentration Ratios Across Sectors (CR4, CR20)
        industry_domar_weights_cr_sectors = industry_domar_weights';
        industry_domar_weights_cr_sectors = sort(industry_domar_weights_cr_sectors, 1, 'descend');
        industry_domar_weights_cr_sectors = industry_domar_weights_cr_sectors(~isnan(industry_domar_weights_cr_sectors));
        
        cr4_across_sectors_final = sum(industry_domar_weights_cr_sectors(1:4, :), 1, 'omitnan');
        cr20_across_sectors_final = sum(industry_domar_weights_cr_sectors(1:20, :), 1, 'omitnan');
        
        Block5 = [cr4_across_sectors_final, cr20_across_sectors_final];
        
        % Block #6: Regression Slope Coefficients (Collusion)
        sum_ms_cartel = cartel .* market_share_imperfect_collusion;
        sum_ms_cartel = nansum(sum_ms_cartel);
        sum_ms_cartel = repmat(sum_ms_cartel, n_f, 1);
        sum_ms_cartel = sum_ms_cartel .* cartel;
        sum_ms_cartel(sum_ms_cartel == 0) = NaN;
        sum_ms_cartel = sum_ms_cartel(:);
        sum_ms_cartel = sum_ms_cartel(all(~isnan(sum_ms_cartel), 2), :);
        
        tempX = cartel(:);
        tempX(tempX == 0) = NaN;
        market_share_economy_cartel = market_share_imperfect_collusion(:);
        market_share_economy_cartel = market_share_economy_cartel .* tempX;
        market_share_economy_cartel = market_share_economy_cartel(all(~isnan(market_share_economy_cartel), 2), :);
        
        temp_intercept_cartel = ones(size(market_share_economy_cartel(:, 1)));
        tempX_final_cartel = [temp_intercept_cartel market_share_economy_cartel sum_ms_cartel];
        
        tempY_ = cartel .* mu_cartel;
        tempY_(tempY_ == 0) = NaN;
        tempY_ = tempY_(:);
        tempY_ = tempY_(all(~isnan(tempY_), 2), :);
        tempY_ = 1 ./ tempY_;
        
        temp_beta_cartel = inv(tempX_final_cartel' * tempX_final_cartel) * tempX_final_cartel' * tempY_;
        
        slope_own_cartel = temp_beta_cartel(2);
        slope_total_cartel = temp_beta_cartel(3);
        sum_coefficients_cartel = slope_own_cartel + slope_total_cartel;
        
        Block6 = sum_coefficients_cartel;
        
        % Block #7: Cartel Overcharge
        cartel_moment = cartel;
        cartel_moment(cartel_moment == 0) = NaN;
        
        overcharge_sample = cartel_moment .* markup_increase;
        overcharge_sample = overcharge_sample(:);
        overcharge_sample = overcharge_sample(all(~isnan(overcharge_sample), 2), :);
        mean_overcharge_sample = mean(overcharge_sample);
        
        Block7 = mean_overcharge_sample;
        
        % Round and compile moments
        Block1 = round(Block1, 3);
        Block2 = round(Block2, 3);
        Block3 = round(Block3, 0);
        Block4 = round(Block4, 2);
        Block5 = round(Block5, 2);
        Block6 = round(Block6, 2);
        Block7 = round(Block7, 2);
        
        moments_collusion = [Block1; Block6; Block4(1); Block4(2); Block5(1); Block5(2); Block3; Block2];
        
        % Parameters for collusion model
        params_collusion = [round(rho, 2); round(eta, 2); round(xi, 2); round(xi_s, 2); 
                           round(zeta_f, 3); round(zeta, 2); round(beta, 2); round(nu, 2)];
        
        %% Untargeted Moments (Collusion only)
        cartel_id = phi .* cartel;
        
        Y_variables = {log(p_i_cartel .* yy_cartel .* phi), log(ll .* phi), ...
                       log(yy_cartel ./ ll), (market_share_imperfect_collusion * 100) .* phi};
        
        cartel_premiums_all = cell(size(Y_variables));
        
        for v = 1:length(Y_variables)
            cartel_premiums = [];
            
            for s = 1:S
                if collusive_ind_final(s, 1) == 1
                    Y_dep = Y_variables{v}(:, s);
                    X = [phi(:, s), cartel_id(:, s)];
                    
                    non_nan_rows_Y = ~isnan(Y_dep);
                    non_nan_rows_X = ~any(isnan(X), 2);
                    
                    Y_dep = Y_dep(non_nan_rows_Y);
                    X = X(non_nan_rows_X, :);
                    
                    [common_rows_Y, common_rows_X] = intersect(find(non_nan_rows_Y), find(non_nan_rows_X));
                    Y_dep = Y_dep(common_rows_Y);
                    X = X(common_rows_X, :);
                    
                    beta_reg = inv(X' * X) * X' * Y_dep;
                    cartel_premium_ = beta_reg(2);
                    cartel_premiums = [cartel_premiums, cartel_premium_];
                end
            end
            
            cartel_premiums(isinf(cartel_premiums)) = NaN;
            cartel_premiums_all{v} = cartel_premiums;
        end
        
        mean_cartel_premiums = cellfun(@nanmean, cartel_premiums_all, 'UniformOutput', false);
        
        % Standard deviations
        tempY_sales = log(sales(:));
        tempY_sales = tempY_sales(all(~isnan(tempY_sales), 2), :);
        
        tempY_employment = log(ll .* phi);
        tempY_employment = tempY_employment(:);
        tempY_employment = tempY_employment(all(~isnan(tempY_employment), 2), :);
        
        % Cross-sectoral regression
        temp_ = ones(1, S);
        tempX_industry = [temp_' collusive_ind];
        tempY_domar_industry = industry_domar_weights' * 100;
        coef_reg = inv(tempX_industry' * tempX_industry) * tempX_industry' * tempY_domar_industry;
        
        untargeted_collusion = [round(coef_reg(2), 2); 
                                round(mean_cartel_premiums{1}, 2); 
                                round(mean_cartel_premiums{2}, 2);
                                round(mean_cartel_premiums{3}, 2); 
                                round(mean_cartel_premiums{4}, 2); 
                                round(std(tempY_sales), 2);
                                round(std(tempY_employment), 2); 
                                round(mean_overcharge_sample, 2)];
        
        % Store results
        results_collusion.moments = moments_collusion;
        results_collusion.params = params_collusion;
        results_collusion.untargeted = untargeted_collusion;
        results_collusion.A_loss_cartel = A_loss_cartel;
        results_collusion.A_loss_efficient = A_loss_efficient;
        results_collusion.distance_to_efficient = distance_to_efficient;
        results_collusion.muagg = muagg;
        results_collusion.muagg_no_cartel = muagg_no_cartel;
        results_collusion.welfare_static = welfare_static;
        results_collusion.welfare_efficient = welfare_efficient;
        results_collusion.check_shares = check_shares;
        results_collusion.collusive_ind_final = collusive_ind_final;
        results_collusion.S = S;
        
    else  % Competitive model
        A_loss_efficient = (A_no_cartel / A_eff - 1) * 100;
        welfare_efficient = ((A_no_cartel / A_eff) .* (muagg).^(-1/(1+nu)) - 1) .* 100;
        
        %% ============================================================
        %  Compute Moments for Competitive Model (inline)
        %  ============================================================
        warning('off', 'MATLAB:singularMatrix');
        
        % Block #1: Aggregate Markup
        Block1 = muagg;
        
        % Block #2: Median Number of Cartel Members (not applicable)
        Block2 = 0;
        
        % Block #3: Median Number of Firms per Sector
        median_number_firms = sum(phi, 'omitnan');
        median_number_firms = median(median_number_firms(median_number_firms > 0), 'omitnan');
        Block3 = median_number_firms;
        
        % Block #4: Concentration Ratios Within Industries (CR4, CR20)
        sales = p_i .* yy .* phi;
        total_sales = sum(sales, 'omitnan');
        m_share = sales ./ repmat(total_sales, N, 1);
        
        concentration_ratio4 = sum(m_share(1:4, :), 1, 'omitnan');
        concentration_ratio4(concentration_ratio4 == 0) = NaN;
        
        concentration_ratio20 = sum(m_share(1:20, :), 1, 'omitnan');
        concentration_ratio20(concentration_ratio20 == 0) = NaN;
        
        total_sales_economy = sum(total_sales, 'omitnan') * ones(1, S);
        industry_domar_weights = total_sales ./ total_sales_economy;
        industry_domar_weights(industry_domar_weights == 0) = NaN;
        
        concentration_ratio4_product = concentration_ratio4 .* industry_domar_weights;
        concentration_ratio4_final = sum(concentration_ratio4_product, 'omitnan');
        
        concentration_ratio20_product = concentration_ratio20 .* industry_domar_weights;
        concentration_ratio20_final = sum(concentration_ratio20_product, 'omitnan');
        
        Block4 = [concentration_ratio4_final, concentration_ratio20_final];
        
        % Block #5: Concentration Ratios Across Sectors (CR4, CR20)
        industry_domar_weights_cr_sectors = industry_domar_weights';
        industry_domar_weights_cr_sectors = sort(industry_domar_weights_cr_sectors, 1, 'descend');
        industry_domar_weights_cr_sectors = industry_domar_weights_cr_sectors(~isnan(industry_domar_weights_cr_sectors));
        
        cr4_across_sectors_final = sum(industry_domar_weights_cr_sectors(1:4, :), 1, 'omitnan');
        cr20_across_sectors_final = sum(industry_domar_weights_cr_sectors(1:20, :), 1, 'omitnan');
        
        Block5 = [cr4_across_sectors_final, cr20_across_sectors_final];
        
        % Block #6: Regression Slope Coefficients (Competitive)
        market_share_economy = omega(:);
        market_share_economy = market_share_economy(all(~isnan(market_share_economy), 2), :);
        
        temp_intercept_ = ones(size(market_share_economy(:, 1)));
        tempX_final_ = [temp_intercept_ market_share_economy];
        
        tempY_ = mu_no_cartel;
        tempY_ = tempY_(:);
        tempY_ = tempY_(all(~isnan(tempY_), 2), :);
        tempY_ = 1 ./ tempY_;
        
        temp_beta_ = inv(tempX_final_' * tempX_final_) * tempX_final_' * tempY_;
        
        slope_own = temp_beta_(2);
        Block6 = slope_own;
        
        % Round and compile moments
        Block1 = round(Block1, 3);
        Block2 = round(Block2, 3);
        Block3 = round(Block3, 0);
        Block4 = round(Block4, 2);
        Block5 = round(Block5, 2);
        Block6 = round(Block6, 2);
        
        moments_competitive = [Block1; Block6; Block4(1); Block4(2); Block5(1); Block5(2); Block3; Block2];
        
        % Parameters for competitive model
        params_competitive = [round(rho, 2); round(eta, 2); round(xi, 2); round(xi_s, 2); 
                             round(zeta_f, 3); NaN; round(beta, 2); round(nu, 2)];
        
        % Store results
        results_competitive.moments = moments_competitive;
        results_competitive.params = params_competitive;
        results_competitive.A_loss_efficient = A_loss_efficient;
        results_competitive.welfare_efficient = welfare_efficient;
    end
end

%% ============================================================
%  Display Consolidated Table 4: Baseline Calibration
%  ============================================================
fprintf('\n');
fprintf('========================================\n');
fprintf('Table 4: Baseline Calibration (Panel A. Targets)\n');
fprintf('========================================\n\n');

% Load data moments
load data_moments_baseline.mat;

MomName = {'Aggregate Markup'; 'Slope'; 'CR4 within'; 'CR20 within';...
           'CR4 across'; 'CR20 across'; 'Median Nbr. Firms Sector'; 'Median Nbr. Members Cartel'};

Targets = all_data_moments;
Collusion = results_collusion.moments;
Competitive = results_competitive.moments;

T = table(Targets, Collusion, Competitive, 'RowNames', MomName);
disp(T);

%% ============================================================
%  Display Consolidated Table 4: Panel B (Parameters)
%  ============================================================
fprintf('\n');
fprintf('========================================\n');
fprintf('Table 4: Baseline Calibration (Panel B: Parameters)\n');
fprintf('========================================\n\n');

ParamName = {'Substitution within sectors (rho)'; 
             'Substitution between sectors (eta)'; 
             'Pareto shape, firms (xi)'; 
             'Pareto shape, sectors (xi_s)'; 
             'Geometric, firms (zeta_f)'; 
             'Geometric, cartel members (zeta)'; 
             'Collusion intensity (beta)'; 
             'Inverse Frisch elasticity (nu)'};

Collusion_Params = results_collusion.params;
Competitive_Params = results_competitive.params;

T_params = table(Collusion_Params, Competitive_Params, 'RowNames', ParamName);
disp(T_params);

%% ============================================================
%  Display Table 5: Untargeted Moments (Collusion Model Only)
%  ============================================================
fprintf('\n');
fprintf('========================================\n');
fprintf('Table 5: Untargeted Moments\n');
fprintf('========================================\n\n');

load data_untargeted_moments.mat;

UntargetedMoments = {'Cartelized industry slope'; 'Average cartel premium (sales)'; ...
                     'Average cartel premium (employment)'; 'Average cartel premium (labor productivity)'; ...
                     'Average cartel premium (market share)'; 'Standard deviation of log sales'; ...
                     'Standard deviation of log employment'; 'Average overcharge (in %)'};

Data_Values = all_data_untargeted_moments;
Model_Values = results_collusion.untargeted;

T_untargeted = table(Data_Values, Model_Values, 'RowNames', UntargetedMoments);
disp(T_untargeted);

%% ============================================================
%  Display Table 6: Aggregate Gains from Breaking Down Cartels
%  ============================================================
fprintf('\n');
fprintf('========================================\n');
fprintf('Table 6: Aggregate Gains from Breaking Down Cartels\n');
fprintf('========================================\n\n');

% Column 1: Collusion
fprintf('Column 1 - Collusion Model:\n');
fprintf('A gain (from no cartel), %%              = %7.2f \n', -results_collusion.A_loss_cartel);
fprintf('A gain (vs. efficient economy), %%       = %7.2f \n', -results_collusion.A_loss_efficient);
fprintf('A change distance (wrt efficient economy), *100   = %7.2f \n', -results_collusion.distance_to_efficient);
fprintf('Markup change, points                  = %7.2f \n', -(results_collusion.muagg - results_collusion.muagg_no_cartel) * 100);
fprintf('Static welfare gain (from cartels), %%   = %7.2f \n', -results_collusion.welfare_static);
fprintf('Static welfare gain (vs. efficient), %%  = %7.2f \n', -results_collusion.welfare_efficient);
fprintf('\n');

% Column 2: Competitive
fprintf('Column 2 - Competitive Model:\n');
fprintf('A gain (vs. efficient economy), %%       = %7.2f \n', -results_competitive.A_loss_efficient);
fprintf('Static welfare gain (vs. efficient), %%  = %7.2f \n', -results_competitive.welfare_efficient);
fprintf('========================================\n\n');

fprintf('Check on market shares                   = %7.3f \n', nanmean(results_collusion.check_shares));
fprintf('Share cartelized sectors                 = %7.3f \n', sum(results_collusion.collusive_ind_final) ./ results_collusion.S);
fprintf('..........................................\n');

diary off
toc;