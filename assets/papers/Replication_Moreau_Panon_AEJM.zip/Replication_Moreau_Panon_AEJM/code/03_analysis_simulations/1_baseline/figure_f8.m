%% AEJ Macro Replication Package (Moreau and Panon, forthcoming)
% This script reproduces Figure F8: Distribution of Cartel Profit Growth

% The figure shows:
%   Unreported figure: Distribution of individual profit growth for cartel members
%   Figure F8: Distribution of aggregate profit growth by cartel

% Required files:
%   - randp.m                          (Pareto random number generator)
%   - equilibrium_benchmark.m          (Competitive equilibrium solver)
%   - equilibrium_imperfect_collusion.m (Collusion equilibrium solver)

tic
clear;
clc;
rng('default');  % For reproducibility

%% ============================================================
%  Model Parameters
%  ============================================================
n_f = 500;                              % Max number of firms per sector
S = 670;                                % Number of sectors
L = 1;                                  % Inelastic labor supply
nu = 2;                                 % Inverse Frisch elasticity

rho = 12.0564816759752;                 % Within-sector elasticity of substitution
eta = 3.10040889831152;                 % Between-sector elasticity of substitution
xi = 10.2378007453196;                  % Firm productivity Pareto shape
xi_s = 2.80881084697840;                % Sector productivity Pareto shape
zeta = 0.161187916362012;               % Cartel size parameter (geometric)
zeta_f = 0.00407313218542430;           % Number of firms parameter (geometric)
beta = 0.41;                            % Collusion intensity
share_cartels = 90;                     % Share of cartelized industries (percentile)

%% ============================================================
%  Generate Productivity Distribution
%  ============================================================
fprintf('\n========================================\n');
fprintf('Generating Productivity Distribution\n');
fprintf('========================================\n\n');

N = n_f;
M = S;
alpha = xi;
b = 1;

% Firm-level productivity draws
P = randp(N, M, alpha, b);
y = b:max(P)/1000:max(P);
z = P;
z = sort(z, 'descend');

% Sectoral productivity draws
M_s = S;
alpha_s = xi_s;
P_s = randp(1, M_s, alpha_s, b);
z_s = P_s;
clear P_s;

% Combined productivity: firm � sector
z_final = bsxfun(@times, z, z_s);
clear z;
z = z_final;
clear z_final;

%% ============================================================
%  Generate Firm Distribution Across Sectors
%  ============================================================
nn = geornd(zeta_f, S, 1);
nn(nn == 0) = 178;          % Replace 0s with median
nn(nn > n_f) = n_f;         % Cap at maximum
nn(nn == 1) = 2;            % Minimum 2 firms (duopoly)

phi = zeros(N, S);
for i = 1:S
    temp = zeros(N, 1);
    temp(1:nn(i)) = 1;
    temp = temp(randperm(N));
    phi(:, i) = temp;
end

phi = sort(phi, 1, 'descend');
z = z .* phi + eps .* (1 - phi);
z = sort(z, 1, 'descend');
phi(phi == 0) = NaN;

%% ============================================================
%  Generate Cartel Structure
%  ============================================================
treated_ind_90 = prctile(z_s, share_cartels);
treated_ind_top10 = z_s >= treated_ind_90;
collusive_ind = double(treated_ind_top10');

n_c = zeros(S, 1);
for s = 1:S
    if collusive_ind(s, 1) == 1
        n_c(s) = geornd(zeta, 1, 1);
    end
end

n_c((n_c == 0) & (collusive_ind == 1)) = 4;  % Median cartel size
n_c(n_c == 1) = 2;                            % Minimum 2 members
dummy = n_c > nn;
n_c(dummy) = nn(dummy);
collusive_ind_final = n_c > 0;

cartel = zeros(n_f, S);
for i = 1:S
    cartel_temp = ones(n_c(i, 1), 1);
    cartel_temp(n_f, 1) = 0;
    cartel(:, i) = cartel_temp;
end
clear cartel_temp;

%% ============================================================
%  Compute Benchmark Equilibrium (No Cartels)
%  ============================================================
fprintf('\n========================================\n');
fprintf('Computing Benchmark Equilibrium (No Cartels)\n');
fprintf('========================================\n\n');

equilibrium_benchmark;

mu_no_cartel = mu;
p_i_no_cartel = p_i;
p_s_no_cartel = p_s;
A_no_cartel = A;
muagg_no_cartel = muagg;
omega_no_cartel = omega;

save no_cartel mu_no_cartel p_i_no_cartel p_s_no_cartel A_no_cartel muagg_no_cartel omega_no_cartel profit_no_cartel
clear p_i p_s A yy;

%% ============================================================
%  Compute Collusion Equilibrium
%  ============================================================
fprintf('\n========================================\n');
fprintf('Computing Equilibrium with Cartels\n');
fprintf('========================================\n\n');

equilibrium_imperfect_collusion;

mu_cartel = mu;
p_i_cartel = p_i;
A_cartel = A;
p_s_cartel = p_s;
clear mu p_i A p_s;

%% ============================================================
%  Load Benchmark Results and Compute Comparisons
%  ============================================================
load no_cartel;
delete no_cartel.mat;

% Productivity loss from cartels
A_loss_cartel = (A_cartel / A_no_cartel - 1) * 100;
omega_cartel = omega;
clear omega;

% Cartel indicator matrix
cartel_moment = cartel;
cartel_moment(cartel_moment == 0) = NaN;

% Markup increase from collusion
markup_increase = ((mu_cartel ./ mu_no_cartel) - 1) * 100;

% Sectoral price indexes
p_s_cartel = (nansum(p_i_cartel.^(1 - rho))).^(1 / (1 - rho));
p_s_no_cartel = (nansum(p_i_no_cartel.^(1 - rho))).^(1 / (1 - rho));

% Profit growth from collusion
profit_growth = ((profit_cartel ./ profit_no_cartel) - 1) * 100;

%% ============================================================
%  Prepare Data for Profit Distribution Plots
%  ============================================================
fprintf('\n========================================\n');
fprintf('Preparing Profit Distribution Data\n');
fprintf('========================================\n\n');

% Individual profit growth (cartel members only)
profit_growth_plot = profit_growth .* cartel_moment;
profit_growth_plot = profit_growth_plot(:);
profit_growth_plot = profit_growth_plot(~isnan(profit_growth_plot));

% Aggregate profit growth by cartel
profit_cartel_agg = profit_cartel .* cartel_moment;
profit_cartel_agg = nansum(profit_cartel_agg);

profit_no_cartel_agg = profit_no_cartel .* cartel_moment;
profit_no_cartel_agg = nansum(profit_no_cartel_agg);

profit_growth_agg_plot = ((profit_cartel_agg ./ profit_no_cartel_agg) - 1) * 100;
profit_growth_agg_plot = profit_growth_agg_plot(:);
profit_growth_agg_plot = profit_growth_agg_plot(~isnan(profit_growth_agg_plot));

%% ============================================================
%  Figure F8(a): Distribution of Individual Profit Growth
%  ============================================================
fprintf('\n========================================\n');
fprintf('Generating Figure F8(a): Individual Profits\n');
fprintf('========================================\n\n');

figure;
nbins = 20;
histogram(profit_growth_plot, nbins, ...
    'Normalization', 'probability', ...
    'EdgeColor', 'black', ...
    'LineWidth', 2, ...
    'FaceColor', [1 1 1]);

xlabel('Growth of cartel members'' individual profits (in %)', ...
    'FontSize', 12, 'FontWeight', 'default', 'Color', 'black');
ylabel('Fraction of cartel members', ...
    'FontSize', 12, 'FontWeight', 'default', 'Color', 'black');
title('', 'FontSize', 12, 'FontWeight', 'default');

set(gca, 'TickDir', 'out');
grid off;
set(gcf, 'Units', 'inches');
screenposition = get(gcf, 'Position');
set(gcf, ...
    'PaperPosition', [0 0 screenposition(3:4)], ...
    'PaperSize', [screenposition(3:4)]);

% Save figure
output_path_indiv = 'figure_f8_unreported';
print('-dpdf', '-painters', output_path_indiv);
fprintf('Figure saved to: %s.pdf\n', output_path_indiv);

%% ============================================================
%  Figure F8(b): Distribution of Aggregate Profit Growth
%  ============================================================
fprintf('\n========================================\n');
fprintf('Generating Figure F8(b): Aggregate Profits\n');
fprintf('========================================\n\n');

figure;
nbins = 10;
histogram(profit_growth_agg_plot, nbins, ...
    'Normalization', 'probability', ...
    'EdgeColor', 'black', ...
    'LineWidth', 2, ...
    'FaceColor', [1 1 1]);

xlabel('Growth of cartel members'' total profits (in %)', ...
    'FontSize', 12, 'FontWeight', 'default', 'Color', 'black');
ylabel('Fraction of cartels', ...
    'FontSize', 12, 'FontWeight', 'default', 'Color', 'black');
title('', 'FontSize', 12, 'FontWeight', 'default');

set(gca, 'TickDir', 'out');
grid off;
set(gcf, 'Units', 'inches');
screenposition = get(gcf, 'Position');
set(gcf, ...
    'PaperPosition', [0 0 screenposition(3:4)], ...
    'PaperSize', [screenposition(3:4)]);

% Save figure
output_path_agg = 'figure_f8';
print('-dpdf', '-painters', output_path_agg);
fprintf('Figure saved to: %s.pdf\n', output_path_agg);

%% ============================================================
%  Display Summary Statistics
%  ============================================================
fprintf('\n========================================\n');
fprintf('Summary Statistics\n');
fprintf('========================================\n\n');

fprintf('Individual Profit Growth (Cartel Members):\n');
fprintf('  Mean:   %7.2f%%\n', mean(profit_growth_plot));
fprintf('  Median: %7.2f%%\n', median(profit_growth_plot));
fprintf('  Std:    %7.2f%%\n', std(profit_growth_plot));
fprintf('  Min:    %7.2f%%\n', min(profit_growth_plot));
fprintf('  Max:    %7.2f%%\n', max(profit_growth_plot));
fprintf('\n');

fprintf('Aggregate Profit Growth (By Cartel):\n');
fprintf('  Mean:   %7.2f%%\n', mean(profit_growth_agg_plot));
fprintf('  Median: %7.2f%%\n', median(profit_growth_agg_plot));
fprintf('  Std:    %7.2f%%\n', std(profit_growth_agg_plot));
fprintf('  Min:    %7.2f%%\n', min(profit_growth_agg_plot));
fprintf('  Max:    %7.2f%%\n', max(profit_growth_agg_plot));
fprintf('\n');

fprintf('Aggregate Results:\n');
fprintf('  Productivity loss from cartels: %7.2f%%\n', A_loss_cartel);
fprintf('  Number of cartelized sectors:   %7.0f\n', sum(collusive_ind_final));
fprintf('  Share of cartelized sectors:    %7.2f%%\n', 100 * sum(collusive_ind_final) / S);

close all;
toc;