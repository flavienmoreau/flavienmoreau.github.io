%% AEJ Macro Replication Package (Moreau and Panon, forthcoming)
% This script reproduces Table 7: Aggregate Gains from Decreasing Collusion Intensity

tic
clear;
clc;
diary table_7.txt
rng('default');                              % For reproducibility

%% ============================================================
%  Model Parameters
%  ============================================================
n_f = 500;                                    % Number of firms within each sector
S = 670;                                      % Number of sectors
L = 1;                                        % Inelastic labor supply
nu = 2;                                       % Inverse Frisch elasticity of labor supply

rho = 12.0564816759752;               % Within-sector elasticity of substitution
eta = 3.10040889831152;               % Between-sector elasticity of substitution
xi = 10.2378007453196;                % Firm productivity Pareto shape parameter
xi_s = 2.80881084697840;              % Sector productivity Pareto shape parameter
zeta = 0.161187916362012;             % Cartel size parameter (geometric distribution)
zeta_f = 0.00407313218542430;         % Number of firms parameter (geometric distribution)
beta = 0.41;                          % Collusion intensity
share_cartels = 90;                   % Controls the share of cartelized industries

%% ============================================================
%  Generate Productivity Distribution
%  ============================================================
N = n_f;
M = S;
alpha = xi;
b = 1;
P = randp(N,M,alpha,b);
y = b:max(P)/1000:max(P);
z = P;
z = sort(z, 'descend');                       % Sorted Data & Index

%--------------------%
% Add sectoral draws %
%--------------------%
M_s = S;
alpha_s = xi_s;
b = 1;
P_s = randp(1,M_s,alpha_s,b);
z_s = P_s;
clear P_s;

% Update firm-level productivity: product of idiosyncratic draw and
% sectoral draw
z_final  = bsxfun(@times, z, z_s);
clear z;
z = z_final;   % Rename z
clear z_final;

%% ============================================================
%  Generate Firm Distribution Across Sectors
%  ============================================================
nn = geornd(zeta_f,S,1);                      % sample from geometric distribution with parameter zeta_f
nn(nn == 0) = 178;                            % Replace 0s by 178 (median number of firms)

phi = zeros(N, S);                            % matrix that determines number of producers per sector

nn(nn > n_f) = n_f;                           % Fix highest number of firms to the upper bound

nn(nn == 1) = 2;                              % Fix smallest number of firms (1) to 2 so that it is a duopoly

for i = 1:S
    temp = zeros(N,1);
    temp(1:nn(i)) = 1;
    temp = temp(randperm(N));
    phi(:,i) = temp;
end

phi  = sort(phi, 1,'descend');

z  = z.*phi  + eps.*(1-phi);                  % Productivity distribution is such that the least productive firms have productivity = 0
z  = sort(z, 1,'descend');

phi(phi == 0) = NaN;

%% ============================================================
%  Generate Cartel Structure
%  ============================================================
treated_ind_90 = prctile(z_s, share_cartels); % Find the threshold value for the top 10%

% Uncomment depending on the case considered
treated_ind_top10 = z_s >= treated_ind_90;

collusive_ind = double(treated_ind_top10');

n_c = zeros(S, 1);                            % Preallocate n_c
for s = 1:S
    if collusive_ind(s,1) == 1
        n_c(s) = geornd(zeta, 1, 1);
        %n_c = geornd(zeta, S, 1);           % sample from geometric distribution with parameter zeta
    end
end

n_c((n_c == 0) & (collusive_ind == 1)) = 4;  % Assign the median number of cartel members whenever n_c is 0 and the industry is cartelized

n_c(n_c == 1) = 2;                            % replaces values == 1 as cartels must have at least 2 firms
dummy = n_c > nn;                             % dummy variable = 1 if number of cartel members > number of producers

n_c(dummy) = nn(dummy);                       % When the number of cartel members > number of operating firms, the cartel is all-inclusive

collusive_ind_final = n_c> 0;                 % Select cartelized industries

for i = 1:S
    cartel_temp = ones(n_c(i,1),1);           % Create column vector of n_c ones
    cartel_temp(n_f,1) = 0;                   % Complete vector to get a (n_f*S) matrix
    cartel(:,i) = cartel_temp;
end
clear cartel_temp;

%% ============================================================
%  Compute Baseline Equilibrium (beta = 0.41)
%  ============================================================
fprintf('\n========================================\n');
fprintf('Computing BASELINE Equilibrium (beta = 0.41)\n');
fprintf('========================================\n\n');

equilibrium_imperfect_collusion;              % Solve model with cartels
mu_cartel = mu;
p_i_cartel = p_i;
A_cartel = A;
p_s_cartel = p_s;
muagg_cartel = muagg;
clear mu p_i A p_s

save benchmark mu_cartel p_i_cartel p_s_cartel A_cartel muagg_cartel

fprintf('Baseline Results:\n');
fprintf('  Aggregate productivity (A)    = %7.4f\n', A_cartel);
fprintf('  Aggregate markup (M)          = %7.4f\n', muagg_cartel);
fprintf('\n');

%% ============================================================
%  Define Beta Values and Initialize Storage
%  ============================================================
beta_values = [0.41, 0.3, 0.2, 0.1];

% Initialize arrays to store results
A_loss_cartel_results = zeros(size(beta_values));
A_loss_efficient_results = zeros(size(beta_values));
A_increased_distance_results = zeros(size(beta_values));
markup_increase_results = zeros(size(beta_values));
welfare_static_results = zeros(size(beta_values));

%% ============================================================
%  Loop Over Beta Values
%  ============================================================
for k = 1:length(beta_values)
    beta = beta_values(k);

    fprintf('\n========================================\n');
    fprintf('Computing Equilibrium for beta = %7.2f\n', beta);
    fprintf('========================================\n\n');

    equilibrium_imperfect_collusion;          % Solve model without cartels
    mu_low_kappa = mu;
    p_i_low_kappa = p_i;
    p_s_low_kappa = p_s;
    A_low_kappa = A;
    muagg_low_kappa = muagg;
    omega_low_kappa = omega;

    load benchmark                            % CAREFUL: IF PARAMETERS CHANGE, THIS NEEDS TO BE UPDATED

    A_loss_cartel = (A_cartel/A_low_kappa-1)*100;

    % Efficient level
    A_s_eff = nanmean(z.^(rho-1)).^(1/(rho-1));
    A_eff = nanmean(A_s_eff.^(eta-1)).^(1/(eta-1));

    A_loss_efficient = (A_cartel/A_eff-1)*100;

    % Welfare (static)
    welfare_static = ((A_cartel/A_low_kappa).*(muagg_cartel/muagg_low_kappa).^(-1/(1+nu))-1).*100;

    % Store results
    A_loss_cartel_results(k) = A_loss_cartel;
    A_loss_efficient_results(k) = A_loss_efficient;
    A_increased_distance_results(k) = ((A_loss_cartel/A_loss_efficient)*100);
    markup_increase_results(k) = (muagg_cartel - muagg_low_kappa)*100;
    welfare_static_results(k) = welfare_static;
    
    %fprintf('Results for beta = %7.2f:\n', beta);
    %fprintf('  Aggregate productivity (A)                = %7.4f\n', A_low_kappa);
    %fprintf('  Aggregate markup (M)                      = %7.4f\n', muagg_low_kappa);
    %fprintf('  A loss (loss from no cartel), %%           = %7.2f\n', A_loss_cartel);
    %fprintf('  A loss (loss wrt efficient economy), %%    = %7.2f\n', A_loss_efficient);
    %fprintf('  A increased distance (wrt efficient), %%   = %7.2f\n', A_increased_distance_results(k));
    %fprintf('  Markup increase, points                   = %7.2f\n', markup_increase_results(k));
    %fprintf('  Static welfare loss (from cartels), %%     = %7.2f\n', welfare_static);
    %fprintf('\n');
end

% Clean up
delete benchmark.mat

%% ============================================================
%  Display Results Table (Table 7 Format)
%  ============================================================
fprintf('\n');
fprintf('================================================================\n');
fprintf('TABLE 7: AGGREGATE GAINS FROM DECREASING COLLUSION INTENSITY\n');
fprintf('================================================================\n\n');

fprintf('                                      kappa=0.1 kappa=0.2 kappa=0.3\n');
fprintf('                                       (1)      (2)      (3)\n');
fprintf('----------------------------------------------------------------\n');
fprintf('Panel A: Aggregate productivity gains, in %%\n');
fprintf('A_cartel -> A_comp                    %6.2f   %6.2f   %6.2f\n', ...
        -A_loss_cartel_results(4), -A_loss_cartel_results(3), -A_loss_cartel_results(2));
fprintf('Distance to efficient allocation    %7.2f  %7.2f  %7.2f\n', ...
        -A_increased_distance_results(4), -A_increased_distance_results(3), -A_increased_distance_results(2));
fprintf('\n');
fprintf('Panel B: Aggregate welfare gains\n');
fprintf('M_cartel -> M_comp (in pp)           %7.2f  %7.2f  %7.2f\n', ...
        -markup_increase_results(4), -markup_increase_results(3), -markup_increase_results(2));
fprintf('W_cartel -> W_comp (in %%)            %6.2f   %6.2f   %6.2f\n', ...
        -welfare_static_results(4), -welfare_static_results(3), -welfare_static_results(2));
fprintf('================================================================\n\n');

diary off
toc;