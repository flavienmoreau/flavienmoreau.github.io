%% Model with markups as exogenous primitives

% The demand elasticities are taken from the cartel equilibrium.
p_i_umbrella_pricing  = ee./(ee-1)./z;

p_s              = nanmean(p_i_umbrella_pricing.^(1-rho)).^(1/(1-rho));
p_s(isinf(p_s))   = 10^16;

P               = nanmean(p_s.^(1-eta)).^(1/(1-eta));

yy = bsxfun(@times, p_i_umbrella_pricing.^(-rho), p_s.^(rho-eta).*P.^eta.*Y); % Comes from FOCs

yy    = real(yy); 

A_umbrella_pricing  = nanmean(nanmean(z.^(-1).*yy/Y)).^(-1);   

Y     = A_umbrella_pricing*(L);

ll = yy./z;

mu_umbrella_pricing  = ee./(ee-1); 
muagg_umbrella_pricing   = P*A_umbrella_pricing;
