%% Equilibrium conditions (guess)
z = z.*phi;

p_i  = rho/(rho-1)./z;                     % Price of a firm
p_s  = (nanmean(p_i.^(1-rho))).^(1/(1-rho));  % Sectoral price index
P   = (nanmean(p_s.^(1-eta))).^(1/(1-eta));   % Aggregate price

A  = nanmean(nanmean(z.^(-1).*(p_i./repmat(p_s,n_f,1)).^(-rho).*repmat(p_s/P, n_f,1).^(-eta))).^(-1); % Aggregate productivity
     
Y     = A*L; % Aggregate output
Yold  = Y;

omegaold  =  ((p_i./repmat(p_s,n_f,1)).^(1-rho))./(repmat(nn', n_f, 1));  % Market share (need to make it a matrix using repmat)
yyold      = (p_i./repmat(p_s,n_f,1)).^(-rho).*(repmat(p_s,n_f,1)./P).^(-eta).*Y; 

omegaold_cum = nansum(omegaold);              % Check market shares add up to one           

%% Solve the model numerically

for it = 1 : 200

Y      = Yold;  
omega  = omegaold;
yy     = yyold;

ee = (1/rho*(1-omega) + 1/eta*omega).^(-1); 
p_i  = ee./(ee-1)./z;

p_s              = nanmean(p_i.^(1-rho)).^(1/(1-rho));
p_s(isinf(p_s))   = 10^16;

P               = nanmean(p_s.^(1-eta)).^(1/(1-eta));

omega = (bsxfun(@times, p_i.^(1-rho), p_s.^(rho-1)))./(repmat(nn', n_f, 1)); % "bsxfun": Directly divides numerator by price index

yy = bsxfun(@times, p_i.^(-rho), p_s.^(rho-eta).*P.^eta.*Y); % Comes from FOCs

omega = real(omega);
yy    = real(yy); 

A  = nanmean(nanmean(phi.*z.^(-1).*yy/Y)).^(-1);   

Y     = A*(L);

error = max([norm(omega - omegaold); norm(Y-Yold)]);

rem = mod(it,10);
if rem == 1
    fprintf('%4i %6.2e \n',[it, error]);
end

if error < 1e-7, break, end
    
Yold         = 1/2*Y      +  1/2*Yold;
omegaold     = 1/10*omega +  9/10*omegaold;
yyold        = 1/10*yy    +  9/10*yyold;

end

ll = yy./z;

if norm(omega-omegaold)>1e-3
    disp('Warning: omega has not converged')
end

mu  = ee./(ee-1); 
muagg   = P*A;

profit_no_cartel = (p_i - 1./z).*yy;

yy_no_cartel = yy;