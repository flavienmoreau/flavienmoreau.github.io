%% AEJ Macro Replication Package (Moreau and Panon, forthcoming)
% This script reproduces Table E15: Importance of the Umbrella Pricing Effect
%
% The table compares two scenarios:
%   Column (1) - Benchmark: Full model with umbrella pricing effect
%   Column (2) - No umbrella pricing effect: counterfactual where the markups 
%   of non-cartel members are held constant at their levels in the cartel equilibrium.

tic
clear;
clc;
diary table_e15.txt
rng('default');  % For reproducibility

%% ============================================================
%  Model Parameters (Collusion Calibration)
%  ============================================================
fprintf('\n========================================\n');
fprintf('Table E15: Importance of the Umbrella Pricing Effect\n');
fprintf('========================================\n\n');

n_f = 500;                  % Max number of firms within each sector
S = 670;                    % Number of sectors
L = 1;                      % Inelastic labor supply
nu = 2;                     % Inverse Frisch elasticity of labor supply

% Calibrated parameters (collusion model)
rho = 12.0564816759752;     % Within-sector elasticity of substitution
eta = 3.10040889831152;     % Between-sector elasticity of substitution
xi = 10.2378007453196;      % Firm productivity Pareto shape parameter
xi_s = 2.80881084697840;    % Sector productivity Pareto shape parameter
zeta = 0.161187916362012;   % Cartel size parameter (geometric distribution)
zeta_f = 0.00407313218542430;  % Number of firms parameter (geometric distribution)
beta = 0.41;                % Collusion intensity
share_cartels = 90;         % Share of cartelized industries (top percentile)

%% ============================================================
%  Generate Productivity Distribution
%  ============================================================
N = n_f;
M = S;
alpha = xi;
b = 1;

% Firm-level productivity draws (Pareto distribution)
P = randp(N, M, alpha, b);
y = b:max(P)/1000:max(P);
z = P;
z = sort(z, 'descend');

% Sectoral productivity draws (Pareto distribution)
M_s = S;
alpha_s = xi_s;
b = 1;
P_s = randp(1, M_s, alpha_s, b);
z_s = P_s;
clear P_s;

% Combined productivity: firm-level � sector-level
z_final = bsxfun(@times, z, z_s);
clear z;
z = z_final;
clear z_final;

%% ============================================================
%  Generate Firm Distribution Across Sectors
%  ============================================================
nn = geornd(zeta_f, S, 1);  % Number of firms per sector (geometric distribution)
nn(nn == 0) = 178;          % Replace 0s with median value

phi = zeros(N, S);          % Matrix that determines number of producers per sector

nn(nn > n_f) = n_f;         % Cap at maximum number of firms
nn(nn == 1) = 2;            % Minimum of 2 firms for potential collusion

% Create firm activity matrix (phi = 1 if firm is active)
for i = 1:S
    temp = zeros(N, 1);
    temp(1:nn(i)) = 1;
    temp = temp(randperm(N));
    phi(:, i) = temp;
end

phi = sort(phi, 1, 'descend');

z = z .* phi + eps .* (1 - phi);  % Inactive firms get negligible productivity
z = sort(z, 1, 'descend');

phi(phi == 0) = NaN;

%% ============================================================
%  Generate Cartel Structure
%  ============================================================
% Identify cartelized industries (sectors with high productivity draws)
treated_ind_90 = prctile(z_s, share_cartels);
treated_ind_top10 = z_s >= treated_ind_90;
collusive_ind = double(treated_ind_top10');

% Determine number of cartel members per industry
n_c = zeros(S, 1);
for s = 1:S
    if collusive_ind(s, 1) == 1
        n_c(s) = geornd(zeta, 1, 1);
    end
end

n_c((n_c == 0) & (collusive_ind == 1)) = 4;  % Assign median cartel size when draw is 0
n_c(n_c == 1) = 2;                            % Cartels must have at least 2 members

% Ensure cartel size doesn't exceed number of firms in sector
dummy = n_c > nn;
n_c(dummy) = nn(dummy);

collusive_ind_final = n_c > 0;

% Create cartel membership matrix (cartel = 1 if firm is cartel member)
for i = 1:S
    cartel_temp = ones(n_c(i, 1), 1);
    cartel_temp(n_f, 1) = 0;
    cartel(:, i) = cartel_temp;
end
clear cartel_temp;

%% ============================================================
%  Step 1: Compute Benchmark Equilibrium (No Cartels)
%  ============================================================
fprintf('\n');
display('Computing Equilibrium without Cartels')
fprintf('\n');

equilibrium_benchmark;

% Store benchmark results
mu_no_cartel = mu;
p_i_no_cartel = p_i;
p_s_no_cartel = p_s;
A_no_cartel = A;
muagg_no_cartel = muagg;
omega_no_cartel = omega;
ee_no_cartel = ee;

save no_cartel mu_no_cartel p_i_no_cartel p_s_no_cartel A_no_cartel muagg_no_cartel omega_no_cartel profit_no_cartel ee_no_cartel

%% ============================================================
%  Step 2: Compute Equilibrium with Cartels
%  ============================================================
equilibrium_imperfect_collusion;

% Store cartel equilibrium results
mu_cartel = mu;
p_i_cartel = p_i;
A_cartel = A;
p_s_cartel = p_s;
clear mu p_i A p_s

load no_cartel
delete no_cartel.mat

A_loss_cartel = (A_cartel / A_no_cartel - 1) * 100;
omega_cartel = omega;
clear omega;

% Check market shares add up to one
check_shares = sum(market_share_imperfect_collusion, 'omitnan');
check_shares(check_shares == 0) = NaN;

% Check markup increase
markup_increase = ((mu_cartel ./ mu_no_cartel) - 1) * 100;

% Get the right sectoral price indexes
p_s_cartel = (nansum(p_i_cartel.^(1-rho))).^(1/(1-rho));
p_s_no_cartel = (nansum(p_i_no_cartel.^(1-rho))).^(1/(1-rho));

% Profit increase
profit_growth = ((profit_cartel ./ profit_no_cartel) - 1) * 100;

% Efficient level
A_s_eff = nanmean(z.^(rho-1)).^(1/(rho-1));
A_eff = nanmean(A_s_eff.^(eta-1)).^(1/(eta-1));

A_loss_efficient = (A_cartel / A_eff - 1) * 100;

%% ============================================================
%  Welfare (static)
%  ============================================================
welfare_static = ((A_cartel / A_no_cartel) .* (muagg / muagg_no_cartel).^(-1/(1+nu)) - 1) .* 100;
welfare_efficient = ((A_cartel / A_eff) .* (muagg).^(-1/(1+nu)) - 1) .* 100;

%% ============================================================
%  Display Results - Column 1 (Benchmark with umbrella pricing)
%  ============================================================
fprintf('\n');
fprintf('========================================================================\n');
fprintf('Column 1: Benchmark (with umbrella pricing effect)\n');
fprintf('========================================================================\n');
fprintf('A loss (loss from no cartel), *100              = %7.2f \n', A_loss_cartel);
fprintf('A loss (loss wrt efficient economy), *100       = %7.2f \n', A_loss_efficient);
fprintf('A increased distance (wrt efficient), *100      = %7.2f \n', ((A_loss_cartel / A_loss_efficient) * 100));
fprintf('Markup increase, points                         = %7.2f \n', (muagg - muagg_no_cartel) * 100);
fprintf('Static welfare loss (from cartels), *100        = %7.2f \n', welfare_static);
fprintf('Static welfare loss (wrt efficient), *100       = %7.2f \n', welfare_efficient);
fprintf('Check on market shares                          = %7.3f \n', nanmean(check_shares));
fprintf('Share cartelized sectors                        = %7.3f \n', sum(collusive_ind_final) ./ S);

%% ============================================================
%  Step 3: Compute Counterfactual (No Umbrella Pricing Effect)
%  ============================================================
% In this counterfactual, we remove the umbrella pricing effect:
% - Cartel members: use demand elasticities from competitive benchmark
% - Non-cartel members: use demand elasticities from cartel equilibrium

clear ee yy ll;

% Construct demand elasticities for the no-umbrella-pricing counterfactual
ee = ee_no_cartel .* cartel;                % Cartel members: competitive elasticities

umbrella_matrix = 1 - cartel;
ee_umbrella = ee_cartel .* umbrella_matrix; % Non-cartel members: cartel equilibrium elasticities

ee = ee + ee_umbrella;                      % Combined elasticity matrix

equilibrium_umbrella_pricing;               % Solve equilibrium with modified elasticities

%% ============================================================
%  Welfare without umbrella pricing
%  ============================================================
welfare_static_um = ((A_cartel / A_umbrella_pricing) .* (muagg / muagg_umbrella_pricing).^(-1/(1+nu)) - 1) .* 100;

%% ============================================================
%  Display Results - Column 2 (No umbrella pricing effect)
%  ============================================================
fprintf('\n');
fprintf('========================================================================\n');
fprintf('Column 2: No umbrella pricing effect\n');
fprintf('========================================================================\n');
fprintf('A loss (loss from no cartel), *100              = %7.2f \n', ((A_cartel / A_umbrella_pricing) - 1) * 100);
fprintf('A loss (loss wrt efficient economy), *100       = %7.2f \n', A_loss_efficient);
fprintf('A increased distance (wrt efficient), *100      = %7.2f \n', ((((A_cartel / A_umbrella_pricing) - 1) * 100 / (((A_cartel / A_eff) - 1) * 100)) * 100));
fprintf('Markup increase, points                         = %7.2f \n', (muagg - muagg_umbrella_pricing) * 100);
fprintf('Static welfare loss (from cartels), *100        = %7.2f \n', welfare_static_um);

%% ============================================================
%  Summary Table E15
%  ============================================================
fprintf('\n');
fprintf('========================================================================\n');
fprintf('                Table E15: Importance of the Umbrella Pricing Effect\n');
fprintf('========================================================================\n');
fprintf('                                          Benchmark    No umbrella pricing\n');
fprintf('                                             (1)              (2)\n');
fprintf('------------------------------------------------------------------------\n');
fprintf('Panel A: Aggregate productivity gains, in %%\n');
fprintf('  A_cartel -> A_comp                       %6.2f           %6.2f\n', ...
    -A_loss_cartel, -((A_cartel / A_umbrella_pricing) - 1) * 100);
fprintf('  Distance to efficient allocation        %6.2f          %6.2f\n', ...
    -((A_loss_cartel / A_loss_efficient) * 100), ...
    -((((A_cartel / A_umbrella_pricing) - 1) * 100 / (((A_cartel / A_eff) - 1) * 100)) * 100));
fprintf('\n');
fprintf('Panel B: Aggregate welfare gains\n');
fprintf('  M_cartel -> M_comp (in pp)              %6.2f          %6.2f\n', ...
    -(muagg - muagg_no_cartel) * 100, -(muagg - muagg_umbrella_pricing) * 100);
fprintf('  W_cartel -> W_comp (in %%)               %6.2f           %6.2f\n', ...
    -welfare_static, -welfare_static_um);
fprintf('========================================================================\n');

diary off
toc;