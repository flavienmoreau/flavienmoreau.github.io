%% AEJ Macro Replication Package (Moreau and Panon, forthcoming)
% This script produces Figure F7: Parameter Identification

% The figure shows a heatmap of how model moments respond to 10% increases 
% in each structural parameter. This helps assess parameter identification.

% Required files:
%   - randp.m         (Pareto random number generator)
%   - heatmap.m       (Heatmap visualization function)
%   - redblue.m       (Red-blue colormap)
%   - equilibrium_Identification.m (Equilibrium solver with cartels)
%   - moments_Identification.m     (Moment calculation)

tic
clear;
clc;
rng('default');  % For reproducibility

%% ============================================================
%  Model Parameters (Baseline Calibration)
%  ============================================================
n_f = 500;                              % Max number of firms per sector
S = 670;                                % Number of sectors
L = 1;                                  % Inelastic labor supply
nu = 2;                                 % Inverse Frisch elasticity

rho = 12.0564816759752;                 % Within-sector elasticity of substitution
eta = 3.10040889831152;                 % Between-sector elasticity of substitution
xi = 10.2378007453196;                  % Firm productivity Pareto shape
xi_s = 2.80881084697840;                % Sector productivity Pareto shape
zeta = 0.161187916362012;               % Cartel size parameter (geometric)
zeta_f = 0.00407313218542430;           % Number of firms parameter (geometric)
beta = 0.41;                            % Collusion intensity
share_cartels = 90;                     % Share of cartelized industries (percentile)

xi_init = xi;                           % Store initial xi for later use

%% ============================================================
%  Generate Baseline Economy
%  ============================================================
fprintf('\n========================================\n');
fprintf('Generating Baseline Economy\n');
fprintf('========================================\n\n');

% --- Firm-level productivity draws ---
N = n_f;
M = S;
alpha = xi;
b = 1;
P = randp(N, M, alpha, b);
y = b:max(P)/1000:max(P);
z = sort(P, 'descend');

% --- Sectoral productivity draws ---
M_s = S;
alpha_s = xi_s;
P_s = randp(1, M_s, alpha_s, b);
z_s = P_s;
clear P_s;

% --- Combined productivity: firm � sector ---
z_final = bsxfun(@times, z, z_s);
clear z;
z = z_final;
clear z_final;

% --- Number of firms per sector (geometric distribution) ---
nn = geornd(zeta_f, S, 1);
nn(nn == 0) = 178;          % Replace 0s with median
nn(nn > n_f) = n_f;         % Cap at maximum
nn(nn == 1) = 2;            % Minimum 2 firms (duopoly)

% --- Firm activity matrix ---
phi = zeros(N, S);
for i = 1:S
    temp = zeros(N, 1);
    temp(1:nn(i)) = 1;
    temp = temp(randperm(N));
    phi(:, i) = temp;
end

phi = sort(phi, 1, 'descend');
z = z .* phi + eps .* (1 - phi);
z = sort(z, 1, 'descend');
phi(phi == 0) = NaN;

% --- Cartel structure ---
treated_ind_90 = prctile(z_s, share_cartels);
treated_ind_top10 = z_s >= treated_ind_90;
collusive_ind = double(treated_ind_top10');

n_c = zeros(S, 1);
for s = 1:S
    if collusive_ind(s, 1) == 1
        n_c(s) = geornd(zeta, 1, 1);
    end
end

n_c((n_c == 0) & (collusive_ind == 1)) = 4;  % Median cartel size
n_c(n_c == 1) = 2;                            % Minimum 2 members
dummy = n_c > nn;
n_c(dummy) = nn(dummy);                       % Cap at number of firms
collusive_ind_final = n_c > 0;

% --- Cartel membership matrix ---
cartel = zeros(n_f, S);
for i = 1:S
    cartel_temp = ones(n_c(i, 1), 1);
    cartel_temp(n_f, 1) = 0;
    cartel(:, i) = cartel_temp;
end
clear cartel_temp;

% --- Save baseline parameters ---
parameters = 'parameters.mat';
save(parameters);

%% ============================================================
%  Compute Baseline Moments
%  ============================================================
fprintf('\n');
fprintf('Computing Equilibrium with Cartels (Baseline)\n');
fprintf('\n');

equilibrium_Identification;

mu_cartel = mu;
p_i_cartel = p_i;

moments_Identification;

original_moments = all_model_moments;
savefile = 'original_moments.mat';
save(savefile, 'original_moments');

%% ============================================================
%  Sensitivity Analysis: Perturb Each Parameter by 10%
%  ============================================================
perturbation = 1.1;  % 10% increase

%% --- Sensitivity to rho ---
fprintf('\n========================================\n');
fprintf('Computing Sensitivity to rho\n');
fprintf('========================================\n\n');

clear;
load parameters;
rho = rho * 1.1;

equilibrium_Identification;
mu_cartel = mu;
p_i_cartel = p_i;
moments_Identification;

model_moments_rho = all_model_moments;
save change_rho model_moments_rho;

%% --- Sensitivity to eta ---
fprintf('\n========================================\n');
fprintf('Computing Sensitivity to eta\n');
fprintf('========================================\n\n');

clear;
load parameters;
eta = eta * 1.1;

equilibrium_Identification;
mu_cartel = mu;
p_i_cartel = p_i;
moments_Identification;

model_moments_eta = all_model_moments;
save change_eta model_moments_eta;

%% --- Sensitivity to xi (firm productivity shape) ---
fprintf('\n========================================\n');
fprintf('Computing Sensitivity to xi\n');
fprintf('========================================\n\n');

clear;
load parameters;
rng('default');

xi = xi * 1.1;
clear z alpha b P y;

% Regenerate productivity with new xi
N = n_f;
M = S;
alpha = xi;
b = 1;
P = randp(N, M, alpha, b);
y = b:max(P)/1000:max(P);
z = sort(P, 'descend');

% Sectoral draws (unchanged)
M_s = S;
alpha_s = xi_s;
P_s = randp(1, M_s, alpha_s, b);
z_s = P_s;
clear P_s;

z_final = bsxfun(@times, z, z_s);
clear z z_s;
z = z_final;
clear z_final;

equilibrium_Identification;
mu_cartel = mu;
p_i_cartel = p_i;
moments_Identification;

model_moments_xi = all_model_moments;
save change_xi model_moments_xi;

%% --- Sensitivity to xi_s (sector productivity shape) ---
fprintf('\n========================================\n');
fprintf('Computing Sensitivity to xi_s\n');
fprintf('========================================\n\n');

clear;
load parameters;
rng('default');

xi_s = xi_s * 1.1;
clear z alpha b P y;

% Regenerate productivity with new xi_s
N = n_f;
M = S;
alpha = xi_init;  % Use original xi
b = 1;
P = randp(N, M, alpha, b);
y = b:max(P)/1000:max(P);
z = sort(P, 'descend');

% Sectoral draws with new xi_s
M_s = S;
alpha_s = xi_s;
P_s = randp(1, M_s, alpha_s, b);
z_s = P_s;
clear P_s;

z_final = bsxfun(@times, z, z_s);
clear z z_s;
z = z_final;
clear z_final;

equilibrium_Identification;
mu_cartel = mu;
p_i_cartel = p_i;
moments_Identification;

model_moments_xi_s = all_model_moments;
save change_xi_s model_moments_xi_s;

%% --- Sensitivity to zeta (cartel size parameter) ---
fprintf('\n========================================\n');
fprintf('Computing Sensitivity to zeta\n');
fprintf('========================================\n\n');

clear;
load parameters;
rng('default');

clear n_c cartel;
zeta = zeta * 1.1;

% Regenerate cartel structure with new zeta
n_c = zeros(S, 1);
for s = 1:S
    if collusive_ind(s, 1) == 1
        n_c(s) = geornd(zeta, 1, 1);
    end
end

n_c((n_c == 0) & (collusive_ind == 1)) = 4;
n_c(n_c == 1) = 2;
dummy = n_c > nn;
n_c(dummy) = nn(dummy);
collusive_ind_final = n_c > 0;

cartel = zeros(n_f, S);
for i = 1:S
    cartel_temp = ones(n_c(i, 1), 1);
    cartel_temp(n_f, 1) = 0;
    cartel(:, i) = cartel_temp;
end
clear cartel_temp;

equilibrium_Identification;
mu_cartel = mu;
p_i_cartel = p_i;
moments_Identification;

model_moments_zeta = all_model_moments;
save change_zeta model_moments_zeta;

%% --- Sensitivity to zeta_f (number of firms parameter) ---
fprintf('\n========================================\n');
fprintf('Computing Sensitivity to zeta_f\n');
fprintf('========================================\n\n');

clear;
load parameters;
rng('default');

zeta_f = zeta_f * 1.1;

% Regenerate number of firms per sector
nn = geornd(zeta_f, S, 1);
nn(nn == 0) = 178;
nn(nn > n_f) = n_f;
nn(nn == 1) = 2;

% Regenerate firm activity matrix
phi = zeros(N, S);
for i = 1:S
    temp = zeros(N, 1);
    temp(1:nn(i)) = 1;
    temp = temp(randperm(N));
    phi(:, i) = temp;
end

phi = sort(phi, 1, 'descend');
z = z .* phi + eps .* (1 - phi);
z = sort(z, 1, 'descend');
phi(phi == 0) = NaN;

% Regenerate cartel structure
treated_ind_90 = prctile(z_s, share_cartels);
treated_ind_top10 = z_s >= treated_ind_90;
collusive_ind = double(treated_ind_top10');

n_c = zeros(S, 1);
for s = 1:S
    if collusive_ind(s, 1) == 1
        n_c(s) = geornd(zeta, 1, 1);
    end
end

n_c((n_c == 0) & (collusive_ind == 1)) = 4;
n_c(n_c == 1) = 2;
dummy = n_c > nn;
n_c(dummy) = nn(dummy);
collusive_ind_final = n_c > 0;

cartel = zeros(n_f, S);
for i = 1:S
    cartel_temp = ones(n_c(i, 1), 1);
    cartel_temp(n_f, 1) = 0;
    cartel(:, i) = cartel_temp;
end
clear cartel_temp;

equilibrium_Identification;
mu_cartel = mu;
p_i_cartel = p_i;
moments_Identification;

model_moments_zeta_f = all_model_moments;
save change_zeta_f model_moments_zeta_f;

%% ============================================================
%  Compute Jacobian Matrix (Sensitivity Analysis)
%  ============================================================
fprintf('\n========================================\n');
fprintf('Computing Jacobian Matrix\n');
fprintf('========================================\n\n');

clear;
load original_moments;
load change_rho;
load change_eta;
load change_xi;
load change_xi_s;
load change_zeta;
load change_zeta_f;

% Compute percentage changes in moments for 10% parameter changes
jacobian_sensitivity = ones(length(original_moments), 6);
jacobian_sensitivity(:, 1) = ((model_moments_rho - original_moments) ./ abs(original_moments)) * 100;
jacobian_sensitivity(:, 2) = ((model_moments_eta - original_moments) ./ abs(original_moments)) * 100;
jacobian_sensitivity(:, 3) = ((model_moments_xi - original_moments) ./ abs(original_moments)) * 100;
jacobian_sensitivity(:, 4) = ((model_moments_xi_s - original_moments) ./ abs(original_moments)) * 100;
jacobian_sensitivity(:, 5) = ((model_moments_zeta_f - original_moments) ./ abs(original_moments)) * 100;
jacobian_sensitivity(:, 6) = ((model_moments_zeta - original_moments) ./ abs(original_moments)) * 100;

%% ============================================================
%  Generate Heatmap Figure
%  ============================================================
fprintf('\n========================================\n');
fprintf('Generating Heatmap Figure\n');
fprintf('========================================\n\n');

% Moment labels (rows)
name_moments = {'Aggregate markup'; ...
                'Slope'; ...
                'CR4 within'; ...
                'CR20 within'; ...
                'CR4 across'; ...
                'CR20 across'; ...
                'Median nbr. firms'; ...
                'Average nbr. cartel members'};

% Parameter labels (columns) using Greek characters
name_parameters = {char(961), ...      % rho
                   char(951), ...      % eta
                   [char(958) '_k'], ... % xi_k
                   [char(958) '_s'], ... % xi_s
                   char(963), ...      % sigma (zeta_f)
                   char(950)};         % zeta

% Colormap range
mincolor = -1;
maxcolor = 1;

% Create heatmap
figure_sensitivity = heatmap(jacobian_sensitivity, name_parameters, name_moments, '%0.3f', ...
    'Colormap', 'redblue', ...
    'Colorbar', true, ...
    'MinColorValue', mincolor, ...
    'MaxColorValue', maxcolor, ...
    'GridLines', '--', ...
    'TickFontSize', 11, ...
    'FontSize', 15, ...
    'ShowAllTicks', true, ...
    'TickAngle', 0);

set(gcf, 'color', 'w', 'PaperSize', [10 10]);

%% ============================================================
%  Save Figure
%  ============================================================
% Update the path below to your desired output location
output_path = 'figure_f7';
print('-dpdf', '-painters', output_path);

fprintf('Figure saved to: %s.pdf\n', output_path);
close;

%% ============================================================
%  Display Summary Statistics
%  ============================================================
fprintf('\n========================================\n');
fprintf('Sensitivity Analysis Complete\n');
fprintf('========================================\n\n');

fprintf('Jacobian Matrix (percent change in moments for 10%% parameter increase):\n\n');
disp(array2table(jacobian_sensitivity, ...
    'VariableNames', {'rho', 'eta', 'xi_k', 'xi_s', 'zeta_f', 'zeta'}, ...
    'RowNames', name_moments));

toc;