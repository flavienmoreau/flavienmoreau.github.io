%% Equilibrium Conditions (Initial Guess)
z = z .* phi;

mu = rho / (rho - 1) * ones(n_f, S);
p_i = mu ./ z;
p_s = (nanmean(p_i.^(1 - rho))).^(1 / (1 - rho));
P = (nanmean(p_s.^(1 - eta))).^(1 / (1 - eta));

A = nanmean(nanmean(z.^(-1) .* (p_i ./ repmat(p_s, n_f, 1)).^(-rho) .* repmat(p_s / P, n_f, 1).^(-eta))).^(-1);

Y = A * L;
Yold = Y;

omegaold = ((p_i ./ repmat(p_s, n_f, 1)).^(1 - rho)) ./ (repmat(nn', n_f, 1));

%% Compute Market Shares for Cartel Members
omegaold2 = omegaold(:, :) .* cartel(:, :);
omegaold2 = nansum(omegaold2);
omegaold2 = ones(n_f, 1) * omegaold2;
omegaold2 = omegaold2 .* cartel(:, :);
omegaold2 = beta * omegaold2;

omega_own = zeros(n_f, S);
for i = 1:S
    omega_own_temp = omegaold(1:n_c(i, 1), i);
    omega_own_temp(n_f, 1) = 0;
    omega_own(:, i) = omega_own_temp;
end
clear omega_own_temp;

omega_own = (1 - beta) * omega_own;
omegaold2 = bsxfun(@plus, omegaold2, omega_own);

for y = 1:S
    for x = 1:n_f
        if omegaold2(x, y) == 0
            omegaold2(x, y) = omegaold(x, y);
        else
            omegaold2(x, y) = omegaold2(x, y);
        end
    end
end

clear omegaold omega_own;

yyold = (p_i ./ repmat(p_s, n_f, 1)).^(-rho) .* (repmat(p_s, n_f, 1) ./ P).^(-eta) .* Y;

%% Solve the Model Numerically
for it = 1:200
    
    Y = Yold;
    omega = omegaold2;
    yy = yyold;
    
    ee = (1 / rho * (1 - omega) + 1 / eta * omega).^(-1);
    
    p_i = ee ./ (ee - 1) ./ z;
    
    p_s = nanmean(p_i.^(1 - rho)).^(1 / (1 - rho));
    p_s(isinf(p_s)) = 10^16;
    
    P = nanmean(p_s.^(1 - eta)).^(1 / (1 - eta));
    
    omega = (bsxfun(@times, p_i.^(1 - rho), p_s.^(rho - 1))) ./ (repmat(nn', n_f, 1));
    
    %% Update Market Shares (Cartel Members Care About Cartel Share)
    omega_new = omega(:, :) .* cartel(:, :);
    omega_new = nansum(omega_new);
    omega_new = ones(n_f, 1) * omega_new;
    omega_new = omega_new .* cartel(:, :);
    omega_new = beta * omega_new;
    
    omega_own2 = zeros(n_f, S);
    for i = 1:S
        omega_own2_temp = omega(1:n_c(i, 1), i);
        omega_own2_temp(n_f, 1) = 0;
        omega_own2(:, i) = omega_own2_temp;
    end
    clear omega_own2_temp;
    
    omega_own2 = (1 - beta) * omega_own2;
    
    omega_new = bsxfun(@plus, omega_new, omega_own2);
    
    for y = 1:S
        for x = 1:n_f
            if omega_new(x, y) == 0
                omega_new(x, y) = omega(x, y);
            else
                omega_new(x, y) = omega_new(x, y);
            end
        end
    end
    omega = omega_new;
    
    yy = bsxfun(@times, p_i.^(-rho), p_s.^(rho - eta) .* P.^eta .* Y);
    
    omega = real(omega);
    yy = real(yy);
    
    A = nanmean(nanmean(z.^(-1) .* yy / Y)).^(-1);
    
    Y = A * (L);
    
    error = max([norm(omega - omegaold2); norm(Y - Yold)]);
    
    rem = mod(it,10);
    if rem == 1
        fprintf('%4i %6.2e \n',[it, error]);
    end
    
    if error < 1e-7, break, end
    
    Yold = 1/2 * Y + 1/2 * Yold;
    omegaold2 = 1/10 * omega + 9/10 * omegaold2;
    yyold = 1/10 * yy + 9/10 * yyold;
    
end

ll = yy ./ z;

if norm(omega - omegaold2) > 1e-3
    disp('Warning: omega has not converged')
end

mu = ee ./ (ee - 1);
muagg = P * A;
clear omegaold2 omega_new;

profit_cartel = (p_i - 1 ./ z) .* yy;

yy_cartel = yy;

market_share_imperfect_collusion = (bsxfun(@times, p_i.^(1 - rho), p_s.^(rho - 1))) ./ (repmat(nn', n_f, 1));

Labor_cartel = nansum(ll);
PjYj_cartel = nansum(p_i .* yy);
mu_s_cartel = PjYj_cartel' ./ Labor_cartel';
ee_cartel = ee;