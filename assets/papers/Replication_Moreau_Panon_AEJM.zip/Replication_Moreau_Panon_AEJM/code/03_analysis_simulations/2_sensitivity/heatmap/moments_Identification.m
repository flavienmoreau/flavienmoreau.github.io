%% Moments Calculation
% This script computes model moments for calibration and identification

%% Block 1: Aggregate Markup
Block1 = [muagg];

%% Block 2: Median Number of Firms per Sector
median_number_firms = sum(phi, 'omitnan');
median_number_firms = median(median_number_firms(median_number_firms > 0), 'omitnan');

Block2 = [median_number_firms];

%% Block 3: Median Number of Cartel Members
median_members = mean(n_c(n_c > 0));

Block3 = [median_members];

%% Block 4: Concentration Ratios Within Industries (CR4, CR20)
sales = p_i_cartel .* yy_cartel .* (phi);
total_sales = sum(sales, 'omitnan');
m_share = sales ./ repmat(total_sales, N, 1);

concentration_ratio4 = sum(m_share(1:4, :), 1, 'omitnan');
concentration_ratio4(concentration_ratio4 == 0) = NaN;

concentration_ratio20 = sum(m_share(1:20, :), 1, 'omitnan');
concentration_ratio20(concentration_ratio20 == 0) = NaN;

total_sales_economy = sum(total_sales, 'omitnan') * ones(1, S);
industry_domar_weights = total_sales ./ total_sales_economy;
industry_domar_weights(industry_domar_weights == 0) = NaN;
sanity_domar_weights = sum(industry_domar_weights, 'omitnan');
clear sanity_domar_weights;

concentration_ratio4_product = concentration_ratio4 .* industry_domar_weights;
concentration_ratio4_final = sum(concentration_ratio4_product, 'omitnan');

concentration_ratio20_product = concentration_ratio20 .* industry_domar_weights;
concentration_ratio20_final = sum(concentration_ratio20_product, 'omitnan');

clear concentration_ratio4_product concentration_ratio20_product concentration_ratio4 concentration_ratio20;

Block4 = [concentration_ratio4_final, concentration_ratio20_final];
clear concentration_ratio4_final concentration_ratio20_final;

%% Block 5: Concentration Ratios Across Sectors (CR4, CR20)
industry_domar_weights_cr_sectors = industry_domar_weights';
industry_domar_weights_cr_sectors = sort(industry_domar_weights_cr_sectors, 1, 'descend');
industry_domar_weights_cr_sectors = industry_domar_weights_cr_sectors(~isnan(industry_domar_weights_cr_sectors));

cr4_across_sectors_final = sum(industry_domar_weights_cr_sectors(1:4, :), 1, 'omitnan');
cr20_across_sectors_final = sum(industry_domar_weights_cr_sectors(1:20, :), 1, 'omitnan');

Block5 = [cr4_across_sectors_final, cr20_across_sectors_final];

%% Block 6: Sum of Regression Coefficients (Cartel Slope)
sum_ms_cartel = cartel .* market_share_imperfect_collusion;
sum_ms_cartel = nansum(sum_ms_cartel);
sum_ms_cartel = repmat(sum_ms_cartel, n_f, 1);
sum_ms_cartel = sum_ms_cartel .* cartel;
sum_ms_cartel(sum_ms_cartel == 0) = NaN;
sum_ms_cartel = sum_ms_cartel(:);
sum_ms_cartel = sum_ms_cartel(all(~isnan(sum_ms_cartel), 2), :);

tempX = cartel(:);
tempX(tempX == 0) = NaN;
market_share_economy_cartel = market_share_imperfect_collusion(:);
market_share_economy_cartel = market_share_economy_cartel .* tempX;
market_share_economy_cartel = market_share_economy_cartel(all(~isnan(market_share_economy_cartel), 2), :);

temp_intercept_cartel = ones(size(market_share_economy_cartel(:, 1)));

tempX_final_cartel = [temp_intercept_cartel market_share_economy_cartel sum_ms_cartel];

tempY_ = cartel .* mu_cartel;
tempY_(tempY_ == 0) = NaN;
tempY_ = tempY_(:);
tempY_ = tempY_(all(~isnan(tempY_), 2), :);
tempY_ = 1 ./ tempY_;

temp_beta_cartel = inv(tempX_final_cartel' * tempX_final_cartel) * tempX_final_cartel' * tempY_;

slope_own_cartel = temp_beta_cartel(2);
slope_total_cartel = temp_beta_cartel(3);
sum_coefficients_cartel = slope_own_cartel + slope_total_cartel;

Block6 = [sum_coefficients_cartel];

%% Compile All Moments
all_model_moments = [Block1; Block6; Block4(1); Block4(2); Block5(1); Block5(2); Block2; Block3]';