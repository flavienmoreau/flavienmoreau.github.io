%% AEJ Macro Replication Package (Moreau and Panon, forthcoming)
% This script reproduces Table E16: Differences with Harberger (1954)

% The table compares productivity gains from eliminating cartels across three models:
%   Column (1) - Benchmark: Full model with firm-level heterogeneity
%   Column (2) - Sectoral level: Harberger-style model with representative firm per sector
%   Column (3) - Unit elastic demand: Model with Cobb-Douglas preferences (rho = eta = 1)

% Required files:
%   - equilibrium_benchmark.m (for Columns 1 & 2)
%   - equilibrium_cartel.m (for Columns 1 & 2)
%   - equilibrium_benchmark_CD.m (for Column 3)
%   - equilibrium_imperfect_collusion_CD.m (for Column 3)

tic
clear;
clc;
diary table_e16.txt
rng('default');  % For reproducibility

fprintf('\n========================================\n');
fprintf('Table E16: Differences with Harberger (1954)\n');
fprintf('========================================\n\n');

%% ============================================================
%  Common Model Parameters
%  ============================================================
n_f = 500;                  % Max number of firms within each sector
S = 670;                    % Number of sectors
L = 1;                      % Inelastic labor supply
nu = 2;                     % Inverse Frisch elasticity of labor supply

% Calibrated parameters (collusion model)
xi = 10.2378007453196;      % Firm productivity Pareto shape parameter
xi_s = 2.80881084697840;    % Sector productivity Pareto shape parameter
zeta = 0.161187916362012;   % Cartel size parameter (geometric distribution)
zeta_f = 0.00407313218542430;  % Number of firms parameter (geometric distribution)
beta = 0.41;                % Collusion intensity
share_cartels = 90;         % Share of cartelized industries (top percentile)

%% ============================================================
%  Generate Productivity Distribution (Common to All Models)
%  ============================================================
N = n_f;
M = S;
alpha = xi;
b = 1;

% Firm-level productivity draws (Pareto distribution)
P = randp(N, M, alpha, b);
z = sort(P, 'descend');

% Sectoral productivity draws (Pareto distribution)
M_s = S;
alpha_s = xi_s;
P_s = randp(1, M_s, alpha_s, b);
z_s = P_s;
clear P_s;

% Combined productivity: firm-level × sector-level
z = bsxfun(@times, z, z_s);

%% ============================================================
%  Generate Firm Distribution Across Sectors
%  ============================================================
nn = geornd(zeta_f, S, 1);  % Number of firms per sector (geometric distribution)
nn(nn == 0) = 178;          % Replace 0s with median value
nn(nn > n_f) = n_f;         % Cap at maximum number of firms
nn(nn == 1) = 2;            % Minimum of 2 firms for potential collusion

% Create firm activity matrix (phi = 1 if firm is active)
phi = zeros(N, S);
for i = 1:S
    temp = zeros(N, 1);
    temp(1:nn(i)) = 1;
    temp = temp(randperm(N));
    phi(:, i) = temp;
end

phi = sort(phi, 1, 'descend');
z = z .* phi + eps .* (1 - phi);  % Inactive firms get negligible productivity
z = sort(z, 1, 'descend');
phi(phi == 0) = NaN;

% Store original productivity matrix for reuse
z_original = z;
phi_original = phi;

%% ============================================================
%  Generate Cartel Structure
%  ============================================================
% Identify cartelized industries (sectors with high productivity draws)
treated_ind_threshold = prctile(z_s, share_cartels);
treated_ind_top = z_s >= treated_ind_threshold;
collusive_ind = double(treated_ind_top');

% Determine number of cartel members per industry
n_c = zeros(S, 1);
for s = 1:S
    if collusive_ind(s, 1) == 1
        n_c(s) = geornd(zeta, 1, 1);
    end
end

n_c((n_c == 0) & (collusive_ind == 1)) = 4;  % Assign median cartel size when draw is 0
n_c(n_c == 1) = 2;                            % Cartels must have at least 2 members

% Ensure cartel size doesn't exceed number of firms in sector
dummy = n_c > nn;
n_c(dummy) = nn(dummy);

collusive_ind_final = n_c > 0;

% Create cartel membership matrix (cartel = 1 if firm is cartel member)
cartel = zeros(n_f, S);
for i = 1:S
    cartel_temp = ones(n_c(i, 1), 1);
    cartel_temp(n_f, 1) = 0;
    cartel(:, i) = cartel_temp;
end
clear cartel_temp;

%% ############################################################
%  COLUMNS (1) & (2): BENCHMARK AND SECTORAL LEVEL
%  Using standard CES equilibrium files
%  ############################################################
fprintf('Computing Columns (1) & (2): Benchmark and Sectoral Level...\n');

% Reset productivity matrix
z = z_original;
phi = phi_original;

% Benchmark elasticities (CES)
rho = 12.0564816759752;
eta = 3.10040889831152;

% --- Compute equilibrium without cartels (CES) ---
equilibrium_benchmark;

mu_no_cartel = mu;
p_i_no_cartel = p_i;
p_s_no_cartel = p_s;
A_no_cartel = A;
muagg_no_cartel = muagg;
omega_no_cartel = omega;

save no_cartel mu_no_cartel p_i_no_cartel p_s_no_cartel A_no_cartel muagg_no_cartel omega_no_cartel profit_no_cartel

% --- Compute equilibrium with cartels (CES) ---
equilibrium_cartel;

mu_cartel = mu;
p_i_cartel = p_i;
A_cartel = A;
p_s_cartel = p_s;

load no_cartel
delete no_cartel.mat

% Column (1): Benchmark productivity gain
A_loss_cartel = log(A_cartel / A_no_cartel) * 100;
A_gain_benchmark = -A_loss_cartel;  % Convert loss to gain

%% Column (2): Sectoral Level (Harberger-style)
% Compute harmonic averages to collapse within-sector heterogeneity

z_harmonic = nanmean(z.^(-1)).^(-1);  % Harmonic average of productivities within sectors

% No-cartel equilibrium (sectoral)
p_i_new_no_cartel = nanmean((p_i_no_cartel).^(-1)).^(-1);  % Harmonic average of prices
p_s_new_no_cartel = p_i_new_no_cartel;  % With one representative firm, p_s = p_i
P_new_no_cartel = (nanmean(p_s_new_no_cartel.^(1-eta))).^(1/(1-eta));
A_new_no_cartel = nanmean(z_harmonic.^(-1) .* (p_i_new_no_cartel./p_s_new_no_cartel).^(-rho) .* (p_s_new_no_cartel/P_new_no_cartel).^(-eta)).^(-1);

% Cartel equilibrium (sectoral)
p_i_new_cartel = nanmean((p_i_cartel).^(-1)).^(-1);  % Harmonic average of prices
p_s_new_cartel = p_i_new_cartel;  % With one representative firm, p_s = p_i
P_new_cartel = (nanmean(p_s_new_cartel.^(1-eta))).^(1/(1-eta));
A_new_cartel = nanmean(z_harmonic.^(-1) .* (p_i_new_cartel./p_s_new_cartel).^(-rho) .* (p_s_new_cartel/P_new_cartel).^(-eta)).^(-1);

% Sectoral productivity loss/gain
A_loss_cartel_sectoral = log(A_new_cartel / A_new_no_cartel) * 100;
A_gain_sectoral = -A_loss_cartel_sectoral;  % Convert loss to gain

%% ############################################################
%  COLUMN (3): UNIT ELASTIC DEMAND (COBB-DOUGLAS)
%  Using Cobb-Douglas equilibrium files with weight_CD
%  ############################################################
fprintf('Computing Column (3): Unit Elastic Demand...\n');

% Reset productivity matrix
z = z_original;
phi = phi_original;

% Unit elastic demand: rho -> 1, eta = 1 (Cobb-Douglas preferences)
rho = 1.0000000001;
eta = 1;

% Equal sector weights for Cobb-Douglas aggregator
weight_CD = ones(1, S);
weight_CD = (1/S) * weight_CD;

% --- Compute equilibrium without cartels (Cobb-Douglas) ---
equilibrium_benchmark_CD;

mu_no_cartel_unit = mu;
p_i_no_cartel_unit = p_i;
A_no_cartel_unit = A;
muagg_no_cartel_unit = muagg;

save no_cartel_unit mu_no_cartel_unit p_i_no_cartel_unit A_no_cartel_unit muagg_no_cartel_unit profit_no_cartel

% --- Compute equilibrium with cartels (Cobb-Douglas) ---
equilibrium_imperfect_collusion_CD;

mu_cartel_unit = mu;
p_i_cartel_unit = p_i;
A_cartel_unit = A;
muagg_cartel_unit = muagg;

load no_cartel_unit
delete no_cartel_unit.mat

% Column (3): Unit elastic productivity gain
A_loss_unit = log(A_cartel_unit / A_no_cartel_unit) * 100;
A_gain_unit_elastic = -A_loss_unit;  % Convert loss to gain

%% ============================================================
%  Display Table E16: Differences with Harberger (1954)
%  ============================================================
fprintf('\n');
fprintf('=====================================================================\n');
fprintf('          Table E16: Differences with Harberger (1954)\n');
fprintf('=====================================================================\n');
fprintf('                              Benchmark   Sectoral level   Unit elastic demand\n');
fprintf('                                 (1)           (2)               (3)\n');
fprintf('---------------------------------------------------------------------\n');
fprintf('A_cartel -> A_comp (in %%)       %5.2f         %5.2f              %5.2f\n', ...
        A_gain_benchmark, A_gain_sectoral, A_gain_unit_elastic);
fprintf('=====================================================================\n');

%% ============================================================
%  Additional Diagnostics
%  ============================================================
fprintf('\n');
fprintf('--- Check ---\n');
fprintf('Share of cartelized sectors              = %7.3f\n', sum(collusive_ind_final) / S);

fprintf('\n');
elapsed_time = toc;

diary off
fprintf('Elapsed time: %.2f seconds\n', elapsed_time);
