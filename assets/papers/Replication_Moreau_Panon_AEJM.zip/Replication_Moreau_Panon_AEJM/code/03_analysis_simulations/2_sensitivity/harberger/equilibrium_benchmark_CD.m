%% Equilibrium Benchmark (No Cartels) - Cobb-Douglas Version
% Uses weight_CD for Cobb-Douglas aggregation

z = z.*phi;

p_i  = rho/(rho-1)./z;                     % Price of a firm
p_s  = (nanmean(p_i.^(1-rho))).^(1/(1-rho));  % Sectoral price index

P = p_s.^weight_CD;                                % Aggregate price
P(isnan(P))= [] ;                             % Remove nan columns
P = prod(P);                                  % Take the product of each column

A  = nanmean(nanmean(z.^(-1).*repmat(weight_CD, n_f, 1).*(p_i./repmat(p_s,n_f,1)).^(-rho).*repmat((p_s)/(P), n_f,1).^(-eta))).^(-1); % Aggregate productivity
     
Y     = A*L; % Aggregate output
Yold  = Y;

omegaold  =  ((p_i./repmat(p_s,n_f,1)).^(1-rho))./(repmat(nn', n_f, 1));  % Market share (need to make it a matrix using repmat)
yyold      = (p_i./repmat(p_s,n_f,1)).^(-rho).*(repmat(p_s,n_f,1)./(P)).^(-eta).*Y.*repmat(weight_CD, n_f, 1); 

omegaold_cum = nansum(omegaold);              % Check market shares add up to one           

%% Solve the model numerically

for it = 1 : 500

Y      = Yold;  
omega  = omegaold;
yy     = yyold;

p_i  = (rho./(rho-1 - (rho-1).*omega))./z;

p_s              = nanmean(p_i.^(1-rho)).^(1/(1-rho));
p_s(isinf(p_s))   = 10^16;

P = p_s.^weight_CD;                                % Aggregate price
P(isnan(P))= [] ;                             % Remove nan columns
P = prod(P);                                  % Take the product of each column

omega = (bsxfun(@times, p_i.^(1-rho), p_s.^(rho-1)))./(repmat(nn', n_f, 1)); % "bsxfun": Directly divides numerator by price index

yy = bsxfun(@times, p_i.^(-rho), p_s.^(rho-1).*P.^eta.*Y.*weight_CD); % Comes from FOCs

omega = real(omega);
yy    = real(yy); 

A  = nanmean(nanmean(phi.*z.^(-1).*yy/Y)).^(-1);   
Y     = A*(L);

error = max([norm(omega - omegaold); norm(Y-Yold)]);

rem = mod(it,10);
if rem == 1
    fprintf('%4i %6.2e \n',[it, error]);
end

if error < 1e-7, break, end
    
Yold         = 1/2*Y      +  1/2*Yold;
omegaold     = 1/10*omega +  9/10*omegaold;
yyold        = 1/10*yy    +  9/10*yyold;

end

ll = yy./z;

if norm(omega-omegaold)>1e-3
    disp('Warning: omega has not converged')
end

mu  = rho./(rho-1 - (rho-1).*omega); 
muagg   = P*A;

profit_no_cartel = (p_i - 1./z).*yy;

yy_no_cartel = yy;

Labor   = sum(ll); 
PjYj = sum(p_i.*yy); 
muj  = PjYj'./Labor';
