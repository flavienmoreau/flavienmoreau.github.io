%% AEJ Macro Replication Package (Moreau and Panon, forthcoming)
% This script reproduces:
% 1) Table E18: Calibration - Cartels in 1995 and 2007 (Targeted & Untargeted Moments)
% 2) Table 9: Gains from Breaking Down Cartels in 1995 and 2007

tic
clear;
clc;
diary tables_9_e18.txt
rng('default');  % For reproducibility

%% ============================================================
%  USER INPUT: Select which years to run
%  ============================================================
%  Options: '1995', '2007', or 'both'

run_years = 'both';  % <-- CHANGE THIS TO '1995', '2007', or 'both'

%% ============================================================
%  Setup Year List
%  ============================================================
if strcmp(run_years, 'both')
    years_to_run = [1995, 2007];
elseif strcmp(run_years, '1995')
    years_to_run = 1995;
elseif strcmp(run_years, '2007')
    years_to_run = 2007;
else
    error('Invalid run_years. Must be ''1995'', ''2007'', or ''both''');
end

results = struct();

%% ============================================================
%  Define Year-Specific Parameters
%  ============================================================
params_1995.S = 647;                % Number of industries in France in 1995
params_1995.rho = 19.6180646971918;
params_1995.eta = 3.43895511460369;
params_1995.xi = 17.7206132413477;
params_1995.xi_s = 4.15600394312617;
params_1995.zeta = 0.177547508476870;
params_1995.zeta_f = 0.00420772531586053;
params_1995.specific_numbers = [1, 2, 7, 12, 17, 18, 19, 22, 23, 24, 28, 29, 30, 32, 36, 39, 40, 46, 48, 60, 66, 69, 71, 76, 81, 107, 110, 112, 114, 119, 123, 126, 129, 155, 176, 178, 179, 188, 193, 200, 202, 207, 211, 213, 216, 218, 219, 222, 229, 231, 241, 243, 245, 248, 254, 256, 258, 263, 271, 274, 300, 311, 322, 324, 338, 367, 372, 375, 405, 407, 408, 412, 430, 440, 455, 459, 481, 499, 500, 501, 563, 612];

params_2007.S = 670;                % Number of industries in France in 2007
params_2007.rho = 11.0366891039573;
params_2007.eta = 3.02528838055022;
params_2007.xi = 9.81502088925834;
params_2007.xi_s = 2.73986293967842;
params_2007.zeta = 0.166853254794781;
params_2007.zeta_f = 0.00413847295682346;
params_2007.specific_numbers = [5, 15, 20, 26, 30, 31, 36, 37, 42, 43, 45, 57, 67, 72, 76, 87, 105, 119, 120, 154, 198, 217, 233, 234, 258, 266, 457, 470, 484, 625];

% Common parameters
n_f = 500;
N = n_f;
L = 1;
nu = 2;
beta = 0.41;
b = 1;

%% ============================================================
%  Main Loop Over Years
%  ============================================================
for y = 1:length(years_to_run)
    
    year = years_to_run(y);
    year_label = num2str(year);
    
    fprintf('\n');
    fprintf('########################################################\n');
    fprintf('#                    %d CALIBRATION                   #\n', year);
    fprintf('########################################################\n');
    fprintf('\n');
    
    rng('default');  % Reset RNG for reproducibility
    
    %% Load Year-Specific Parameters
    if year == 1995
        p = params_1995;
    else
        p = params_2007;
    end
    
    S = p.S;
    rho = p.rho;
    eta = p.eta;
    xi = p.xi;
    xi_s = p.xi_s;
    zeta = p.zeta;
    zeta_f = p.zeta_f;
    specific_numbers = p.specific_numbers;
    
    %% Generate Productivity Distribution
    M = S;
    alpha = xi;
    P = randp(N, M, alpha, b);
    z = sort(P, 'descend');
    
    % Sectoral draws
    alpha_s = xi_s;
    P_s = randp(1, S, alpha_s, b);
    z_s = P_s;
    
    % Combined productivity: firm � sector
    z = bsxfun(@times, z, z_s);
    
    %% Generate Firm Distribution Across Sectors
    nn = geornd(zeta_f, S, 1);
    nn(nn == 0) = 178;
    nn(nn > n_f) = n_f;
    nn(nn == 1) = 2;
    
    phi = zeros(N, S);
    for i = 1:S
        temp = zeros(N, 1);
        temp(1:nn(i)) = 1;
        temp = temp(randperm(N));
        phi(:, i) = temp;
    end
    
    phi = sort(phi, 1, 'descend');
    z = z .* phi + eps .* (1 - phi);
    z = sort(z, 1, 'descend');
    phi(phi == 0) = NaN;
    
    %% Generate Cartel Structure
    [~, sortedIndices] = sort(z_s, 'descend');
    rankingVector = zeros(size(z_s));
    for i = 1:length(sortedIndices)
        rankingVector(sortedIndices(i)) = i;
    end
    
    collusive_ind = zeros(size(rankingVector));
    for i = 1:length(specific_numbers)
        collusive_ind(rankingVector == specific_numbers(i)) = 1;
    end
    collusive_ind = collusive_ind';
    
    n_c = zeros(S, 1);
    for s = 1:S
        if collusive_ind(s, 1) == 1
            n_c(s) = geornd(zeta, 1, 1);
        end
    end
    
    n_c((n_c == 0) & (collusive_ind == 1)) = 4;
    n_c(n_c == 1) = 2;
    dummy = n_c > nn;
    n_c(dummy) = nn(dummy);
    collusive_ind_final = n_c > 0;
    
    cartel = zeros(n_f, S);
    for i = 1:S
        cartel_temp = ones(n_c(i, 1), 1);
        cartel_temp(n_f, 1) = 0;
        cartel(:, i) = cartel_temp;
    end
    
    %% Compute Benchmark Equilibrium (No Cartels)
    fprintf('Computing Equilibrium without Cartels (%d)\n', year);
    
    equilibrium_benchmark;
    
    mu_no_cartel = mu;
    p_i_no_cartel = p_i;
    p_s_no_cartel = p_s;
    A_no_cartel = A;
    muagg_no_cartel = muagg;
    omega_no_cartel = omega;
    
    save no_cartel mu_no_cartel p_i_no_cartel p_s_no_cartel A_no_cartel muagg_no_cartel omega_no_cartel profit_no_cartel
    
    %% Compute Collusion Equilibrium
    fprintf('Computing Equilibrium with Cartels (%d)\n', year);
    
    equilibrium_imperfect_collusion;
    
    mu_cartel = mu;
    p_i_cartel = p_i;
    A_cartel = A;
    p_s_cartel = p_s;
    clear mu p_i A p_s
    
    load no_cartel
    delete no_cartel.mat
    
    omega_cartel = omega;
    clear omega;
    
    %% Compute Welfare Metrics
    A_loss_cartel = (A_cartel / A_no_cartel - 1) * 100;
    
    A_s_eff = nanmean(z.^(rho-1)).^(1/(rho-1));
    A_eff = nanmean(A_s_eff.^(eta-1)).^(1/(eta-1));
    A_loss_efficient = (A_cartel / A_eff - 1) * 100;
    
    check_shares = sum(market_share_imperfect_collusion, 'omitnan'); % Check market shares add up to one
    check_shares(check_shares == 0) = NaN;
    
    markup_increase = ((mu_cartel ./ mu_no_cartel) - 1) * 100;
    
    p_s_cartel = (nansum(p_i_cartel.^(1-rho))).^(1/(1-rho));
    p_s_no_cartel = (nansum(p_i_no_cartel.^(1-rho))).^(1/(1-rho));
    
    profit_growth = ((profit_cartel ./ profit_no_cartel) - 1) * 100;
    
    welfare_static = ((A_cartel/A_no_cartel) .* (muagg/muagg_no_cartel).^(-1/(1+nu)) - 1) .* 100;
    welfare_efficient = ((A_cartel/A_eff) .* (muagg).^(-1/(1+nu)) - 1) .* 100;
    
    %% Display Results
    fprintf('\n========================================\n');
    fprintf('%d RESULTS\n', year);
    fprintf('========================================\n');
    fprintf('A loss (loss from no cartel), *100           = %7.2f \n', A_loss_cartel);
    fprintf('A loss (loss wrt efficient economy), *100    = %7.2f \n', A_loss_efficient);
    fprintf('A increased distance (wrt efficient), *100   = %7.2f \n', (A_loss_cartel/A_loss_efficient)*100);
    fprintf('Markup increase, points                      = %7.2f \n', (muagg - muagg_no_cartel)*100);
    fprintf('Static welfare loss (loss from cartels), *100= %7.2f \n', welfare_static);
    fprintf('Static welfare loss (wrt efficient), *100    = %7.2f \n', welfare_efficient);
    fprintf('Check on market shares                       = %7.3f \n', nanmean(check_shares));
    fprintf('Share cartelized sectors                     = %7.3f \n', sum(collusive_ind_final)./S);
    
    %% Compute and Display Moments
    moments_1995_2007;
    
    %% Store Results
    year_field = ['year_' year_label];
    results.(year_field).params.rho = rho;
    results.(year_field).params.eta = eta;
    results.(year_field).params.xi = xi;
    results.(year_field).params.xi_s = xi_s;
    results.(year_field).params.zeta = zeta;
    results.(year_field).params.zeta_f = zeta_f;
    results.(year_field).params.beta = beta;
    results.(year_field).params.nu = nu;
    
    results.(year_field).moments = model_moments;
    results.(year_field).untargeted = untargeted_moments;
    
    results.(year_field).welfare.A_cartel = A_cartel;
    results.(year_field).welfare.A_no_cartel = A_no_cartel;
    results.(year_field).welfare.A_eff = A_eff;
    results.(year_field).welfare.A_gain = -A_loss_cartel;
    results.(year_field).welfare.distance_to_efficient = (A_loss_cartel/A_loss_efficient)*100;
    results.(year_field).welfare.markup_change = (muagg - muagg_no_cartel)*100;
    results.(year_field).welfare.welfare_gain = -welfare_static;
    
    fprintf('\n%d calibration completed.\n', year);
    
end

%% ########################################################
%                   SUMMARY TABLES                      
%  ########################################################
if strcmp(run_years, 'both')
    
    fprintf('\n');
    fprintf('########################################################\n');
    fprintf('#                   SUMMARY TABLES                      #\n');
    fprintf('########################################################\n');
    
    %% TABLE E18
    fprintf('\n');
    fprintf('============================================================\n');
    fprintf('TABLE E18: Calibration - Cartels in 1995 and 2007\n');
    fprintf('============================================================\n');
    fprintf('\n');
    
    temp_data = load('data_moments_1995.mat');
    if isfield(temp_data, 'all_data_moments_1995')
        data_1995 = temp_data.all_data_moments_1995;
    else
        data_1995 = temp_data.all_data_moments;
    end
    
    temp_data = load('data_moments_2007.mat');
    if isfield(temp_data, 'all_data_moments_2007')
        data_2007 = temp_data.all_data_moments_2007;
    else
        data_2007 = temp_data.all_data_moments;
    end
    clear temp_data;
    
    fprintf('Panel A. Targets\n');
    fprintf('--------------------------------------------------------------------\n');
    fprintf('%-35s %10s %12s %12s %12s\n', 'Moments', 'Data(1995)', 'Model(1995)', 'Data(2007)', 'Model(2007)');
    fprintf('--------------------------------------------------------------------\n');
    
    fprintf('%-35s %10.2f %12.2f %12.2f %12.2f\n', 'Aggregate markup', ...
        data_1995(1), results.year_1995.moments.aggregate_markup, ...
        data_2007(1), results.year_2007.moments.aggregate_markup);
    fprintf('%-35s %10.2f %12.2f %12.2f %12.2f\n', 'Slope parameter', ...
        data_1995(2), results.year_1995.moments.slope, ...
        data_2007(2), results.year_2007.moments.slope);
    fprintf('%-35s %10.2f %12.2f %12.2f %12.2f\n', 'Top-4 sales share, within-sector', ...
        data_1995(3), results.year_1995.moments.cr4_within, ...
        data_2007(3), results.year_2007.moments.cr4_within);
    fprintf('%-35s %10.2f %12.2f %12.2f %12.2f\n', 'Top-20 sales share, within-sector', ...
        data_1995(4), results.year_1995.moments.cr20_within, ...
        data_2007(4), results.year_2007.moments.cr20_within);
    fprintf('%-35s %10.2f %12.2f %12.2f %12.2f\n', 'Top-4 sales share, across-sector', ...
        data_1995(5), results.year_1995.moments.cr4_across, ...
        data_2007(5), results.year_2007.moments.cr4_across);
    fprintf('%-35s %10.2f %12.2f %12.2f %12.2f\n', 'Top-20 sales share, across-sector', ...
        data_1995(6), results.year_1995.moments.cr20_across, ...
        data_2007(6), results.year_2007.moments.cr20_across);
    fprintf('%-35s %10.0f %12.0f %12.0f %12.0f\n', 'Median # firms per sector', ...
        data_1995(7), results.year_1995.moments.median_firms, ...
        data_2007(7), results.year_2007.moments.median_firms);
    fprintf('%-35s %10.0f %12.0f %12.0f %12.0f\n', 'Median # members per cartel', ...
        data_1995(8), results.year_1995.moments.median_cartel_members, ...
        data_2007(8), results.year_2007.moments.median_cartel_members);
    
    fprintf('\n');
    fprintf('Panel B. Parameters\n');
    fprintf('--------------------------------------------------------------------\n');
    fprintf('%-35s %23s %25s\n', '', '1995', '2007');
    fprintf('--------------------------------------------------------------------\n');
    
    fprintf('%-35s %23.2f %25.2f\n', 'Substitution within sectors', ...
        results.year_1995.params.rho, results.year_2007.params.rho);
    fprintf('%-35s %23.2f %25.2f\n', 'Substitution between sectors', ...
        results.year_1995.params.eta, results.year_2007.params.eta);
    fprintf('%-35s %23.2f %25.2f\n', 'Pareto shape, firms', ...
        results.year_1995.params.xi, results.year_2007.params.xi);
    fprintf('%-35s %23.2f %25.2f\n', 'Pareto shape, sectors', ...
        results.year_1995.params.xi_s, results.year_2007.params.xi_s);
    fprintf('%-35s %23.3f %25.3f\n', 'Geometric, firms', ...
        results.year_1995.params.zeta_f, results.year_2007.params.zeta_f);
    fprintf('%-35s %23.2f %25.2f\n', 'Geometric, cartel members', ...
        results.year_1995.params.zeta, results.year_2007.params.zeta);
    fprintf('%-35s %23.2f %25.2f\n', 'Collusion intensity', ...
        results.year_1995.params.beta, results.year_2007.params.beta);
    fprintf('%-35s %23.0f %25.0f\n', 'Inverse Frisch elasticity', ...
        results.year_1995.params.nu, results.year_2007.params.nu);
    
    %% TABLE 9
    fprintf('\n\n');
    fprintf('============================================================\n');
    fprintf('TABLE 9: Gains from Breaking Down Cartels in 1995 and 2007\n');
    fprintf('============================================================\n');
    fprintf('\n');
    
    fprintf('%-45s %12s %12s\n', 'Year:', '1995', '2007');
    fprintf('%-45s %12s %12s\n', '', '(1)', '(2)');
    fprintf('--------------------------------------------------------------------\n');
    
    fprintf('\n');
    fprintf('Panel A: Aggregate productivity gains, %%\n');
    fprintf('%-45s %12.2f %12.2f\n', 'A_cartel -> A_comp', ...
        results.year_1995.welfare.A_gain, results.year_2007.welfare.A_gain);
    fprintf('%-45s %12.2f %12.2f\n', 'Distance to efficient allocation', ...
        -results.year_1995.welfare.distance_to_efficient, -results.year_2007.welfare.distance_to_efficient);
    
    fprintf('\n');
    fprintf('Panel B: Aggregate welfare gains\n');
    fprintf('%-45s %12.2f %12.2f\n', 'M_cartel -> M_comp (in pp)', ...
        -results.year_1995.welfare.markup_change, -results.year_2007.welfare.markup_change);
    fprintf('%-45s %12.2f %12.2f\n', 'W_cartel -> W_comp (in %%)', ...
        results.year_1995.welfare.welfare_gain, results.year_2007.welfare.welfare_gain);
    
    %% UNTARGETED MOMENTS
    % Only report cartelized industry slope since this is the only moment
    % mentioned in the text. Uncomment other moments if needed
    fprintf('\n\n');
    fprintf('============================================================\n');
    fprintf('UNTARGETED MOMENTS\n');
    fprintf('============================================================\n');
    fprintf('\n');
    
    fprintf('%-45s %12s %12s\n', '', '1995', '2007');
    fprintf('--------------------------------------------------------------------\n');
    
    fprintf('%-45s %12.2f %12.2f\n', 'Cartelized industry slope', ...
        results.year_1995.untargeted.cartelized_industry_slope, ...
        results.year_2007.untargeted.cartelized_industry_slope);
    %fprintf('%-45s %12.2f %12.2f\n', 'Average cartel premium (sales)', ...
    %    results.year_1995.untargeted.cartel_premium_sales, ...
    %    results.year_2007.untargeted.cartel_premium_sales);
    %fprintf('%-45s %12.2f %12.2f\n', 'Average cartel premium (employment)', ...
    %    results.year_1995.untargeted.cartel_premium_employment, ...
    %    results.year_2007.untargeted.cartel_premium_employment);
    %fprintf('%-45s %12.2f %12.2f\n', 'Average cartel premium (labor productivity)', ...
    %    results.year_1995.untargeted.cartel_premium_tfpl, ...
    %    results.year_2007.untargeted.cartel_premium_tfpl);
    %fprintf('%-45s %12.2f %12.2f\n', 'Average cartel premium (market share)', ...
    %    results.year_1995.untargeted.cartel_premium_market_share, ...
    %    results.year_2007.untargeted.cartel_premium_market_share);
    %fprintf('%-45s %12.2f %12.2f\n', 'Standard deviation of log sales', ...
    %    results.year_1995.untargeted.std_log_sales, ...
    %    results.year_2007.untargeted.std_log_sales);
    %fprintf('%-45s %12.2f %12.2f\n', 'Standard deviation of log employment', ...
    %    results.year_1995.untargeted.std_log_employment, ...
    %    results.year_2007.untargeted.std_log_employment);
    %fprintf('%-45s %12.2f %12.2f\n', 'Average overcharge (in %%)', ...
    %    results.year_1995.untargeted.mean_overcharge, ...
    %    results.year_2007.untargeted.mean_overcharge);
    
end

%% Save Results
save('results_1995_2007.mat', 'results');
fprintf('\n');
fprintf('Results saved to results_1995_2007.mat\n');

diary off
toc;