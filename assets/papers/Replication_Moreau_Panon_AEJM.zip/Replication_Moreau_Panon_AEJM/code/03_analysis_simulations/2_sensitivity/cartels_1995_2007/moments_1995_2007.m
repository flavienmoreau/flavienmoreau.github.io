%% Computes model moments for cartel calibration (1995 and 2007)
% This script is called by start_collusion_1995_2007.m
% Requires: year_label variable to be set ('1995' or '2007')

fprintf('\n');
fprintf('Computing moments for %s...\n', year_label);

%% ============================================================
%  Load Data Moments
%  ============================================================
if strcmp(year_label, '1995')
    temp_data = load('data_moments_1995.mat');
    if isfield(temp_data, 'all_data_moments_1995')
        all_data_moments = temp_data.all_data_moments_1995;
    else
        all_data_moments = temp_data.all_data_moments;
    end
else  % 2007
    temp_data = load('data_moments_2007.mat');
    if isfield(temp_data, 'all_data_moments_2007')
        all_data_moments = temp_data.all_data_moments_2007;
    else
        all_data_moments = temp_data.all_data_moments;
    end
end
clear temp_data;

%% ============================================================
%  Block #1: Aggregate Markup
%  ============================================================
Block1 = muagg;

%% ============================================================
%  Block #2: Median Number of Cartel Members
%  ============================================================
median_members = median(n_c(n_c > 0));
Block2 = median_members;

%% ============================================================
%  Block #3: Median Number of Firms per Sector
%  ============================================================
median_number_firms = sum(phi, 'omitnan');
median_number_firms = median(median_number_firms(median_number_firms > 0), 'omitnan');
Block3 = median_number_firms;

%% ============================================================
%  Block #4: Concentration Ratios Within Industries (CR4, CR20)
%  ============================================================
sales = p_i_cartel .* yy_cartel .* phi;
total_sales = sum(sales, 'omitnan');
m_share = sales ./ repmat(total_sales, N, 1);

% Top 4 and Top 20 concentration ratios
concentration_ratio4 = sum(m_share(1:4, :), 1, 'omitnan');
concentration_ratio4(concentration_ratio4 == 0) = NaN;

concentration_ratio20 = sum(m_share(1:20, :), 1, 'omitnan');
concentration_ratio20(concentration_ratio20 == 0) = NaN;

% Weight by sales share (Domar weights)
total_sales_economy = sum(total_sales, 'omitnan') * ones(1, S);
industry_domar_weights = total_sales ./ total_sales_economy;
industry_domar_weights(industry_domar_weights == 0) = NaN;

concentration_ratio4_product = concentration_ratio4 .* industry_domar_weights;
concentration_ratio4_final = sum(concentration_ratio4_product, 'omitnan');

concentration_ratio20_product = concentration_ratio20 .* industry_domar_weights;
concentration_ratio20_final = sum(concentration_ratio20_product, 'omitnan');

Block4 = [concentration_ratio4_final, concentration_ratio20_final];

%% ============================================================
%  Block #5: Concentration Ratios Across Sectors (CR4, CR20)
%  ============================================================
industry_domar_weights_cr_sectors = industry_domar_weights';
industry_domar_weights_cr_sectors = sort(industry_domar_weights_cr_sectors, 1, 'descend');
industry_domar_weights_cr_sectors = industry_domar_weights_cr_sectors(~isnan(industry_domar_weights_cr_sectors));

cr4_across_sectors_final = sum(industry_domar_weights_cr_sectors(1:4, :), 1, 'omitnan');
cr20_across_sectors_final = sum(industry_domar_weights_cr_sectors(1:20, :), 1, 'omitnan');

Block5 = [cr4_across_sectors_final, cr20_across_sectors_final];

%% ============================================================
%  Block #6: Regression Slope Coefficients (sum of own + total)
%  ============================================================
sum_ms_cartel = cartel .* market_share_imperfect_collusion;
sum_ms_cartel = nansum(sum_ms_cartel);
sum_ms_cartel = repmat(sum_ms_cartel, n_f, 1);
sum_ms_cartel = sum_ms_cartel .* cartel;
sum_ms_cartel(sum_ms_cartel == 0) = NaN;
sum_ms_cartel = sum_ms_cartel(:);
sum_ms_cartel = sum_ms_cartel(all(~isnan(sum_ms_cartel), 2), :);

tempX = cartel(:);
tempX(tempX == 0) = NaN;
market_share_economy_cartel = market_share_imperfect_collusion(:);
market_share_economy_cartel = market_share_economy_cartel .* tempX;
market_share_economy_cartel = market_share_economy_cartel(all(~isnan(market_share_economy_cartel), 2), :);

temp_intercept_cartel = ones(size(market_share_economy_cartel(:, 1)));
tempX_final_cartel = [temp_intercept_cartel market_share_economy_cartel sum_ms_cartel];

tempY_ = cartel .* mu_cartel;
tempY_(tempY_ == 0) = NaN;
tempY_ = tempY_(:);
tempY_ = tempY_(all(~isnan(tempY_), 2), :);
tempY_ = 1 ./ tempY_;

temp_beta_cartel = inv(tempX_final_cartel' * tempX_final_cartel) * tempX_final_cartel' * tempY_;

slope_own_cartel = temp_beta_cartel(2);
slope_total_cartel = temp_beta_cartel(3);
sum_coefficients_cartel = slope_own_cartel + slope_total_cartel;

Block6 = sum_coefficients_cartel;

%% ============================================================
%  Block #7: Cartel Overcharge
%  ============================================================
cartel_moment = cartel;
cartel_moment(cartel_moment == 0) = NaN;

overcharge_sample = cartel_moment .* markup_increase;
overcharge_sample = overcharge_sample(:);
overcharge_sample = overcharge_sample(all(~isnan(overcharge_sample), 2), :);
mean_overcharge_sample = mean(overcharge_sample);

Block7 = mean_overcharge_sample;

%% ============================================================
%  Compile Targeted Moments
%  ============================================================
Block1 = round(Block1, 3);
Block2 = round(Block2, 3);
Block3 = round(Block3, 0);
Block4 = round(Block4, 2);
Block5 = round(Block5, 2);
Block6 = round(Block6, 2);
Block7 = round(Block7, 2);

% Store in structure for output
model_moments.aggregate_markup = Block1;
model_moments.slope = Block6;
model_moments.cr4_within = Block4(1);
model_moments.cr20_within = Block4(2);
model_moments.cr4_across = Block5(1);
model_moments.cr20_across = Block5(2);
model_moments.median_firms = Block3;
model_moments.median_cartel_members = Block2;

%% ============================================================
%  Display Targeted Moments Table
%  ============================================================
fprintf('\n');
fprintf('========================================\n');
fprintf('TARGETED MOMENTS (%s)\n', year_label);
fprintf('========================================\n');

MomName = {'Aggregate Markup'; 'Slope'; 'CR4 within'; 'CR20 within';...
           'CR4 across'; 'CR20 across'; 'Median Nbr. Firms Sector'; 'Median Nbr. Members Cartel'};

all_model_moments = [Block1; Block6; Block4(1); Block4(2); Block5(1); Block5(2); Block3; Block2];

T = table(all_data_moments, all_model_moments, 'RowNames', MomName, 'VariableNames', {'Data', 'Model'});
%disp(T);

%% ============================================================
%  Untargeted Moments
%  ============================================================
fprintf('\n');
fprintf('========================================\n');
fprintf('UNTARGETED MOMENTS (%s)\n', year_label);
fprintf('========================================\n\n');

% Compute cartel premia within cartelized industries
cartel_id = phi .* cartel;

Y_variables = {log(p_i_cartel .* yy_cartel .* phi), log(ll .* phi), ...
               log(yy_cartel ./ ll), (market_share_imperfect_collusion * 100) .* phi};

variable_names = {'Sales', 'Employment', 'TFPL', 'Market Share'};
cartel_premiums_all = cell(size(Y_variables));

for v = 1:length(Y_variables)
    cartel_premiums = [];
    
    for s = 1:S
        if collusive_ind_final(s, 1) == 1
            Y_dep = Y_variables{v}(:, s);
            X = [phi(:, s), cartel_id(:, s)];
            
            non_nan_rows_Y = ~isnan(Y_dep);
            non_nan_rows_X = ~any(isnan(X), 2);
            
            Y_dep_clean = Y_dep(non_nan_rows_Y);
            X_clean = X(non_nan_rows_X, :);
            
            [common_rows_Y, common_rows_X] = intersect(find(non_nan_rows_Y), find(non_nan_rows_X));
            Y_dep_reg = Y_dep(common_rows_Y);
            X_reg = X(common_rows_X, :);
            
            if size(X_reg, 1) > 2
                beta_reg = inv(X_reg' * X_reg) * X_reg' * Y_dep_reg;
                cartel_premium_ = beta_reg(2);
                cartel_premiums = [cartel_premiums, cartel_premium_];
            end
        end
    end
    
    cartel_premiums(isinf(cartel_premiums)) = NaN;
    cartel_premiums_all{v} = cartel_premiums;
end

mean_cartel_premiums = cellfun(@nanmean, cartel_premiums_all, 'UniformOutput', false);

% Standard deviations
sales_log = log(p_i_cartel .* yy_cartel .* phi);
tempY_sales = sales_log(:);
tempY_sales = tempY_sales(all(~isnan(tempY_sales), 2), :);

tempY_employment = log(ll .* phi);
tempY_employment = tempY_employment(:);
tempY_employment = tempY_employment(all(~isnan(tempY_employment), 2), :);

% Cross-sectoral regression
temp_ = ones(1, S);
tempX_industry = [temp_' collusive_ind];
tempY_domar_industry = industry_domar_weights' * 100;
coef_reg = inv(tempX_industry' * tempX_industry) * tempX_industry' * tempY_domar_industry;

% Store untargeted moments
untargeted_moments.cartelized_industry_slope = round(coef_reg(2), 2);
untargeted_moments.cartel_premium_sales = round(mean_cartel_premiums{1}, 2);
untargeted_moments.cartel_premium_employment = round(mean_cartel_premiums{2}, 2);
untargeted_moments.cartel_premium_tfpl = round(mean_cartel_premiums{3}, 2);
untargeted_moments.cartel_premium_market_share = round(mean_cartel_premiums{4}, 2);
untargeted_moments.std_log_sales = round(std(tempY_sales), 2);
untargeted_moments.std_log_employment = round(std(tempY_employment), 2);
untargeted_moments.mean_overcharge = round(mean_overcharge_sample, 2);

% Display untargeted moments table
UntargetedMoments = {'Cartelized industry slope'; 'Average cartel premium (sales)'; ...
                     'Average cartel premium (employment)'; 'Average cartel premium (labor productivity)'; ...
                     'Average cartel premium (market share)'; 'Standard deviation of log sales'; ...
                     'Standard deviation of log employment'; 'Average overcharge (in %)'};

Model_Values = [untargeted_moments.cartelized_industry_slope; ...
                untargeted_moments.cartel_premium_sales; ...
                untargeted_moments.cartel_premium_employment; ...
                untargeted_moments.cartel_premium_tfpl; ...
                untargeted_moments.cartel_premium_market_share; ...
                untargeted_moments.std_log_sales; ...
                untargeted_moments.std_log_employment; ...
                untargeted_moments.mean_overcharge];

T_untargeted = table(Model_Values, 'RowNames', UntargetedMoments, 'VariableNames', {'Model'});
%disp(T_untargeted);

fprintf('\n');