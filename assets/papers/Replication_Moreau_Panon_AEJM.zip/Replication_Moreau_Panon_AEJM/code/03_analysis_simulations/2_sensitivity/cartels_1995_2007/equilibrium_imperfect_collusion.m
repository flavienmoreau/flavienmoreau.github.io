%% Equilibrium conditions (guess)
z = z.*phi;

mu = rho/(rho-1)*ones(n_f, S);             % Guess on markups
p_i  = mu./z;                              % Price of a firm
p_s  = (nanmean(p_i.^(1-rho))).^(1/(1-rho));  % Sectoral price index
P   = (nanmean(p_s.^(1-eta))).^(1/(1-eta));   % Aggregate price

A  = nanmean(nanmean(z.^(-1).*(p_i./repmat(p_s,n_f,1)).^(-rho).*repmat(p_s/P, n_f,1).^(-eta))).^(-1); % Aggregate productivity
     
Y     = A*L; % Aggregate output
Yold  = Y;

omegaold  =  ((p_i./repmat(p_s,n_f,1)).^(1-rho))./(repmat(nn', n_f, 1));  % Market share (need to make it a matrix using repmat)

% Method for market shares
% 1) Loop through each sector and create matrix with market share of colluders

omegaold2 = omegaold(:,:).*cartel(:,:); % Market shares of colluding firms (get zeros if sector has no cartel) 
omegaold2 = nansum(omegaold2);             % Sum all these market shares to get cartel market share
omegaold2 = ones(n_f, 1)*omegaold2;     % Complete the matrix
omegaold2 = omegaold2.*cartel(:,:);     % Makes sure that this matrix applies only to cartel members in a sector 
                                        % (zeros are for non-cartel members
                                        % in a sector)
omegaold2 = beta*omegaold2;             % Multiply the cartel market share matrix by the intensity of collusion

%------------------------------------%
% Own market share of cartel members %
%------------------------------------%
% Need to loop because each sector has a different number of cartel members
for i = 1:S
omega_own_temp = omegaold(1:n_c(i,1), i);       % Take n-first market shares of cartel members in each sector
omega_own_temp(n_f,1) = 0;                      % Complete vector to get a (n_f*S) matrix (non members get zeroes)
omega_own(:,i) = omega_own_temp;                % Complete matrix by adding each vector
end
clear omega_own_temp;

omega_own = (1-beta)*omega_own;         % Multiply by 1-collusion parameter
omegaold2 = bsxfun(@plus, omegaold2, omega_own); % Add own market shares and cartel market share

for y = 1:S
for x = 1:n_f
if  omegaold2(x,y) == 0;
    
    omegaold2(x,y) = omegaold(x,y);
else
    omegaold2(x,y) = omegaold2(x,y);
end
end
%fprintf('%4i %6.2e \n',[y]);
end

clear omegaold omega_own;

yyold      = (p_i./repmat(p_s,n_f,1)).^(-rho).*(repmat(p_s,n_f,1)./P).^(-eta).*Y; 

%% Solve the model numerically

for it = 1 : 200

Y      = Yold;  
omega  = omegaold2;
yy     = yyold;

ee = (1/rho*(1-omega) + 1/eta*omega).^(-1);  % Cournot case
%ee = (rho*(1-omega) + eta*omega);  % Bertrand case

p_i  = ee./(ee-1)./z;

p_s              = nanmean(p_i.^(1-rho)).^(1/(1-rho));
p_s(isinf(p_s))   = 10^16;

P               = nanmean(p_s.^(1-eta)).^(1/(1-eta));

omega = (bsxfun(@times, p_i.^(1-rho), p_s.^(rho-1)))./(repmat(nn', n_f, 1)); % "bsxfun": Directly divides numerator by price index

%--------------------------------------------------------------------%
% Compute new market shares (cartel members care about cartel share) %
%--------------------------------------------------------------------%
omega_new = omega(:,:).*cartel(:,:);       % Market shares of colluding firms (get zeros if sector has no cartel) 
omega_new = nansum(omega_new);                % Sum all these market shares to get cartel market share
omega_new = ones(n_f, 1)*omega_new;        % Complete the matrix
omega_new = omega_new.*cartel(:,:);        % Makes sure that this matrix applies only to cartel members in a sector 
                                           % (zeros are for non-cartel members
                                           % in a sector)
omega_new = beta*omega_new;                % Multiply the cartel market share matrix by the intensity of collusion

for i = 1:S
omega_own2_temp = omega(1:n_c(i,1), i);    % Take n-first market shares of cartel members in each sector
omega_own2_temp(n_f,1) = 0;                % Complete vector to get a (n_f*S) matrix (non members get zeroes)
omega_own2(:,i) = omega_own2_temp;         % Complete matrix by adding each vector
end
clear omega_own2_temp;

omega_own2 = (1-beta)*omega_own2;          % Multiply by 1-collusion parameter

omega_new = bsxfun(@plus, omega_new, omega_own2);

for y = 1:S
for x = 1:n_f
if  omega_new(x,y) == 0;
    
    omega_new(x,y) = omega(x,y);
else
    omega_new(x,y) = omega_new(x,y);
end
end
%fprintf('%4i %6.2e \n',[y]);
end
omega = omega_new;

yy = bsxfun(@times, p_i.^(-rho), p_s.^(rho-eta).*P.^eta.*Y); % Comes from FOCs

omega = real(omega);
yy    = real(yy); 

A  = nanmean(nanmean(z.^(-1).*yy/Y)).^(-1);   

Y     = A*(L);

error = max([norm(omega - omegaold2); norm(Y-Yold)]);

rem = mod(it,10);
if rem == 1
    fprintf('%4i %6.2e \n',[it, error]);
end

if error < 1e-7, break, end
    
Yold         = 1/2*Y      +  1/2*Yold;
omegaold2     = 1/10*omega +  9/10*omegaold2;
yyold        = 1/10*yy    +  9/10*yyold;

end

ll = yy./z;

if norm(omega-omegaold2)>1e-3
    disp('Warning: omega has not converged')
end

mu  = ee./(ee-1); 
muagg   = P*A;
clear omegaold2 omega_new;

profit_cartel = (p_i - 1./z).*yy;

yy_cartel = yy;

market_share_imperfect_collusion = (bsxfun(@times, p_i.^(1-rho), p_s.^(rho-1)))./(repmat(nn', n_f, 1));

Labor_cartel   = nansum(ll); 
PjYj_cartel = nansum(p_i.*yy); 
mu_s_cartel  = PjYj_cartel'./Labor_cartel';
ee_cartel = ee;