%% Equilibrium conditions (guess) - Imperfect Collusion
% This version supports:
% - Cournot and Bertrand competition (via 'competition_type')
% - Heterogeneous kappa across sectors (via 'het_kappa' and 'kappa_matrix')

z = z.*phi;

mu = rho/(rho-1)*ones(n_f, S);             % Guess on markups
p_i  = mu./z;                              % Price of a firm
p_s  = (nanmean(p_i.^(1-rho))).^(1/(1-rho));  % Sectoral price index
P   = (nanmean(p_s.^(1-eta))).^(1/(1-eta));   % Aggregate price

A  = nanmean(nanmean(z.^(-1).*(p_i./repmat(p_s,n_f,1)).^(-rho).*repmat(p_s/P, n_f,1).^(-eta))).^(-1); % Aggregate productivity
     
Y     = A*L; % Aggregate output
Yold  = Y;

omegaold  =  ((p_i./repmat(p_s,n_f,1)).^(1-rho))./(repmat(nn', n_f, 1));  % Market share

%% Compute initial cartel market shares
% Method: Create matrix with market share of colluders

omegaold2 = omegaold(:,:).*cartel(:,:); % Market shares of colluding firms
omegaold2 = nansum(omegaold2);           % Sum to get cartel market share per sector
omegaold2 = ones(n_f, 1)*omegaold2;      % Complete the matrix
omegaold2 = omegaold2.*cartel(:,:);      % Apply only to cartel members

if het_kappa
    % Heterogeneous kappa: use sector-specific kappa_matrix
    % kappa_matrix has sector-specific beta values
    beta_matrix = kappa_matrix;
    beta_matrix(isnan(beta_matrix)) = 0;
    % For initial guess, use column-wise beta (first non-zero value per sector)
    beta_vec = zeros(1, S);
    for s = 1:S
        col_vals = beta_matrix(:, s);
        col_vals = col_vals(col_vals > 0);
        if ~isempty(col_vals)
            beta_vec(s) = col_vals(1);
        end
    end
    omegaold2 = omegaold2 .* repmat(beta_vec, n_f, 1);
else
    omegaold2 = beta*omegaold2;
end

% Own market share of cartel members
omega_own = zeros(n_f, S);
for i = 1:S
    omega_own_temp = omegaold(1:n_c(i,1), i);
    omega_own_temp(n_f,1) = 0;
    omega_own(:,i) = omega_own_temp;
end

if het_kappa
    omega_own = omega_own .* (1 - repmat(beta_vec, n_f, 1));
else
    omega_own = (1-beta)*omega_own;
end

omegaold2 = bsxfun(@plus, omegaold2, omega_own);

% Fill in non-cartel members with their own market share
for y = 1:S
    for x = 1:n_f
        if omegaold2(x,y) == 0
            omegaold2(x,y) = omegaold(x,y);
        end
    end
end

clear omegaold omega_own;

yyold = (p_i./repmat(p_s,n_f,1)).^(-rho).*(repmat(p_s,n_f,1)./P).^(-eta).*Y; 

%% Solve the model numerically

for it = 1 : 200

Y      = Yold;  
omega  = omegaold2;
yy     = yyold;

% Competition type switch
if strcmp(competition_type, 'bertrand')
    ee = (rho*(1-omega) + eta*omega);  % Bertrand case
else
    ee = (1/rho*(1-omega) + 1/eta*omega).^(-1);  % Cournot case (default)
end

p_i  = ee./(ee-1)./z;

p_s              = nanmean(p_i.^(1-rho)).^(1/(1-rho));
p_s(isinf(p_s))   = 10^16;

P               = nanmean(p_s.^(1-eta)).^(1/(1-eta));

omega = (bsxfun(@times, p_i.^(1-rho), p_s.^(rho-1)))./(repmat(nn', n_f, 1));

%% Compute new market shares (cartel members care about cartel share)
omega_new = omega(:,:).*cartel(:,:);
omega_new = nansum(omega_new);
omega_new = ones(n_f, 1)*omega_new;
omega_new = omega_new.*cartel(:,:);

if het_kappa
    omega_new = omega_new .* repmat(beta_vec, n_f, 1);
else
    omega_new = beta*omega_new;
end

omega_own2 = zeros(n_f, S);
for i = 1:S
    omega_own2_temp = omega(1:n_c(i,1), i);
    omega_own2_temp(n_f,1) = 0;
    omega_own2(:,i) = omega_own2_temp;
end

if het_kappa
    omega_own2 = omega_own2 .* (1 - repmat(beta_vec, n_f, 1));
else
    omega_own2 = (1-beta)*omega_own2;
end

omega_new = bsxfun(@plus, omega_new, omega_own2);

% Fill in non-cartel members
for y = 1:S
    for x = 1:n_f
        if omega_new(x,y) == 0
            omega_new(x,y) = omega(x,y);
        end
    end
end
omega = omega_new;

yy = bsxfun(@times, p_i.^(-rho), p_s.^(rho-eta).*P.^eta.*Y);

omega = real(omega);
yy    = real(yy); 

A  = nanmean(nanmean(z.^(-1).*yy/Y)).^(-1);   

Y     = A*(L);

error = max([norm(omega - omegaold2); norm(Y-Yold)]);

rem = mod(it,10);
if rem == 1
    fprintf('%4i %6.2e \n',[it, error]);
end

if error < 1e-7, break, end
    
Yold         = 1/2*Y      +  1/2*Yold;
omegaold2    = 1/10*omega +  9/10*omegaold2;
yyold        = 1/10*yy    +  9/10*yyold;

end

ll = yy./z;

if norm(omega-omegaold2)>1e-3
    disp('Warning: omega has not converged')
end

mu  = ee./(ee-1); 
muagg   = P*A;
clear omegaold2 omega_new omega_own2;

profit_cartel = (p_i - 1./z).*yy;

yy_cartel = yy;

market_share_imperfect_collusion = (bsxfun(@times, p_i.^(1-rho), p_s.^(rho-1)))./(repmat(nn', n_f, 1));

Labor_cartel   = nansum(ll); 
PjYj_cartel = nansum(p_i.*yy); 
mu_s_cartel  = PjYj_cartel'./Labor_cartel';
ee_cartel = ee;