%% AEJ Macro Replication Package (Moreau and Panon, forthcoming)
% This script reproduces 
% 1) Table 8 Robustness Experiments
% 2) Table E17: Calibration: Robustness

% It runs all robustness specifications and collects results

tic
clear;
clc;
diary tables_8_e17.txt
rng('default');  % For reproducibility

%% ============================================================
%  Define All Robustness Specifications
%  ============================================================
% Specifications: Baseline, Decile 8, Top 20%, kappa=0.83, Het. kappa, M=1.1, Bertrand

spec_names = {'Baseline', 'Decile8', 'Top20', 'HighKappa', 'HetKappa', 'Mu10', 'Bertrand'};
n_specs = length(spec_names);

% Fixed parameters across all specifications
n_f = 500;                  % Max number of firms within each sector
S = 670;                    % Number of sectors
L = 1;                      % Inelastic labor supply
nu = 2;                     % Inverse Frisch elasticity of labor supply

%% ============================================================
%  Parameter Values for Each Specification
%  ============================================================
% Structure: [rho, eta, xi, xi_s, zeta, zeta_f, beta]

params = struct();

% Baseline
params.Baseline.rho = 12.0564816759752;
params.Baseline.eta = 3.10040889831152;
params.Baseline.xi = 10.2378007453196;
params.Baseline.xi_s = 2.80881084697840;
params.Baseline.zeta = 0.161187916362012;
params.Baseline.zeta_f = 0.00407313218542430;
params.Baseline.beta = 0.41;
params.Baseline.share_cartels = 90;
params.Baseline.cartel_selection = 'top';  % top X%
params.Baseline.competition = 'cournot';
params.Baseline.het_kappa = false;

% Decile 8 (80th-90th percentile only)
params.Decile8.rho = 11.5509965161527;
params.Decile8.eta = 3.06478773660874;
params.Decile8.xi = 9.68972134001515;
params.Decile8.xi_s = 2.79933288764516;
params.Decile8.zeta = 0.160049209426380;
params.Decile8.zeta_f = 0.00414326272262689;
params.Decile8.beta = 0.41;
params.Decile8.share_cartels_low = 80;
params.Decile8.share_cartels_high = 90;
params.Decile8.cartel_selection = 'decile';  % specific decile
params.Decile8.competition = 'cournot';
params.Decile8.het_kappa = false;

% Top 20%
params.Top20.rho = 11.9778897897880;
params.Top20.eta = 3.09604975909987;
params.Top20.xi = 10.3128110514306;
params.Top20.xi_s = 2.83307247238125;
params.Top20.zeta = 0.152704210807296;
params.Top20.zeta_f = 0.00413309797540218;
params.Top20.beta = 0.41;
params.Top20.share_cartels = 80;
params.Top20.cartel_selection = 'top';
params.Top20.competition = 'cournot';
params.Top20.het_kappa = false;

% High kappa (kappa = 0.83)
params.HighKappa.rho = 12.0267674320988;
params.HighKappa.eta = 3.09775829367731;
params.HighKappa.xi = 10.3543309574790;
params.HighKappa.xi_s = 2.85649447297864;
params.HighKappa.zeta = 0.185354058235973;
params.HighKappa.zeta_f = 0.00404232999870217;
params.HighKappa.beta = 0.83;
params.HighKappa.share_cartels = 90;
params.HighKappa.cartel_selection = 'top';
params.HighKappa.competition = 'cournot';
params.HighKappa.het_kappa = false;

% Heterogeneous kappa
params.HetKappa.rho = 11.4897522193176;
params.HetKappa.eta = 3.04347821805735;
params.HetKappa.xi = 10.1931670616541;
params.HetKappa.xi_s = 2.75811691095246;
params.HetKappa.zeta = 0.198882400584494;
params.HetKappa.zeta_f = 0.00430195675400501;
params.HetKappa.beta = 0.41;
params.HetKappa.share_cartels = 90;
params.HetKappa.cartel_selection = 'top';
params.HetKappa.competition = 'cournot';
params.HetKappa.het_kappa = true;

% M = 1.1 (lower aggregate markup target)
params.Mu10.rho = 17.9110611955180;
params.Mu10.eta = 3.38282948080959;
params.Mu10.xi = 14.7368702029979;
params.Mu10.xi_s = 3.18274791044588;
params.Mu10.zeta = 0.152043148719045;
params.Mu10.zeta_f = 0.00403474030792220;
params.Mu10.beta = 0.41;
params.Mu10.share_cartels = 90;
params.Mu10.cartel_selection = 'top';
params.Mu10.competition = 'cournot';
params.Mu10.het_kappa = false;

% Bertrand competition
params.Bertrand.rho = 9.72873188887960;
params.Bertrand.eta = 3.10040889831152;
params.Bertrand.xi = 9.21102399195340;
params.Bertrand.xi_s = 2.83106919579062;
params.Bertrand.zeta = 0.163284092784997;
params.Bertrand.zeta_f = 0.00406214213918567;
params.Bertrand.beta = 0.41;
params.Bertrand.share_cartels = 90;
params.Bertrand.cartel_selection = 'top';
params.Bertrand.competition = 'bertrand';
params.Bertrand.het_kappa = false;

%% ============================================================
%  Initialize Results Storage
%  ============================================================
% Table 8 results (Robustness Experiments)
results_table8 = struct();
results_table8.A_cartel_to_comp = zeros(1, n_specs);
results_table8.A_cartel_to_eff = zeros(1, n_specs);
results_table8.distance_to_eff = zeros(1, n_specs);
results_table8.markup_change = zeros(1, n_specs);
results_table8.welfare_gain = zeros(1, n_specs);

% Table E17 results (Calibration: Robustness)
% Panel A: Targeted moments
results_tableE17 = struct();
results_tableE17.agg_markup = zeros(1, n_specs);
results_tableE17.slope = zeros(1, n_specs);
results_tableE17.CR4_within = zeros(1, n_specs);
results_tableE17.CR20_within = zeros(1, n_specs);
results_tableE17.CR4_across = zeros(1, n_specs);
results_tableE17.CR20_across = zeros(1, n_specs);
results_tableE17.median_firms = zeros(1, n_specs);
results_tableE17.median_cartel_members = zeros(1, n_specs);

% Panel B: Parameters
results_tableE17.param_rho = zeros(1, n_specs);
results_tableE17.param_eta = zeros(1, n_specs);
results_tableE17.param_xi = zeros(1, n_specs);
results_tableE17.param_xi_s = zeros(1, n_specs);
results_tableE17.param_zeta_f = zeros(1, n_specs);
results_tableE17.param_zeta = zeros(1, n_specs);

% For Het. kappa: P25 and P75
results_tableE17.P25_kappa = NaN;
results_tableE17.P75_kappa = NaN;

% Untargeted moments storage
untargeted = struct();
untargeted.cartelized_industry_slope = zeros(1, n_specs);
untargeted.cartel_premium_sales = zeros(1, n_specs);
untargeted.cartel_premium_employment = zeros(1, n_specs);
untargeted.cartel_premium_tfpl = zeros(1, n_specs);
untargeted.cartel_premium_mshare = zeros(1, n_specs);
untargeted.std_log_sales = zeros(1, n_specs);
untargeted.std_log_employment = zeros(1, n_specs);
untargeted.mean_overcharge = zeros(1, n_specs);

%% ============================================================
%  Main Loop: Run Each Specification
%  ============================================================

for spec_idx = 1:n_specs
    
    spec_name = spec_names{spec_idx};
    p = params.(spec_name);
    
    fprintf('\n');
    fprintf('============================================================\n');
    fprintf('Running Specification %d/%d: %s\n', spec_idx, n_specs, spec_name);
    fprintf('============================================================\n');
    
    % Reset random seed for reproducibility
    rng('default');
    
    % Extract parameters
    rho = p.rho;
    eta = p.eta;
    xi = p.xi;
    xi_s = p.xi_s;
    zeta = p.zeta;
    zeta_f = p.zeta_f;
    beta = p.beta;
    competition_type = p.competition;
    het_kappa = p.het_kappa;
    
    % Store parameters
    results_tableE17.param_rho(spec_idx) = rho;
    results_tableE17.param_eta(spec_idx) = eta;
    results_tableE17.param_xi(spec_idx) = xi;
    results_tableE17.param_xi_s(spec_idx) = xi_s;
    results_tableE17.param_zeta_f(spec_idx) = zeta_f;
    results_tableE17.param_zeta(spec_idx) = zeta;
    
    %% Generate Productivity Distribution
    N = n_f;
    M = S;
    alpha = xi;
    b = 1;
    
    % Firm-level productivity draws
    P_draw = randp(N, M, alpha, b);
    z = sort(P_draw, 'descend');
    
    % Sectoral productivity draws
    M_s = S;
    alpha_s = xi_s;
    P_s = randp(1, M_s, alpha_s, b);
    z_s = P_s;
    clear P_s P_draw;
    
    % Combined productivity: firm x sector
    z = bsxfun(@times, z, z_s);
    
    %% Generate Firm Distribution Across Sectors
    nn = geornd(zeta_f, S, 1);
    nn(nn == 0) = 178;              % Replace 0s with median
    nn(nn > n_f) = n_f;             % Cap at maximum
    nn(nn == 1) = 2;                % Minimum of 2 firms
    
    % Create firm activity matrix
    phi = zeros(N, S);
    for i = 1:S
        temp = zeros(N, 1);
        temp(1:nn(i)) = 1;
        temp = temp(randperm(N));
        phi(:, i) = temp;
    end
    
    phi = sort(phi, 1, 'descend');
    z = z .* phi + eps .* (1 - phi);
    z = sort(z, 1, 'descend');
    phi(phi == 0) = NaN;
    
    %% Generate Cartel Structure
    if strcmp(p.cartel_selection, 'top')
        % Top X% of sectors
        treated_ind_threshold = prctile(z_s, p.share_cartels);
        treated_ind_top = z_s >= treated_ind_threshold;
        collusive_ind = double(treated_ind_top');
    elseif strcmp(p.cartel_selection, 'decile')
        % Specific decile (e.g., 80th-90th percentile)
        treated_ind_low = prctile(z_s, p.share_cartels_low);
        treated_ind_high = prctile(z_s, p.share_cartels_high);
        treated_ind_decile = (z_s >= treated_ind_low) & (z_s < treated_ind_high);
        collusive_ind = double(treated_ind_decile');
    end
    
    % Determine number of cartel members per industry
    n_c = zeros(S, 1);
    for s = 1:S
        if collusive_ind(s, 1) == 1
            n_c(s) = geornd(zeta, 1, 1);
        end
    end
    
    n_c((n_c == 0) & (collusive_ind == 1)) = 4;  % Median cartel size
    n_c(n_c == 1) = 2;                            % Minimum 2 members
    
    % Ensure cartel size doesn't exceed number of firms
    dummy = n_c > nn;
    n_c(dummy) = nn(dummy);
    
    collusive_ind_final = n_c > 0;
    
    % Create cartel membership matrix
    cartel = zeros(n_f, S);
    for i = 1:S
        cartel_temp = ones(n_c(i, 1), 1);
        cartel_temp(n_f, 1) = 0;
        cartel(:, i) = cartel_temp;
    end
    
    %% Heterogeneous kappa (if applicable)
    if het_kappa
        cartelized_indices = find(collusive_ind_final == 1);
        num_cartelized = length(cartelized_indices);
        random_kappas = rand(1, num_cartelized);
        scaled_kappas = beta * random_kappas / mean(random_kappas);
        
        kappa_distribution = zeros(size(collusive_ind_final));
        kappa_distribution(cartelized_indices) = scaled_kappas;
        kappa_matrix = repmat(kappa_distribution', N, 1);
        kappa_matrix = kappa_matrix .* phi;
        
        % Store P25 and P75
        v_nonzero = kappa_distribution(kappa_distribution > 0);
        results_tableE17.P25_kappa = prctile(v_nonzero, 25);
        results_tableE17.P75_kappa = prctile(v_nonzero, 75);
    else
        kappa_matrix = [];
    end
    
    %% Compute Benchmark Equilibrium (No Cartels)
    fprintf('\nComputing Benchmark Equilibrium (No Cartels)...\n');
    
    % Store original z for later use
    z_original = z;
    
    % Call benchmark equilibrium
    equilibrium_benchmark_robustness;
    
    % Store no-cartel results
    mu_no_cartel = mu;
    p_i_no_cartel = p_i;
    p_s_no_cartel = p_s;
    A_no_cartel = A;
    muagg_no_cartel = muagg;
    omega_no_cartel = omega;
    
    % Reset z for collusion equilibrium
    z = z_original;
    
    %% Compute Collusion Equilibrium
    fprintf('\nComputing Equilibrium with Cartels...\n');
    
    equilibrium_imperfect_collusion_robustness;
    
    mu_cartel = mu;
    p_i_cartel = p_i;
    A_cartel = A;
    p_s_cartel = p_s;
    
    %% Compute Welfare Metrics
    % Efficient allocation benchmark
    A_s_eff = nanmean(z.^(rho-1)).^(1/(rho-1));
    A_eff = nanmean(A_s_eff.^(eta-1)).^(1/(eta-1));
    
    A_loss_cartel = (A_cartel / A_no_cartel - 1) * 100;
    A_loss_efficient = (A_cartel / A_eff - 1) * 100;
    
    A_cartel_to_comp = -A_loss_cartel;  % Positive gain from breaking cartels
    A_cartel_to_eff = -A_loss_efficient;  % Positive gap to efficient
    distance_to_efficient = (A_loss_cartel / A_loss_efficient) * 100;
    
    % Markup change: from cartel to competitive (reduction = negative of increase)
    markup_change_pp = (muagg - muagg_no_cartel) * 100;  % muagg is cartel markup
    
    % Welfare: gain from moving from cartel to competitive
    % This is negative (loss from cartels), so welfare gain = -welfare_static
    welfare_loss_from_cartel = ((A_cartel / A_no_cartel) * (muagg / muagg_no_cartel)^(-1/(1+nu)) - 1) * 100;
    welfare_gain = -welfare_loss_from_cartel;
    
    % Store Table 8 results
    results_table8.A_cartel_to_comp(spec_idx) = A_cartel_to_comp;
    results_table8.A_cartel_to_eff(spec_idx) = A_cartel_to_eff;
    results_table8.distance_to_eff(spec_idx) = distance_to_efficient;
    results_table8.markup_change(spec_idx) = -markup_change_pp;  % Reduction in markup (positive)
    results_table8.welfare_gain(spec_idx) = welfare_gain;
    
    %% Compute Targeted Moments (Table E17 Panel A)
    % Aggregate markup
    results_tableE17.agg_markup(spec_idx) = round(muagg, 2);
    
    % Market shares for moments computation
    market_share_imperfect_collusion = (bsxfun(@times, p_i_cartel.^(1-rho), p_s_cartel.^(rho-1))) ./ (repmat(nn', n_f, 1));
    
    % Markup increase for overcharge calculation
    markup_increase = ((mu_cartel ./ mu_no_cartel) - 1) * 100;
    
    % Call moments computation
    moments_robustness;
    
    % Store moments results (these are set in moments_robustness.m)
    results_tableE17.slope(spec_idx) = slope_result;
    results_tableE17.CR4_within(spec_idx) = CR4_within_result;
    results_tableE17.CR20_within(spec_idx) = CR20_within_result;
    results_tableE17.CR4_across(spec_idx) = CR4_across_result;
    results_tableE17.CR20_across(spec_idx) = CR20_across_result;
    results_tableE17.median_firms(spec_idx) = median_firms_result;
    results_tableE17.median_cartel_members(spec_idx) = median_members_result;
    
    % Store untargeted moments
    untargeted.cartelized_industry_slope(spec_idx) = cartelized_ind_slope_result;
    untargeted.cartel_premium_sales(spec_idx) = cartel_premium_sales_result;
    untargeted.cartel_premium_employment(spec_idx) = cartel_premium_employment_result;
    untargeted.cartel_premium_tfpl(spec_idx) = cartel_premium_tfpl_result;
    untargeted.cartel_premium_mshare(spec_idx) = cartel_premium_mshare_result;
    untargeted.std_log_sales(spec_idx) = std_log_sales_result;
    untargeted.std_log_employment(spec_idx) = std_log_employment_result;
    untargeted.mean_overcharge(spec_idx) = mean_overcharge_result;
    
    fprintf('\nSpecification %s completed.\n', spec_name);
    
end

%% ============================================================
%  Display Table 8: Robustness Experiments (excludes Baseline)
%  ============================================================
fprintf('\n\n');
fprintf('================================================================\n');
fprintf('TABLE 8 - ROBUSTNESS EXPERIMENTS\n');
fprintf('================================================================\n');
fprintf('\n');
fprintf('%-35s', '');
for i = 2:n_specs
    fprintf('%12s', spec_names{i});
end
fprintf('\n');
fprintf('%s\n', repmat('-', 1, 35 + 12*(n_specs-1)));

% Row 1: A_cartel -> A_comp
fprintf('%-35s', 'A_cartel -> A_comp');
for i = 2:n_specs
    fprintf('%12.2f', results_table8.A_cartel_to_comp(i));
end
fprintf('\n');

% Row 2: A_cartel -> A_eff
fprintf('%-35s', 'A_cartel -> A_eff');
for i = 2:n_specs
    fprintf('%12.2f', results_table8.A_cartel_to_eff(i));
end
fprintf('\n');

% Row 3: Distance to efficient allocation
fprintf('%-35s', 'Distance to efficient allocation');
for i = 2:n_specs
    fprintf('%12.2f', -results_table8.distance_to_eff(i));
end
fprintf('\n');
fprintf('\n');

% Row 4: Markup change (in pp)
fprintf('%-35s', 'M_cartel -> M_comp (in pp)');
for i = 2:n_specs
    fprintf('%12.2f', results_table8.markup_change(i));
end
fprintf('\n');

% Row 5: Welfare gain (in %)
fprintf('%-35s', 'W_cartel -> W_comp (in %)');
for i = 2:n_specs
    fprintf('%12.2f', results_table8.welfare_gain(i));
end
fprintf('\n');

%% ============================================================
%  Display Table E17: Calibration Robustness (includes Baseline)
%  ============================================================
fprintf('\n\n');
fprintf('================================================================\n');
fprintf('TABLE E17 - CALIBRATION: ROBUSTNESS\n');
fprintf('================================================================\n');
fprintf('\n');
fprintf('Panel A: Targets\n');
fprintf('%s\n', repmat('-', 1, 35 + 12*n_specs));
fprintf('%-35s', 'Moments');
for i = 1:n_specs
    fprintf('%12s', spec_names{i});
end
fprintf('\n');
fprintf('%s\n', repmat('-', 1, 35 + 12*n_specs));

fprintf('%-35s', 'Aggregate markup');
for i = 1:n_specs
    fprintf('%12.2f', results_tableE17.agg_markup(i));
end
fprintf('\n');

fprintf('%-35s', 'Slope parameter');
for i = 1:n_specs
    fprintf('%12.2f', results_tableE17.slope(i));
end
fprintf('\n');

fprintf('%-35s', 'Top-4 sales share, within-sector');
for i = 1:n_specs
    fprintf('%12.2f', results_tableE17.CR4_within(i));
end
fprintf('\n');

fprintf('%-35s', 'Top-20 sales share, within-sector');
for i = 1:n_specs
    fprintf('%12.2f', results_tableE17.CR20_within(i));
end
fprintf('\n');

fprintf('%-35s', 'Top-4 sales share, across-sector');
for i = 1:n_specs
    fprintf('%12.2f', results_tableE17.CR4_across(i));
end
fprintf('\n');

fprintf('%-35s', 'Top-20 sales share, across-sector');
for i = 1:n_specs
    fprintf('%12.2f', results_tableE17.CR20_across(i));
end
fprintf('\n');

fprintf('%-35s', 'Median # firms per sector');
for i = 1:n_specs
    fprintf('%12.0f', results_tableE17.median_firms(i));
end
fprintf('\n');

fprintf('%-35s', 'Median # members per cartel');
for i = 1:n_specs
    fprintf('%12.0f', results_tableE17.median_cartel_members(i));
end
fprintf('\n');

fprintf('\n');
fprintf('Panel B: Parameters\n');
fprintf('%s\n', repmat('-', 1, 35 + 12*n_specs));
fprintf('%-35s', 'Interpretation');
for i = 1:n_specs
    fprintf('%12s', spec_names{i});
end
fprintf('\n');
fprintf('%s\n', repmat('-', 1, 35 + 12*n_specs));

fprintf('%-35s', 'Substitution within sectors');
for i = 1:n_specs
    fprintf('%12.2f', results_tableE17.param_rho(i));
end
fprintf('\n');

fprintf('%-35s', 'Substitution between sectors');
for i = 1:n_specs
    fprintf('%12.2f', results_tableE17.param_eta(i));
end
fprintf('\n');

fprintf('%-35s', 'Pareto shape, firms');
for i = 1:n_specs
    fprintf('%12.2f', results_tableE17.param_xi(i));
end
fprintf('\n');

fprintf('%-35s', 'Pareto shape, sectors');
for i = 1:n_specs
    fprintf('%12.2f', results_tableE17.param_xi_s(i));
end
fprintf('\n');

fprintf('%-35s', 'Geometric, firms');
for i = 1:n_specs
    fprintf('%12.3f', results_tableE17.param_zeta_f(i));
end
fprintf('\n');

fprintf('%-35s', 'Geometric, cartel members');
for i = 1:n_specs
    fprintf('%12.2f', results_tableE17.param_zeta(i));
end
fprintf('\n');

% P25 kappa and P75 kappa (only for Het. kappa)
fprintf('%-35s', 'P25 kappa');
for i = 1:n_specs
    if strcmp(spec_names{i}, 'HetKappa')
        fprintf('%12.2f', results_tableE17.P25_kappa);
    else
        fprintf('%12s', '');
    end
end
fprintf('\n');

fprintf('%-35s', 'P75 kappa');
for i = 1:n_specs
    if strcmp(spec_names{i}, 'HetKappa')
        fprintf('%12.2f', results_tableE17.P75_kappa);
    else
        fprintf('%12s', '');
    end
end
fprintf('\n');

%% ============================================================
%  Display Untargeted Moments (excludes Baseline)
%  ============================================================
fprintf('\n\n');
fprintf('================================================================\n');
fprintf('UNTARGETED MOMENTS\n');
fprintf('================================================================\n');
fprintf('\n');
fprintf('%-35s', '');
for i = 2:n_specs
    fprintf('%12s', spec_names{i});
end
fprintf('\n');
fprintf('%s\n', repmat('-', 1, 35 + 12*(n_specs-1)));

fprintf('%-35s', 'Cartelized industry slope');
for i = 2:n_specs
    fprintf('%12.2f', untargeted.cartelized_industry_slope(i));
end
fprintf('\n');

%fprintf('%-35s', 'Avg cartel premium (sales)');
%for i = 2:n_specs
%    fprintf('%12.2f', untargeted.cartel_premium_sales(i));
%end
%fprintf('\n');

%fprintf('%-35s', 'Avg cartel premium (employment)');
%for i = 2:n_specs
%    fprintf('%12.2f', untargeted.cartel_premium_employment(i));
%end
%fprintf('\n');

%fprintf('%-35s', 'Avg cartel premium (labor prod.)');
%for i = 2:n_specs
%    fprintf('%12.2f', untargeted.cartel_premium_tfpl(i));
%end
%fprintf('\n');

%fprintf('%-35s', 'Avg cartel premium (market share)');
%for i = 2:n_specs
%    fprintf('%12.2f', untargeted.cartel_premium_mshare(i));
%end
%fprintf('\n');

%fprintf('%-35s', 'Std dev of log sales');
%for i = 2:n_specs
%    fprintf('%12.2f', untargeted.std_log_sales(i));
%end
%fprintf('\n');

%fprintf('%-35s', 'Std dev of log employment');
%for i = 2:n_specs
%    fprintf('%12.2f', untargeted.std_log_employment(i));
%end
%fprintf('\n');

fprintf('%-35s', 'Average overcharge (in %)');
for i = 2:n_specs
    fprintf('%12.2f', untargeted.mean_overcharge(i));
end
fprintf('\n');

%% ============================================================
%  Save Results
%  ============================================================
save('robustness_results.mat', 'results_table8', 'results_tableE17', 'untargeted', 'spec_names', 'params');

fprintf('\n\nResults saved to robustness_results.mat\n');

diary off
toc;