%% Computes model moments for robustness specifications
% This script computes targeted and untargeted moments
% and stores results in variables to be collected by the main robustness script
% 
% Required variables from main script:
% - spec_name: current specification name
% - All equilibrium results (p_i_cartel, yy_cartel, mu_cartel, etc.)

%% ============================================================
%  Data Moments (Targets)
%  ============================================================
% Data moments for comparison - hardcoded for each specification
% Format: [agg_markup; slope; CR4_within; CR20_within; CR4_across; CR20_across; median_firms; median_cartel_members]

if strcmp(spec_name, 'Mu10')
    % M=1.1 specification targets aggregate markup of 1.10
    all_data_moments = [1.10; -0.24; 0.42; 0.66; 0.14; 0.33; 178; 4];
else
    % All other specifications use baseline data moments
    all_data_moments = [1.14; -0.24; 0.42; 0.66; 0.14; 0.33; 178; 4];
end

% Untargeted data moments for comparison
% Format: [cartelized_ind_slope; cartel_premium_sales; cartel_premium_employment; 
%          cartel_premium_tfpl; cartel_premium_mshare; std_log_sales; std_log_employment; mean_overcharge]
all_data_untargeted_moments = [0.03; 0.36; 0.23; 0.13; 1.73; 2.40; 2.28; 20.0];

%% ============================================================
%  Block #1: Aggregate Markup (already stored in main script)
%  ============================================================
% muagg is already computed

%% ============================================================
%  Block #2: Median Number of Cartel Members
%  ============================================================
median_members = median(n_c(n_c > 0));
median_members_result = median_members;

%% ============================================================
%  Block #3: Median Number of Firms per Sector
%  ============================================================
median_number_firms = sum(phi, 'omitnan');
median_number_firms = median(median_number_firms(median_number_firms > 0), 'omitnan');
median_firms_result = median_number_firms;

%% ============================================================
%  Block #4: Concentration Ratios Within Industries (CR4, CR20)
%  ============================================================
sales = p_i_cartel .* yy_cartel .* phi;

total_sales = sum(sales, 'omitnan');
m_share = sales ./ repmat(total_sales, N, 1);

% Top 4 and Top 20 concentration ratios
concentration_ratio4 = sum(m_share(1:4, :), 1, 'omitnan');
concentration_ratio4(concentration_ratio4 == 0) = NaN;

concentration_ratio20 = sum(m_share(1:20, :), 1, 'omitnan');
concentration_ratio20(concentration_ratio20 == 0) = NaN;

% Weight by sales share (Domar weights)
total_sales_economy = sum(total_sales, 'omitnan') * ones(1, S);
industry_domar_weights = total_sales ./ total_sales_economy;
industry_domar_weights(industry_domar_weights == 0) = NaN;

concentration_ratio4_product = concentration_ratio4 .* industry_domar_weights;
CR4_within_result = round(sum(concentration_ratio4_product, 'omitnan'), 2);

concentration_ratio20_product = concentration_ratio20 .* industry_domar_weights;
CR20_within_result = round(sum(concentration_ratio20_product, 'omitnan'), 2);

%% ============================================================
%  Block #5: Concentration Ratios Across Sectors (CR4, CR20)
%  ============================================================
industry_domar_weights_cr_sectors = industry_domar_weights';
industry_domar_weights_cr_sectors = sort(industry_domar_weights_cr_sectors, 1, 'descend');
industry_domar_weights_cr_sectors = industry_domar_weights_cr_sectors(~isnan(industry_domar_weights_cr_sectors));

CR4_across_result = round(sum(industry_domar_weights_cr_sectors(1:4, :), 1, 'omitnan'), 2);
CR20_across_result = round(sum(industry_domar_weights_cr_sectors(1:20, :), 1, 'omitnan'), 2);

%% ============================================================
%  Block #6: Regression Slope Coefficient
%  ============================================================
% Collusion model: sum of own + total coefficients

% Cartel market shares
sum_ms_cartel = cartel .* market_share_imperfect_collusion;
sum_ms_cartel = nansum(sum_ms_cartel);
sum_ms_cartel = repmat(sum_ms_cartel, n_f, 1);
sum_ms_cartel = sum_ms_cartel .* cartel;
sum_ms_cartel(sum_ms_cartel == 0) = NaN;
sum_ms_cartel_vec = sum_ms_cartel(:);
sum_ms_cartel_vec = sum_ms_cartel_vec(all(~isnan(sum_ms_cartel_vec), 2), :);

% Own market share for cartel members
tempX = cartel(:);
tempX(tempX == 0) = NaN;
market_share_economy_cartel = market_share_imperfect_collusion(:);
market_share_economy_cartel = market_share_economy_cartel .* tempX;
market_share_economy_cartel = market_share_economy_cartel(all(~isnan(market_share_economy_cartel), 2), :);

temp_intercept_cartel = ones(size(market_share_economy_cartel(:, 1)));
tempX_final_cartel = [temp_intercept_cartel market_share_economy_cartel sum_ms_cartel_vec];

% Dependent variable: inverse markup for cartel members
tempY_ = cartel .* mu_cartel;
tempY_(tempY_ == 0) = NaN;
tempY_ = tempY_(:);
tempY_ = tempY_(all(~isnan(tempY_), 2), :);
tempY_ = 1 ./ tempY_;

temp_beta_cartel = inv(tempX_final_cartel' * tempX_final_cartel) * tempX_final_cartel' * tempY_;

slope_own_cartel = temp_beta_cartel(2);
slope_total_cartel = temp_beta_cartel(3);
sum_coefficients_cartel = slope_own_cartel + slope_total_cartel;

slope_result = round(sum_coefficients_cartel, 2);

%% ============================================================
%  Block #7: Cartel Overcharge
%  ============================================================
cartel_moment = cartel;
cartel_moment(cartel_moment == 0) = NaN;

overcharge_sample = cartel_moment .* markup_increase;
overcharge_sample = overcharge_sample(:);
overcharge_sample = overcharge_sample(all(~isnan(overcharge_sample), 2), :);
mean_overcharge_sample = mean(overcharge_sample);

mean_overcharge_result = round(mean_overcharge_sample, 2);

%% ============================================================
%  Untargeted Moments
%  ============================================================

% Compute cartel premia within cartelized industries
cartel_id = phi .* cartel;

Y_variables = {log(p_i_cartel .* yy_cartel .* phi), log(ll .* phi), ...
               log(yy_cartel ./ ll), (market_share_imperfect_collusion * 100) .* phi};

variable_names = {'Sales', 'Employment', 'TFPL', 'Market Share'};
cartel_premiums_all = cell(size(Y_variables));

for v = 1:length(Y_variables)
    cartel_premiums = [];
    
    for s = 1:S
        if collusive_ind_final(s, 1) == 1
            Y_dep = Y_variables{v}(:, s);
            X = [phi(:, s), cartel_id(:, s)];
            
            non_nan_rows_Y = ~isnan(Y_dep);
            non_nan_rows_X = ~any(isnan(X), 2);
            
            Y_dep_clean = Y_dep(non_nan_rows_Y);
            X_clean = X(non_nan_rows_X, :);
            
            [common_rows_Y, common_rows_X] = intersect(find(non_nan_rows_Y), find(non_nan_rows_X));
            
            if length(common_rows_Y) > 2 && length(common_rows_X) > 2
                Y_dep_final = Y_dep(common_rows_Y);
                X_final = X(common_rows_X, :);
                
                if rank(X_final' * X_final) == size(X_final, 2)
                    beta_reg = inv(X_final' * X_final) * X_final' * Y_dep_final;
                    cartel_premium_ = beta_reg(2);
                    cartel_premiums = [cartel_premiums, cartel_premium_];
                end
            end
        end
    end
    
    cartel_premiums(isinf(cartel_premiums)) = NaN;
    cartel_premiums_all{v} = cartel_premiums;
end

mean_cartel_premiums = cellfun(@nanmean, cartel_premiums_all, 'UniformOutput', false);

cartel_premium_sales_result = round(mean_cartel_premiums{1}, 2);
cartel_premium_employment_result = round(mean_cartel_premiums{2}, 2);
cartel_premium_tfpl_result = round(mean_cartel_premiums{3}, 2);
cartel_premium_mshare_result = round(mean_cartel_premiums{4}, 2);

% Standard deviations of log sales and log employment
sales_all = p_i_cartel .* yy_cartel .* phi;
tempY_sales = log(sales_all(:));
tempY_sales = tempY_sales(all(~isnan(tempY_sales), 2), :);
tempY_sales = tempY_sales(all(~isinf(tempY_sales), 2), :);

tempY_employment = log(ll .* phi);
tempY_employment = tempY_employment(:);
tempY_employment = tempY_employment(all(~isnan(tempY_employment), 2), :);
tempY_employment = tempY_employment(all(~isinf(tempY_employment), 2), :);

std_log_sales_result = round(std(tempY_sales), 2);
std_log_employment_result = round(std(tempY_employment), 2);

% Cross-sectoral regression: cartelized industry slope
temp_ = ones(1, S);
tempX_industry = [temp_' collusive_ind_final];
tempY_domar_industry = industry_domar_weights' * 100;

% Remove NaN rows
valid_rows = ~isnan(tempY_domar_industry);
tempX_industry_clean = tempX_industry(valid_rows, :);
tempY_domar_industry_clean = tempY_domar_industry(valid_rows);

if rank(tempX_industry_clean' * tempX_industry_clean) == size(tempX_industry_clean, 2)
    coef_reg = inv(tempX_industry_clean' * tempX_industry_clean) * tempX_industry_clean' * tempY_domar_industry_clean;
    cartelized_ind_slope_result = round(coef_reg(2), 2);
else
    cartelized_ind_slope_result = NaN;
end

%% ============================================================
%  Print Summary for Current Specification
%  ============================================================
fprintf('\n--- Moments Summary ---\n');
fprintf('Aggregate markup: %.2f\n', muagg);
fprintf('Slope coefficient: %.2f\n', slope_result);
fprintf('CR4 within: %.2f\n', CR4_within_result);
fprintf('CR20 within: %.2f\n', CR20_within_result);
fprintf('CR4 across: %.2f\n', CR4_across_result);
fprintf('CR20 across: %.2f\n', CR20_across_result);
fprintf('Median firms per sector: %.0f\n', median_firms_result);
fprintf('Median cartel members: %.0f\n', median_members_result);
fprintf('Mean overcharge: %.2f%%\n', mean_overcharge_result);
