*================================================*
* Clean Raw FICUS data before using that dataset *
*================================================*
cap use "$path\data\FICUS_All_Sectors_1994_2007.dta", clear
cap use "$path/data/FICUS_All_Sectors_1994_2007.dta", clear

gen naf_deflators = "01-05" if naf == "01" | naf == "02" | naf == "05"
replace naf_deflators = "10-14" if naf == "10" | naf == "11" | naf == "12" | naf == "13" | naf == "14"
replace naf_deflators = "15-16" if naf == "15" | naf == "16"
replace naf_deflators = "17-19" if naf == "17" | naf == "18" | naf == "19"
replace naf_deflators = "21-22" if naf == "21" | naf == "22"
replace naf_deflators = "27-28" if naf == "27" | naf == "28"
replace naf_deflators = "30-33" if naf == "30" | naf == "31" | naf == "32" | naf == "33" 
replace naf_deflators = "34-35" if naf == "34" | naf == "35"
replace naf_deflators = "36-37" if naf == "36" | naf == "37"
replace naf_deflators = "40-41" if naf == "40" | naf == "41"
replace naf_deflators = "50-52" if naf == "50" | naf == "51" | naf == "52"
replace naf_deflators = "60-63" if naf == "60" | naf == "61" | naf == "62" | naf == "63"
replace naf_deflators = "71-74" if naf == "71" | naf == "72" | naf == "73" | naf == "74" 
replace naf_deflators = "90-93" if naf == "90" | naf == "91" | naf == "92" | naf == "93" 
replace naf_deflators = naf if naf_deflators == ""

* merge to get deflators *
preserve

cap use "$path\data\deflators_economy_1994_2007.dta", clear
cap use "$path/data/deflators_economy_1994_2007.dta", clear

rename naf naf_deflators

tempfile naf_deflators
save "`naf_deflators'"

restore

merge m:1 naf_deflators year using "`naf_deflators'"
drop if _m == 1
drop _merge

* Sum of expenditures on raw materials, goods, other goods and changes in inventories
gen materials = achampr + achamar + varstmp + varstma
label var materials "Inputs (achampr, achamar, varstma, varstmp)"

gen materials2 = achampr + achamar 
label var materials2 "Inputs (achampr, achamar)"

gen gross_output = catotal + prodsto + prodimm 

gen real_gross_output = gross_output/go_p
gen real_catotal = catotal/go_p
gen real_cafranc = cafranc/go_p
gen real_caexpor= caexpor/go_p
	
gen real_vaht = vaht/va_p
		
gen real_materials = materials/ii_p

* We drop observations for which value added, sales or labor compensation are non positive
gen labor_compensation = saltrai + charsoc
label var labor_compensation "Total Labor Cost"

* Eliminate very small firms
bysort siren: egen max_empl = max(effsalm)

drop if real_gross_output <= 0 
drop if real_catotal <= 0 
drop if real_cafranc <= 0 
drop if real_caexpor < 0
drop if real_vaht <= 0
drop if	effsalm <= 0 
drop if real_materials <= 0 
drop if immocor <= 0 | immocor == .
drop if labor_compensation <= 0

* Remove firms with fewer than 2 employees over entire time period 
drop if max_empl == 0 | max_empl == 1 | max_empl == 2

gen rev_share_labor = labor_compensation/gross_output
gen rev_share_materials = materials/gross_output
label var rev_share_labor "Revenue Share of Labor (nominal)"
label var rev_share_materials "Revenue Share of Materials (nominal)"

gen q_gross_output = ln(real_gross_output)
gen q_alternative = ln(real_catotal)
gen q_va = ln(real_vaht)
gen l = ln(effsalm)
gen m = ln(real_materials)

* generate labor productivity 
gen tfp_labor_real = ln(real_vaht/effsalm)

gen wage = ln(labor_compensation/effsalm)

* Only keep relevant variables to be used 
keep siren year naf ape catotal cafranc caexpor vaht vabcf effsalm saltrai charsoc dep ebe monor reg zemp materials materials2 gross_output real_gross_output real_catotal real_cafranc real_caexpor real_vaht real_materials labor_compensation rev_share_labor rev_share_materials q_gross_output q_alternative q_va l m tfp_labor_real wage immocor amimcor TraEq OMach OCon RStruc Other autach
compress

*----------------------------------*
* Clean outliers before estimation *
*----------------------------------*
* Trim the growth rates of sales that are double or 
* half the previous value for each sector 

cap drop naf2 max_naf2
egen naf2 = group(naf)
qui sum naf2
global max_naf2 = r(max)

* Clean sales for each sector 
forvalues i = 1/$max_naf2{
	preserve
		keep if naf2 == `i'
		local variables "catotal"
		foreach x of local variables{
		bysort siren (year): gen gr_`x' = ((`x'[_n]/`x'[_n-1])-1)*100
		egen p1_gr_`x' = pctile(gr_`x'), p(1)
		egen p99_gr_`x' = pctile(gr_`x'), p(99)
		gen gr_`x'2 = gr_`x' 
		replace gr_`x'2 = . if gr_`x'2 < p1_gr_`x' | gr_`x'2 > p99_gr_`x'
		drop p1_gr_`x' p99_gr_`x'
		su gr_`x' gr_`x'2 
}

		tempfile clean_`i'
		save "`clean_`i''"
	restore
}
use "`clean_1'", clear
forvalues i = 2/$max_naf2{
append using "`clean_`i''"
}

drop if gr_catotal2 == . & gr_catotal != .
drop gr_catota*

tempfile clean_FICUS
save "`clean_FICUS'"

compress
*cap save "$path\data\Clean_Ficus.dta", replace
cap save "$path/data/Clean_Ficus.dta", replace
