*==================*
* Estimate markups *
*==================*

* Loop over different winsorization levels
* baseline: p(5)/p(95), wins1: p(1)/p(99), wins3: p(3)/p(97)

foreach wins in baseline wins1 wins3 {

	cap use "$path\data\Clean_Ficus.dta", clear
	cap use "$path/data/Clean_Ficus.dta", clear

	replace autach = . if autach < 0

	* Generate shares
	gen alpha_m = (materials)/gross_output
	drop if alpha_m <0 | alpha_m == .

	gen alpha_l = labor_compensation/gross_output
	drop if alpha_l <0 | alpha_l == .

	* Winsorize 
	tempvar temph templ 
	local varlist alpha_m alpha_l
	foreach var of local varlist{
		
		bysort naf year: egen `templ' = pctile( `var'), p(5)
		bysort naf year: egen `temph' = pctile( `var'), p(95)

		replace `var' = `templ' if  `var' <= `templ' & `var' != .
		replace `var' = `temph' if  `var' >= `temph' & `var' != .
		
		drop `templ' `temph'

	}

	replace alpha_m = 1 if alpha_m > 1
	replace alpha_l = 1 if alpha_l > 1

	* Generate other variables
	gen capital = immocor

	gen rental_rate = 0.05 + 0.01675912
	* UPDATE: R = 0.01675912 over 1994-2007 (mean)

	gen Totcost = labor_compensation + materials + rental_rate*capital + autach
	drop if Totcost == . | Totcost < 0

	gen CS_m = (materials)/Totcost
	gen CS_l = labor_compensation/Totcost

	bysort ape: egen theta_m = mean(CS_m)
	bysort ape: egen theta_l = mean(CS_l)

	*tabstat theta_m, by(naf)

	gen mu_m = theta_m/alpha_m
	gen mu_l = theta_l/alpha_l

	*--------------------------*
	* Apply Raval's correction *
	*--------------------------*

	gen ratio_raval = labor_compensation/(materials)

	*-----------*
	* Winsorize *
	*-----------*

	bysort ape: egen quint_20 = pctile(ratio_raval), p(20)
	bysort ape: egen quint_40 = pctile(ratio_raval), p(40)
	bysort ape: egen quint_60 = pctile(ratio_raval), p(60)
	bysort ape: egen quint_80 = pctile(ratio_raval), p(80)

	gen quint1 = ratio_raval <= quint_20
	gen quint2 = ratio_raval > quint_20 & ratio_raval <= quint_40
	gen quint3 = ratio_raval > quint_40 & ratio_raval <= quint_60
	gen quint4 = ratio_raval > quint_60 & ratio_raval <= quint_80
	gen quint5 = ratio_raval > quint_80

	gen quint_combined = 1 if quint1 == 1
	replace quint_combined = 2 if quint2 == 1
	replace quint_combined = 3 if quint3 == 1
	replace quint_combined = 4 if quint4 == 1
	replace quint_combined = 5 if quint5 == 1

	bysort ape quint_combined: egen theta_m_quint = mean(CS_m)
	bysort ape quint_combined: egen theta_l_quint = mean(CS_l)

	gen mu_raval_m = theta_m_quint/alpha_m
	gen mu_raval_l = theta_l_quint/alpha_l

	*-----------*
	* Winsorize *
	*-----------*

	* Set winsorization percentiles based on specification
	if "`wins'" == "baseline" {
		local plo = 5
		local phi = 95
	}
	else if "`wins'" == "wins1" {
		local plo = 1
		local phi = 99
	}
	else if "`wins'" == "wins3" {
		local plo = 3
		local phi = 97
	}

	tempvar temph templ 
	local varlist mu_m mu_l mu_raval_m mu_raval_l
	foreach var of local varlist{
		
	bysort year: egen `templ' = pctile( `var'), p(`plo')
	bysort year: egen `temph' = pctile( `var'), p(`phi')

		replace `var' = `templ' if  `var' <= `templ' & `var' != .
		replace `var' = `temph' if  `var' >= `temph' & `var' != .
		
		drop `templ' `temph'

	}

	su mu*, d

	keep siren year mu*
	compress

	* Save with appropriate filename
	if "`wins'" == "baseline" {
		*cap save "$path\data\markups_cost_share.dta", replace
		cap save "$path/data/markups_cost_share.dta", replace
	}
	else {
		*cap save "$path\data\markups_cost_share_`wins'.dta", replace
		cap save "$path/data/markups_cost_share_`wins'.dta", replace

	}

}
