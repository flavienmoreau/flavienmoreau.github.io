*===================================================================*
* In this do-file, we import all the FICUS dta files and clean them *
*===================================================================*
* The user should have access to French firm-level data to launch the code (SUSE_ESANE_FICUS files).

clear


forvalues i = 1994/2007 {

* PC or Mac
cap use "$path\data\SUSE_ESANE_FICUS_`i'.dta", clear
cap use "$path/data/SUSE_ESANE_FICUS_`i'.dta", clear

gen year = `i'
label var year "Year"

* We keep the BIC-BRN and BIC-RSI firms 
drop if typimpo ==  "3"

* We drop observations for which the siren is not well identified 
drop if siren == "" | siren == "000000000"

* We create the sectors 
gen naf = substr(ape, 1, 2)
label var naf "Naf Code"

* We eliminate potential duplicates 
duplicates drop

compress

tempfile temp`i'
save "`temp`i''", replace
}

use "`temp1994'", clear
forvalues i = 1995/2007 {
append using "`temp`i''"
}

keep typimpo nom achamar achampr amimcor amiminc ape autacha autprex caexpor cafranc catotal charsoc com cote defail dep dividen dotamor ebe effsalm immocor immoinc immofin amimfin invavap invcorp monor n114 naf nom partsal pbcai pncai prodimm prodsto prodtot prodven reg saltrai siren stocmar stocmpp subvinv subvexp tcharex impotax vabcf vaht varstma varstmp ventmar year zemp valid tactibr tactint tamcirc datcr 

order nom siren year naf ape n114 catotal cafranc caexpor ventmar prodven vaht vabcf subvinv subvexp impotax achamar achampr autacha effsalm saltrai charsoc immocor immoinc immofin dotamor amimcor amiminc amimfin tamcirc tactibr tactint invavap invcorp autprex com cote defail dep dividen ebe monor partsal pbcai pncai prodimm prodsto prodtot reg stocmar stocmpp varstma varstmp zemp valid
sort siren year
compress

* There are some duplicates *
duplicates drop
duplicates list siren year 
drop if siren == "383789682" & year == 2005 & nom == ""
drop if siren == "300286408" & year == 2005 & datcr == "??????"
drop if siren == "300717345" & year == 2005 & datcr == "??????"
drop if siren == "426280269" & year == 2005 & datcr == "198909"
drop if siren == "585580301" & year == 2005 & datcr == "??????"

compress

cap save "$path\data\FICUS_All_Sectors_1994_2007.dta", replace
cap save "$path/data/FICUS_All_Sectors_1994_2007.dta", replace

