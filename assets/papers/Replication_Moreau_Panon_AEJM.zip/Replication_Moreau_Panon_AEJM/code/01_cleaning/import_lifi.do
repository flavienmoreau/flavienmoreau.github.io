*==============================================================*
* In this do-file, we import all the LIFI files and clean them *
*==============================================================*
* The user should have access to French firm-level data to launch the code (LIFI_ENT files).

clear

qui{
forvalues i = 1994/2007 {
*use "$path\data\LIFI_ENT_`i'.dta", clear
use "$path/data/LIFI_ENT_`i'.dta", clear

gen year = `i'
tempfile temp`i'
save "`temp`i''", replace
}

use "`temp1994'", clear

forvalues i = 1995/2007 {
append using "`temp`i''"
}
gen str lifi_ent = "ENT"
drop an
}

* We eliminate potential duplicates 
duplicates drop

* We label the variables according to the pdf files provided 
* One must be careful given that some variables do not include the comma and are expressed in Francs 
qui{
label var lifi_ent "Origin of the LIFI"
label var year "Year"
label var sirlifi "SIREN de l'entreprise"
label var rs "Nom ou raison sociale"
label var sigle "Sigle"
label var cadr "complément adresse"
label var voie "Adresse du siège sociale de l'entreprise"
label var distsp "Distribution spéciale"
label var adrl6 "Ligne acheminement postal"
label var pays "Code pays" 
label var paysorig "Code pays" 
label var totit "Total des titres de participations détenus (compte 261 et 266 du plan comptable). L'unité est le KF (1KF=1000F). La valeur 9999999 est non significative."
label var acent "Répartition de l'actionnariat. Ce taux correspond au pourcentage d'actions détenus par l'entreprise elle-même. Le taux est exprimé sur 5 caractères, la virgule n'est pas matérialisée (100% s'écrit 10000). La valeur 99999 est non-significative."
label var acsal "Répartition de l'actionnariat. Ce taux correspond au pourcentage d'actions détenus par les salariés de l'entreprise."
label var acetat "Répartition de l'actionnariat. Ce taux correspond au pourcentage d'actions détenus par l'Etat."
label var acppf "Répartition de l'actionnariat. Ce taux correspond au pourcentage d'actions détenus par des personnes physiques françaises"
label var acpmf "Répartition de l'actionnariat. Ce taux correspond au pourcentage d'actions détenus par des personnes morales françaises."
label var acppe "Répartition de l'actionnariat. Ce taux correspond au pourcentage d'actions détenus par des personnes physiques étrangères"
label var acpme "Répartition de l'actionnariat. Ce taux correspond au pourcentage d'actions détenus par des personnes morales étrangères."
label var acpinc "Répartition de l'actionnariat. Ce taux correspond au pourcentage d'actions détenus par des tiers inconnus."
label var apedef "Code activité principale."
label var qcontr "% de contrôle global des groupes. Calculé à partir des LAR pour les entreprises TG, du noyau dur et du contour élargi.Il correspond au pourcentage de voix dans les assemblées générales. C'est la somme des taux de contrôle réel des différents groupes"
label var contour "Position de l'entreprise dans le groupe"
label var sirtg "SIREN de la tête de groupe"
label var txcontr "Taux de contrôle effectif de l'entreprise par sa TG"
label var rcontr "Rang de conttôle. Cette variable définit la position d'une filiale par rapport à la tête de groupe"
label var natact "Nature de la tête de groupe"
label var rstg "Nom ou raison sociale de la TG"
label var paystg "Code pays" 
label var efffrgr "effectif français du groupe"
}

order sirtg sirlifi year apedef contour rstg rs rcontr natact paystg efffrgr qcontr txcontr
sort sirtg year contour sirlifi

*cap save "$path\data\LIFI_1994_2007_ENT.dta", replace
cap save "$path/data/LIFI_1994_2007_ENT.dta", replace
