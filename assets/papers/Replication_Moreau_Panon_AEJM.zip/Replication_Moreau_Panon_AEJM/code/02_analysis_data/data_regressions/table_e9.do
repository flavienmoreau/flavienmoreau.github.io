*----------*
* Table E9 *
*----------*

preserve

*cap use "$path\data\Moreau_Panon_panel.dta", clear
cap use "$path/data/Moreau_Panon_panel.dta", clear

* Generate number of firms per cartel
rename Nbr_f n_firms_cartel

* Drop one firm cartels
drop if n_firms_cartel == 1

keep siren year Collude Decisions Big_cartel
tempfile moreau_panon
save "`moreau_panon'"
restore

*cap use "$path\data\Clean_Ficus", clear
use "$path/data/Clean_Ficus", clear
merge 1:1 siren year using "`moreau_panon'"
drop if _m == 2
drop _m

replace Collude = 0 if Collude == .
rename Collude collude

order siren year Decisions ape

keep siren year Decisions ape naf catotal cafranc labor_compensation vaht collude immocor autach materials

*-------------------------------*
* Merge with cost-share markups *
*-------------------------------*
*merge 1:1 siren year using "$path\data\markups_cost_share.dta"
merge 1:1 siren year using "$path/data/markups_cost_share.dta"
keep if _m == 3
drop _m 
drop mu_m mu_l mu_raval_l
rename mu_raval_m mu_raval_m_baseline

*merge 1:1 siren year using "$path\data\markups_cost_share_wins1.dta"
merge 1:1 siren year using "$path/data/markups_cost_share_wins1.dta"
keep if _m == 3
drop _m 
drop mu_m mu_l mu_raval_l
rename mu_raval_m mu_raval_m_wins1

*merge 1:1 siren year using "$path\data\markups_cost_share_wins3.dta"
merge 1:1 siren year using "$path/data/markups_cost_share_wins3.dta"
keep if _m == 3
drop _m 
drop mu_m mu_l mu_raval_l
rename mu_raval_m mu_raval_m_wins3

bysort ape year: egen market_share_france = total(cafranc)
replace market_share_france = cafranc/market_share_france

bysort ape year: egen market_share_world = total(catotal)
replace market_share_world = catotal/market_share_world

*----------------------------------------------*
* Slope of firm-level markups on market shares *
*----------------------------------------------*
gen inverse_markup_baseline = 1/mu_raval_m_baseline
gen inverse_markup_wins1 = 1/mu_raval_m_wins1
gen inverse_markup_wins3 = 1/mu_raval_m_wins3

gen labor_share = (labor_compensation/vaht)
replace labor_share = 1 if labor_share > 1
replace labor_share = . if labor_share < 0

bysort siren: egen max_collude_firm = max(collude)

bysort Decisions ape year: egen cartel_market_share = total(market_share_world)
replace cartel_market_share = 0 if Decisions == ""

bysort Decisions ape year: egen cartel_market_share_france = total(market_share_france)
replace cartel_market_share_france = 0 if Decisions == ""

*-----------------------------*
* Generate accounting markups *
*-----------------------------*

* Generate other variables
gen capital = immocor
gen rental_rate = 0.05 + 0.01675912
* UPDATE: R = 0.01675912 over 1994-2007 (mean)
gen Totcost = labor_compensation + materials + rental_rate*capital + autach
drop if Totcost == . | Totcost < 0

gen mu_account = catotal/Totcost

gen inverse_markup_account = 1/mu_account

*------------------------*
* Generate fixed effects *
*------------------------*
egen fe_firm = group(siren)
egen fe_cartel = group(Decisions)
egen fe_industry = group(ape)
egen fe_sector = group(naf)

*----------*
* Table E9 *
*----------*
reghdfe labor_share market_share_world cartel_market_share if collude == 1, absorb(year) vce(cluster fe_firm)
reghdfe inverse_markup_account market_share_world cartel_market_share if collude == 1, absorb(year) vce(cluster fe_firm)
reghdfe inverse_markup_wins3 market_share_world cartel_market_share if collude == 1, absorb(year) vce(cluster fe_firm)
reghdfe inverse_markup_wins1 market_share_world cartel_market_share if collude == 1, absorb(year) vce(cluster fe_firm)
reghdfe inverse_markup_baseline market_share_france cartel_market_share_france if collude == 1, absorb(year) vce(cluster fe_firm)
