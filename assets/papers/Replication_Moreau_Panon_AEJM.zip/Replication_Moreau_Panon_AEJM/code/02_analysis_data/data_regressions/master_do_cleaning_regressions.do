*============================================*
* Master Do-File: Generate Empirical Results *
*============================================*

* Set "path" to the replication package directory
* Use "/" for Mac/Linux, "\" for Windows
* Example: global path "/Users/name/Replication_Moreau_Panon_AEJM"

* This script runs all data preparation and generates Tables 1-3, E1, E3-E14, E19-E20 from the paper                           
* All variables and values used are reported in the Online Appendix 

cap global path "\Users\ludovicpanon1\Dropbox\Cartel Misallocation\Replication_Moreau_Panon_AEJM"
cap global path "/Users/ludovicpanon1/Dropbox/Cartel Misallocation/Replication_Moreau_Panon_AEJM"

*---------------*
* Load raw data *
*---------------*

* Should run this one to generate all results 
*qui cap do "$path\code\01_cleaning\import_data"
qui do "$path/code/01_cleaning/import_data"

*----------------*
* Clean raw data *
*----------------*
*qui cap do "$path\code\01_cleaning\clean_data"
qui do "$path/code/01_cleaning/clean_data"

*------------------*
* Estimate markups *
*------------------*
*qui cap do "$path\code\01_cleaning\estimate_markups"
qui do "$path/code/01_cleaning/estimate_markups"

*-------------------------------------*
* Moments (generate Figure 6 as well) *
*-------------------------------------*
*cap do "$path\code\02_analysis_data\data_regressions\moments"
do "$path/code/02_analysis_data/data_regressions/moments"

*----------------*
* Figures F1, F2 *
*----------------*
*cap do "$path\code\02_analysis_data\data_regressions\figure_f1"
do "$path/code/02_analysis_data/data_regressions/figure_f1"

*cap do "$path\code\02_analysis_data\data_regressions\figure_f2"
do "$path/code/02_analysis_data/data_regressions/figure_f2"

*------------------*
* Tables 1, E4, E5 *
*------------------*
* Need to install reghdfe 
*cap do "$path\code\02_analysis_data\data_regressions\tables_1_e4_e5"
do "$path/code/02_analysis_data/data_regressions/tables_1_e4_e5"

*--------------*
* Tables 2, E6 *
*--------------*
*cap do "$path\code\02_analysis_data\data_regressions\tables_2_e6"
do "$path/code/02_analysis_data/data_regressions/tables_2_e6"

*-------------------*
* Tables 3, E3, E14 *
*-------------------*
*cap do "$path\code\02_analysis_data\data_regressions\tables_3_e13_e14"
do "$path/code/02_analysis_data/data_regressions/tables_3_e13_e14"

*-----------*
* Tables E2 *
*-----------*
*cap do "$path\code\02_analysis_data\data_regressions\table_e2"
do "$path/code/02_analysis_data/data_regressions/table_e2"

*----------*
* Table E9 *
*----------*
*cap do "$path\code\02_analysis_data\data_regressions\table_e9"
do "$path/code/02_analysis_data/data_regressions/table_e9"

*----------------------*
* Tables E10, E11, E12 *
*----------------------*
*cap do "$path\code\02_analysis_data\data_regressions\tables_e10_e11_e12"
do "$path/code/02_analysis_data/data_regressions/tables_e10_e11_e12"

*-----------------*
* Tables E19, E20 *
*-----------------*
*cap do "$path\code\02_analysis_data\data_regressions\tables_e19_20"
do "$path/code/02_analysis_data/data_regressions/tables_e19_20"

*---------------*
* Tables E1, E3 *
*---------------*
*cap do "$path\code\02_analysis_data\data_regressions\tables_e1_e3"
do "$path/code/02_analysis_data/data_regressions/tables_e1_e3"

*---------------*
* Tables E7, E8 *
*---------------*
*cap do "$path\code\02_analysis_data\data_regressions\tables_e7_e8"
do "$path/code/02_analysis_data/data_regressions/tables_e7_e8"

*-----------------------------------------------------*
* Select industries with cartels (Table 9) for Matlab *
*-----------------------------------------------------*
*cap do "$path\code\02_analysis_data\data_regressions\select_industries_1995_2007"
do "$path/code/02_analysis_data/data_regressions/select_industries_1995_2007"
