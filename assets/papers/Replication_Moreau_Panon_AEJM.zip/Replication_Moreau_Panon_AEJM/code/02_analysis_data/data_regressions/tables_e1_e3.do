*------------------*
* Tables E1 and E3 *
*------------------*

preserve

*cap use "$path\data\Moreau_Panon_panel.dta", clear
cap use "$path/data/Moreau_Panon_panel.dta", clear

* Generate number of firms per cartel
rename Nbr_f n_firms_cartel

* Drop one firm cartels
drop if n_firms_cartel == 1

keep siren year Collude Decisions Big_cartel
tempfile moreau_panon
save "`moreau_panon'"
restore

*cap use "$path\data\Clean_Ficus", clear
use "$path/data/Clean_Ficus", clear
merge 1:1 siren year using "`moreau_panon'"
drop if _m == 2
drop _m

replace Collude = 0 if Collude == .
rename Collude collude

order siren year Decisions ape

keep siren year Decisions ape naf catotal cafranc labor_compensation vaht collude immocor materials effsalm tfp_labor_real

*-------------------------------*
* Merge with cost-share markups *
*-------------------------------*
*merge 1:1 siren year using "$path\data\markups_cost_share.dta"
merge 1:1 siren year using "$path/data/markups_cost_share.dta"

bysort ape year: egen market_share_world = total(catotal)
replace market_share_world = catotal/market_share_world

gen wage = labor_compensation/effsalm
gen log_wage = log(wage)
gen log_kl = log(immocor/effsalm)

replace catotal = catotal/1000
replace vaht = vaht/1000
replace materials = materials/1000

*----------*
* Table E1 *
*----------*
su market_share_world mu_raval_m catotal vaht tfp_labor_real effsalm log_wage log_kl materials, d

*----------*
* Table E3 *
*----------*
bysort siren: egen max_collude = max(collude)

su market_share_world mu_raval_m catotal vaht tfp_labor_real effsalm log_wage log_kl materials if max_collude == 1
su market_share_world mu_raval_m catotal vaht tfp_labor_real effsalm log_wage log_kl materials if max_collude == 0

unique siren  if max_collude == 1
unique siren  if max_collude == 0
