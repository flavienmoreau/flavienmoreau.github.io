*-------------------------*
* Tables E10, E11 and E12 *
*-------------------------*

preserve

*cap use "$path\data\Moreau_Panon_panel.dta", clear
cap use "$path/data/Moreau_Panon_panel.dta", clear

* Generate number of firms per cartel
rename Nbr_f n_firms_cartel

* Drop one firm cartels
drop if n_firms_cartel == 1

keep siren year Collude Decisions Big_cartel
tempfile moreau_panon
save "`moreau_panon'"
restore

*cap use "$path\data\Clean_Ficus", clear
use "$path/data/Clean_Ficus", clear
merge 1:1 siren year using "`moreau_panon'"
drop if _m == 2
drop _m

replace Collude = 0 if Collude == .
rename Collude collude

order siren year Decisions ape

keep siren year Decisions ape naf catotal cafranc labor_compensation vaht collude tfp_labor_real

*-------------------------------*
* Merge with cost-share markups *
*-------------------------------*
*merge 1:1 siren year using "$path\data\markups_cost_share.dta"
merge 1:1 siren year using "$path/data/markups_cost_share.dta"
keep if _m == 3
drop _m 

bysort ape year: egen market_share_france = total(cafranc)
replace market_share_france = cafranc/market_share_france

bysort ape year: egen market_share_world = total(catotal)
replace market_share_world = catotal/market_share_world

*----------------------------------------------*
* Slope of firm-level markups on market shares *
*----------------------------------------------*
gen inverse_markup = 1/mu_raval_m
gen inverse_markup_l = 1/mu_raval_l
gen inverse_markup_m2 = 1/mu_m
gen inverse_markup_l2 = 1/mu_l

gen labor_share = (labor_compensation/vaht)
replace labor_share = 1 if labor_share > 1
replace labor_share = . if labor_share < 0

bysort siren: egen max_collude_firm = max(collude)

bysort Decisions ape year: egen cartel_market_share = total(market_share_world)
replace cartel_market_share = 0 if Decisions == ""

*------------------------*
* Generate fixed effects *
*------------------------*
egen fe_firm = group(siren)
egen fe_cartel = group(Decisions)
egen fe_industry = group(ape)
egen fe_sector = group(naf)

clonevar ape_fixed = ape
bysort siren (year): replace ape_fixed = ape_fixed[1]

egen fe_industry_new = group(ape_fixed)

*-----------*
* Table E11 *
*-----------*

* Cartel FEs
qui reghdfe inverse_markup market_share_world cartel_market_share if collude == 1, absorb(year##fe_cartel) vce(cluster fe_firm)
gen sample_cartel = e(sample)

reghdfe inverse_markup market_share_world cartel_market_share if collude == 1 & sample_cartel == 1, absorb(year) vce(cluster fe_firm)
di _b[cartel_market_share]/(_b[market_share_world] + _b[cartel_market_share])

reghdfe inverse_markup market_share_world cartel_market_share if collude == 1 & sample_cartel == 1, absorb(fe_cartel) vce(cluster fe_firm)
di _b[cartel_market_share]/(_b[market_share_world] + _b[cartel_market_share])

reghdfe inverse_markup market_share_world cartel_market_share if collude == 1 & sample_cartel == 1, absorb(year fe_cartel) vce(cluster fe_firm)
di _b[cartel_market_share]/(_b[market_share_world] + _b[cartel_market_share])

reghdfe inverse_markup market_share_world cartel_market_share if collude == 1 & sample_cartel == 1, absorb(year##fe_cartel) vce(cluster fe_firm)
di _b[cartel_market_share]/(_b[market_share_world] + _b[cartel_market_share])

*-----------*
* Table E12 *
*-----------*
* Sector FEs
qui reghdfe inverse_markup market_share_world cartel_market_share if collude == 1, absorb(year##fe_sector) vce(cluster fe_firm)
gen sample_sec = e(sample)

reghdfe inverse_markup market_share_world cartel_market_share if collude == 1 & sample_sec == 1, absorb(year) vce(cluster fe_firm)
di _b[cartel_market_share]/(_b[market_share_world] + _b[cartel_market_share])

reghdfe inverse_markup market_share_world cartel_market_share if collude == 1 & sample_sec == 1, absorb(fe_sector) vce(cluster fe_firm)
di _b[cartel_market_share]/(_b[market_share_world] + _b[cartel_market_share])

reghdfe inverse_markup market_share_world cartel_market_share if collude == 1 & sample_sec == 1, absorb(year fe_sector) vce(cluster fe_firm)
di _b[cartel_market_share]/(_b[market_share_world] + _b[cartel_market_share])

reghdfe inverse_markup market_share_world cartel_market_share if collude == 1 & sample_sec == 1, absorb(year##fe_sector) vce(cluster fe_firm)
di _b[cartel_market_share]/(_b[market_share_world] + _b[cartel_market_share])

*------------------------------*
* IV when cartel is not active *
*------------------------------*
keep if max_collude_firm == 1
clonevar id_cartel = Decisions 
bysort siren (id_cartel): replace id_cartel = id_cartel[_N]
sort siren year 
order siren year Dec id_cartel
egen fe_cartel_final = group(id_cartel)

* Flag firms with well-defined pre-periods 
bysort siren (year): gen first_ = collude[_n==1] == 1
bysort siren: egen flag_first_ = max(first_)

* Generate IV own market share
bysort siren (year): gen iv_own_temp = market_share_world[1] if collude[_n==1] == 0
bysort siren: egen iv_own = max(iv_own_temp)

* Generate IV cartel market share
bysort id_cartel ape_fixed year: egen cartel_market_share_new = total(market_share_world)
* Keep track of industry-cartel pairs without colluders 
bysort id_cartel ape_fixed (year collude siren): gen iv_cartel_temp = cartel_market_share_new[1] if collude[_n==1] == 0
bysort id_cartel ape_fixed: egen iv_cartel = max(iv_cartel_temp)

order ape_fixed, after(id_cartel)

*-----------*
* Table E10 *
*-----------*
rename (market_share_world cartel_market_share_new) (own total)
ivreghdfe inverse_markup (own total = iv_own iv_cartel) if collude == 1, absorb() vce(cluster fe_firm) first
di _b[total]/(_b[own] + _b[total])

ivreghdfe inverse_markup (own total = iv_own iv_cartel) if collude == 1, absorb(year) vce(cluster fe_firm) first
di _b[total]/(_b[own] + _b[total])

*---------------------------------------------------------*
* Sanity check (delivers the same result as for Table 10) *
*---------------------------------------------------------*
preserve 

keep id_cartel ape_fixed year collude siren own
rename own market_share_world
sort id_cartel ape_fixed (year collude siren)

* Flag cartels with non-collusive behavior in first year and keep them 
bysort id_cartel ape_fixed (year collude siren): gen flag = collude[1] == 1
keep if flag == 0

* Flag first year 
bysort id_cartel ape_fixed (year): gen first_year = year[1]

* Keep first year 
keep if year == first_year
drop flag 

* Generate initial cartel market share 
bysort id_cartel ape_fixed: egen iv_cartel_init = total(market_share_world)
keep id_cartel ape_fixed iv_cartel_init
duplicates drop 

tempfile iv_cartel_init
save "`iv_cartel_init'"

restore 

merge m:1 id_cartel ape_fixed using "`iv_cartel_init'"
ivreghdfe inverse_markup (own total = iv_own iv_cartel_init) if collude == 1, absorb() vce(cluster fe_firm) first
di _b[total]/(_b[own] + _b[total])

ivreghdfe inverse_markup (own total = iv_own iv_cartel_init) if collude == 1, absorb(year) vce(cluster fe_firm) first
di _b[total]/(_b[own] + _b[total])
