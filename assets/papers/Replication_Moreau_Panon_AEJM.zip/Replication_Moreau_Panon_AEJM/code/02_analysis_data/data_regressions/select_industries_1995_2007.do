*------------------------------------------------------------------*
* Select industries for Matlab analysis (used to generate Table 9) *
*------------------------------------------------------------------*

preserve

*cap use "$path\data\Moreau_Panon_panel.dta", clear
cap use "$path/data/Moreau_Panon_panel.dta", clear

* Generate number of firms per cartel
rename Nbr_f n_firms_cartel

* Drop one firm cartels
drop if n_firms_cartel == 1

keep siren year Collude Decisions Big_cartel
tempfile moreau_panon
save "`moreau_panon'"
restore

*cap use "$path\data\Clean_Ficus", clear
use "$path/data/Clean_Ficus", clear
merge 1:1 siren year using "`moreau_panon'"
drop if _m == 2
drop _m

replace Collude = 0 if Collude == .
rename Collude collude

order siren year Decisions ape

keep siren year Decisions ape naf catotal cafranc labor_compensation vaht collude

bysort siren: egen max_collude_firm = max(collude)

* Save the full dataset before looping
tempfile full_data
save "`full_data'"

*-------------------------------*
* Loop over years 1995 and 2007 *            *
*-------------------------------*
foreach yr in 1995 2007 {
	
	use "`full_data'", clear
	keep if year == `yr'
	
	di _newline(2)
	di "=============================================="
	di "       ANALYSIS FOR YEAR `yr'"
	di "=============================================="
	di _newline(1)

	*--------------------------------*
	* Identify cartelized industries *
	*--------------------------------*
	bysort ape year: egen cartel_ind = max(collude)

	tempfile sample_ 
	save "`sample_'"

	*--------------------------------*
	* Compute industry market shares *
	*--------------------------------*
	bysort ape year: egen industry_sales = total(catotal)
	bysort year: egen total_sales = total(catotal)
	gen market_share_ind = (industry_sales/total_sales)

	* Keep variables at the 4-digit level
	keep naf ape year cartel_ind market_share_ind
	duplicates drop
	 
	unique naf
	unique naf if cartel_ind == 1

	bysort year: egen total_cartelized_ind = total(cartel_ind)
	bysort year: gen N_ind = _N
	gen share_cartel_ind = total_cartelized_ind/N_ind
	tabstat share_cartel_ind, by(year) format(%9.2f)

	gsort year -cartel_ind
	bysort year: egen cartel_sectoral_share = total(market_share_ind) if cartel_ind == 1
	tabstat cartel_sectoral_share, by(year) format(%9.2f)

	*-------------------------------------------------*
	* Keep track of the rank of cartelized industries *
	*-------------------------------------------------*
	gsort year -market_share_ind
	gen rank = _n

	tab rank if cartel_ind == 1
	
}
