*----------------------------------*
* Tables 2 and E6 on cartel premia *
*----------------------------------*
preserve

*cap use "$path\data\Moreau_Panon_panel.dta", clear
cap use "$path/data/Moreau_Panon_panel.dta", clear

* Generate number of firms per cartel
rename Nbr_f n_firms_cartel

* Drop one firm cartels
drop if n_firms_cartel == 1

keep siren year Collude Decisions Big_cartel
tempfile moreau_panon
save "`moreau_panon'"
restore

*cap use "$path\data\Clean_Ficus", clear
use "$path/data/Clean_Ficus", clear

merge 1:1 siren year using "`moreau_panon'"
drop if _m == 2
drop _m

replace Collude = 0 if Collude == .
rename Collude collude

order siren year Decisions ape

keep siren year Decisions ape naf catotal cafranc labor_compensation vaht collude effsalm tfp_labor_real

*-------------------------------*
* Merge with cost-share markups *
*-------------------------------*
*merge 1:1 siren year using "$path\data\markups_cost_share.dta"
merge 1:1 siren year using "$path/data/markups_cost_share.dta"
keep if _m == 3
drop _m 

*-----------------------------------------------------*
* Generate relevant set of fixed effects and controls *
*-----------------------------------------------------*
bysort siren: gen firstobs = _n == 1
gen long siren_fe = sum(firstobs) if !mi("siren")
drop firstobs

bysort naf: gen firstobs = _n == 1
gen long sector_fe = sum(firstobs) if !mi("naf")
drop firstobs

bysort ape: gen firstobs = _n == 1
gen long industry_fe = sum(firstobs) if !mi("ape")
drop firstobs

bysort Decisions: gen firstobs = _n == 1
gen long Decisions_fe = sum(firstobs) if !mi("Decisions")
drop firstobs

gen ln_sales = ln(catotal)
gen ln_va = ln(vaht)
gen ln_employment = ln(effsalm)
gen ln_mu = ln(mu_raval_m)

bysort ape year: egen total_sales_industry = total(catotal)
gen ms_firms = (catotal/total_sales_industry)
replace ms_firms = ms_firms*100

bysort siren: egen max_collude_firm = max(collude)

bysort ape year: egen total_sales_industry_france = total(cafranc)
gen ms_firms_france = (cafranc/total_sales_industry_france)
replace ms_firms_france = ms_firms_france*100

*---------*
* Table 2 *
*---------*
* Uncomment for variation across industries as in older WP version
*reghdfe ln_sales max_collude_firm if collude == 0, absorb(year) vce(cluster siren_fe)
*reghdfe ms_firms max_collude_firm if collude == 0, absorb(year) vce(cluster siren_fe)
*reghdfe ln_employment max_collude_firm if collude == 0, absorb(year) vce(cluster siren_fe)
*reghdfe tfp_labor_real max_collude_firm if collude == 0, absorb(year) vce(cluster siren_fe)

* Run on pre-collusion period (if collude == 0)
reghdfe ln_sales max_collude_firm if collude == 0, absorb(industry_fe#year) vce(cluster siren_fe)
reghdfe ms_firms max_collude_firm if collude == 0, absorb(industry_fe#year) vce(cluster siren_fe)
reghdfe ln_employment max_collude_firm if collude == 0, absorb(industry_fe#year) vce(cluster siren_fe)
reghdfe tfp_labor_real max_collude_firm if collude == 0, absorb(industry_fe#year) vce(cluster siren_fe)

*---------*
* Table E6 *
*---------*
qui reghdfe mu_raval_m max_collude_firm if collude == 0, absorb(industry_fe#year) vce(cluster siren_fe)
gen sample_ = e(sample)
reghdfe mu_raval_m max_collude_firm if collude == 0 & sample_ == 1, absorb(year) vce(cluster siren_fe)
reghdfe mu_raval_m max_collude_firm if collude == 0 & sample_ == 1, absorb(industry_fe#year) vce(cluster siren_fe)
