*----------------*
* Plot Figure F2 *
*----------------*

use "$path/data/figure_f2_dta.dta", clear

twoway bar count_firm_y year, barw(0.3) bcolor(blue) xtitle("Year") ytitle("# Firms", color(black)) xlabel(1994(1)2007, labsize(small) tlength(2)) ylabel(100(50)350, labsize(small) glcolor(gs15)) graphregion(color(white)) plotregion(color(white)) legend(off col(1) order(1) rowgap(1) symxsize(10) label(1 "# Decisions") size(small)) saving("$path/figure_f2", replace)
graph export "$path/figure_f2.pdf", replace
erase "$path/figure_f2.gph"
