*=============================================================================*
* Moments (Table 4): Aggregate Markups, Number of Firms, Concentration Ratios *
*=============================================================================*


*========================================================*
* PART 1: Number of Firms per Industry (uses full panel) *
*========================================================*

*cap use "$path\data\Clean_Ficus", clear
cap use "$path/data/Clean_Ficus", clear

bysort ape year: gen count_ = _N
keep ape year count_ 
duplicates drop 
tabstat count_, by(year) stats(mean median)

_pctile count_, p(50 60 65 70 75)
return list

*============================================*
* PART 2: Aggregate Markup (uses full panel) *
*============================================*

preserve

*cap use "$path\data\Moreau_Panon_panel.dta", clear
cap use "$path/data/Moreau_Panon_panel.dta", clear

* Generate number of firms per cartel
rename Nbr_f n_firms_cartel

* Drop one firm cartels
drop if n_firms_cartel == 1

keep siren year Collude Decisions Big_cartel
tempfile moreau_panon
save "`moreau_panon'"
restore

*cap use "$path\data\Clean_Ficus.dta", clear
cap use "$path/data/Clean_Ficus.dta", clear

merge 1:1 siren year using "`moreau_panon'"
drop if _m == 2
drop _m

replace Collude = 0 if Collude == .
rename Collude collude

* Merge with cost-share markups *
*cap merge 1:1 siren year using "$path\data\markups_cost_share.dta"
cap merge 1:1 siren year using "$path/data/markups_cost_share.dta"

tab _m 

keep if _m == 3
drop _m 

gen inverse_markup = 1/mu_raval_m
gen inverse_markup_l = 1/mu_raval_l
gen inverse_markup_m2 = 1/mu_m
gen inverse_markup_l2 = 1/mu_l

gen labor_share = (labor_compensation/vaht)
replace labor_share = 1 if labor_share > 1
replace labor_share = . if labor_share < 0

keep year siren catotal cafranc mu_* labor_share  ape naf  inverse_markup* collude 
*corr labor_share inverse_markup*
*corr labor_share inverse_markup* if collude == 1

*-------------------*
* Aggregate markups *
*-------------------*

qui{
bysort year: egen m_share_econ = total(catotal)
replace m_share_econ = catotal/m_share_econ

gen prod_harmonic_m = m_share_econ*(1/mu_raval_m)
bysort year: egen mu_harm_m = total(prod_harmonic_m)
replace mu_harm_m = 1/mu_harm_m

}
preserve 

keep mu_harm_m year
duplicates drop 
tabstat mu_harm*, by(year) format(%9.3f)

* Plot aggregate markup and save
twoway line mu_harm_m year, title("Aggregate Markup in France") ytitle("Aggregate markup") xtitle("")
*cap graph export "$path\figure_f6.png", replace
cap graph export "$path/figure_f6.png", replace

restore 

drop m_share_econ prod_harmonic* mu_harm*

*==========================================================================*
* PART 3: Concentration Ratios Across Industries (uses 2007 cross-section) *
*==========================================================================*

*cap use "$path\data\Clean_Ficus", clear
cap use "$path/data/Clean_Ficus", clear

keep if year == 2007

bysort ape year: egen industry_sales = total(catotal)
bysort year: egen total_sales = total(catotal)

gen market_share_ind = (industry_sales/total_sales)*100

keep ape market_share_ind year
duplicates drop 
su market_share_ind, d

*CR4
gsort year -market_share_ind
by year: gen top4 = _n <= 4
bysort year: egen cr4 = total(market_share_ind) if top4 == 1

*CR20
gsort year -market_share_ind
by year: gen top20 = _n <= 20
bysort year: egen cr20 = total(market_share_ind) if top20 == 1

keep cr* year
duplicates drop 
 
bysort year (cr4): replace cr4 = cr4[1]
bysort year (cr20): replace cr20 = cr20[1]

duplicates drop
tabstat cr*, by(year) stats(mean median) format(%9.2f)

*==========================================================================*
* PART 4: Concentration Ratios Within Industries (uses 2007 cross-section) *
*==========================================================================*

*cap use "$path\data\Clean_Ficus", clear
cap use "$path/data/Clean_Ficus", clear

keep if year == 2007

* Generate weights 
bysort ape: egen weight_sales = total(catotal)
egen weight_sales_total = total(catotal)
replace weight_sales = weight_sales/weight_sales_total

* Compute total number of firms in each 4-digit industry
bysort ape: gen total_f = _N

* Generate 4-digit market shares
bysort ape: egen industry_sales = total(catotal)
gen m_share_4digit = catotal/industry_sales

gsort ape -m_share_4digit
bysort ape: gen top4 = _n <= 4
bysort ape: egen cr4 = total(m_share_4digit) if top4 == 1

gsort ape -m_share_4digit
bysort ape: gen top5 = _n <= 5
bysort ape: egen cr5 = total(m_share_4digit) if top5 == 1

gsort ape -m_share_4digit
bysort ape: gen top10 = _n <= 10
bysort ape: egen cr10 = total(m_share_4digit) if top10 == 1

gsort ape -m_share_4digit
bysort ape: gen top20 = _n <= 20
bysort ape: egen cr20 = total(m_share_4digit) if top20 == 1

* Generate weighted averages 
keep ape weight_sales cr*
duplicates drop 

bysort ape (cr4): replace cr4 = cr4[1]
bysort ape (cr5): replace cr5 = cr5[1]
bysort ape (cr10): replace cr10 = cr10[1]
bysort ape (cr20): replace cr20 = cr20[1]

duplicates drop 

gen cr4_w = cr4*weight_sales
gen cr5_w = cr5*weight_sales
gen cr10_w = cr10*weight_sales
gen cr20_w = cr20*weight_sales

egen cr4_w_ = total(cr4_w)
egen cr5_w_ = total(cr5_w)
egen cr10_w_ = total(cr10_w)
egen cr20_w_ = total(cr20_w)

keep cr4_w_ cr5_w_ cr10_w_ cr20_w_
tabstat cr*, format(%9.2f)
duplicates drop 

*============================*
* PART 5: Untargeted moments *
*============================*
* This generates the standard deviation of log sales and log TFPL
* The other moments are generated in tables_1_e4_e5 and tables_2_e6

preserve

*cap use "$path\data\Moreau_Panon_panel.dta", clear
cap use "$path/data/Moreau_Panon_panel.dta", clear

* Generate number of firms per cartel
rename Nbr_f n_firms_cartel

* Drop one firm cartels
drop if n_firms_cartel == 1

keep siren year Collude Decisions Big_cartel

tempfile moreau_panon
save "`moreau_panon'"

restore

*cap use "$path\data\Clean_Ficus", clear
cap use "$path/data/Clean_Ficus", clear

merge 1:1 siren year using "`moreau_panon'"
drop if _m == 2
drop _m

replace Collude = 0 if Collude == .
rename Collude collude

order siren year Decisions ape

keep siren year Decisions ape naf catotal cafranc labor_compensation vaht collude effsalm tfp_labor_real

* Merge with cost-share markups
*merge 1:1 siren year using "$path\data\markups_cost_share.dta"
merge 1:1 siren year using "$path/data/markups_cost_share.dta"
keep if _m == 3
drop _m 

gen log_sales = ln(catotal)
gen log_l = ln(effsalm)

su log_sales log_l
