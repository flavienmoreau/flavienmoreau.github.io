*----------*
* Table E2 *
*----------*

use "$path/data/table_e2.dta", clear 

preserve
keep Decisions count_firms_cartel
duplicates drop
su count_firms_cartel, d
restore

su price_fixing market_allocation prod_quotas information Repeat_Offender Bid_Rigging Dominant_leader Abuse_dominance Guaranteed_buy_backs Exclusive_dealing_contracts, d
