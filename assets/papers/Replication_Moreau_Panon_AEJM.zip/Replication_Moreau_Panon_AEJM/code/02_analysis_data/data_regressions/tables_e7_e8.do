*-----------------------------------------------------*
* Tables E7 and E8: Sales and Productivity Dispersion *
*-----------------------------------------------------*
* Set case_study = 1 for Table E8 (APE 252E only)
* Set case_study = 0 for Table E7 (all industries)
*--------------------------------------------------*

* USER: Set this parameter
local case_study = 0  // 0 = Table E7 (all), 1 = Table E8 (case study APE 252E)

if `case_study' == 1 {
    di _n "Running Table E8: Case Study (APE 252E - Revêtement sol)"
}
else {
    di _n "Running Table E7: All Industries"
}

preserve

*cap use "$path\data\Moreau_Panon_panel.dta", clear
use "$path/data/Moreau_Panon_panel.dta", clear

* Generate number of firms per cartel
rename Nbr_f n_firms_cartel

keep siren year Collude Decisions Big_cartel n_firms_cartel
tempfile moreau_panon
save "`moreau_panon'"
restore

*use "$path\data\Clean_Ficus", clear
use "$path/data/Clean_Ficus", clear
merge 1:1 siren year using "`moreau_panon'"
drop if _m == 2
drop _m

replace Collude = 0 if Collude == .
rename Collude collude

* Keep one cross-section
keep if year == 2007

* Drop one firm cartels
drop if n_firms_cartel == 1

* Case study: restrict to floor covering cartel (APE 252E)
if `case_study' == 1 {
    keep if ape == "252E"
}

* Generate cartel FE for loop
egen group_cartel = group(Decisions)

*----------------------------------------------*
* Compute dispersion for each 4-digit industry *
*----------------------------------------------*

gen log_sales = ln(catotal)

* Loop over log sales and log labor productivity to recover both panels  

foreach x of varlist tfp_l log_sales {
    
    * Follow Syverson (2004)
    preserve
    qui {
        keep if collude == 0
        bysort ape: egen median_`x'_no_cartel = median(`x')
        bysort ape: egen p5_`x'_no_cartel = pctile(`x'), p(5)
        bysort ape: egen p10_`x'_no_cartel = pctile(`x'), p(10)
        bysort ape: egen p25_`x'_no_cartel = pctile(`x'), p(25)
        bysort ape: egen p75_`x'_no_cartel = pctile(`x'), p(75)
        bysort ape: egen p90_`x'_no_cartel = pctile(`x'), p(90)
        bysort ape: egen p95_`x'_no_cartel = pctile(`x'), p(95)
        
        gen iq_range_no_cartel = p75_`x'_no_cartel - p25_`x'_no_cartel
        gen range_90_10_no_cartel = p90_`x'_no_cartel - p10_`x'_no_cartel
        gen range_95_5_no_cartel = p95_`x'_no_cartel - p5_`x'_no_cartel
        
        keep ape median_`x'_no_cartel iq_range_no_cartel range_90_10_no_cartel range_95_5_no_cartel
        duplicates drop
    }
    
    di _n "=== Non-cartel dispersion: `x' ==="
    su median_`x'_no_cartel, d
    su iq_range_no_cartel, d
    su range_90_10_no_cartel, d
    su range_95_5_no_cartel, d
    
    restore
}

*---------------------------------------*
* Compute dispersion within each cartel *
*---------------------------------------*

* Compute ratios for each cartel
foreach x of varlist tfp_l log_sales {
    
    qui {
        keep if collude == 1
        
        bysort Decision: egen median_`x'_cartel = median(`x')
        bysort Decision: egen p5_`x'_cartel = pctile(`x'), p(5)
        bysort Decision: egen p10_`x'_cartel = pctile(`x'), p(10)
        bysort Decision: egen p25_`x'_cartel = pctile(`x'), p(25)
        bysort Decision: egen p75_`x'_cartel = pctile(`x'), p(75)
        bysort Decision: egen p90_`x'_cartel = pctile(`x'), p(90)
        bysort Decision: egen p95_`x'_cartel = pctile(`x'), p(95)
        
        gen iq_range_c_`x' = p75_`x'_cartel - p25_`x'_cartel
        gen range_90_10_c_`x' = p90_`x'_cartel - p10_`x'_cartel
        gen range_95_5_c_`x' = p95_`x'_cartel - p5_`x'_cartel
    }
    
    preserve
    qui keep Decisions median_`x'_cartel iq_range_c_`x' range_90_10_c_`x' range_95_5_c_`x'
    qui duplicates drop
    
    di _n "=== Cartel dispersion: `x' ==="
    su median_`x'_cartel, d
    su iq_range_c_`x', d
    su range_90_10_c_`x', d
    su range_95_5_c_`x', d
    restore
}
