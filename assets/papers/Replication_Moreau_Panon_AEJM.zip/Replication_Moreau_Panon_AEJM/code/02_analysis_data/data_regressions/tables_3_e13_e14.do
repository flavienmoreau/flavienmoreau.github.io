*-----------------------*
* Tables 3, E13 and E14 *
*-----------------------*
preserve

*cap use "$path\data\Moreau_Panon_panel.dta", clear
cap use "$path/data/Moreau_Panon_panel.dta", clear

* Generate number of firms per cartel
rename Nbr_f n_firms_cartel

* Drop one firm cartels
drop if n_firms_cartel == 1

keep siren year Collude Decisions Big_cartel
tempfile moreau_panon
save "`moreau_panon'"
restore

*cap use "$path\data\Clean_Ficus", clear
use "$path/data/Clean_Ficus", clear
merge 1:1 siren year using "`moreau_panon'"
drop if _m == 2
drop _m

replace Collude = 0 if Collude == .
rename Collude collude

order siren year Decisions ape

keep siren year Decisions ape naf catotal cafranc labor_compensation vaht collude

*-------------------------------*
* Merge with cost-share markups *
*-------------------------------*
*merge 1:1 siren year using "$path\data\markups_cost_share.dta"
merge 1:1 siren year using "$path/data/markups_cost_share.dta"
keep if _m == 3
drop _m 

bysort ape year: egen market_share_world = total(catotal)
replace market_share_world = catotal/market_share_world

*----------------------------------------------*
* Slope of firm-level markups on market shares *
*----------------------------------------------*
gen inverse_markup = 1/mu_raval_m
gen inverse_markup_l = 1/mu_raval_l
gen inverse_markup_m2 = 1/mu_m
gen inverse_markup_l2 = 1/mu_l

gen labor_share = (labor_compensation/vaht)
replace labor_share = 1 if labor_share > 1
replace labor_share = . if labor_share < 0

bysort siren: egen max_collude_firm = max(collude)

bysort Decisions ape year: egen cartel_market_share = total(market_share_world)
replace cartel_market_share = 0 if Decisions == ""

*------------------------*
* Generate fixed effects *
*------------------------*
egen fe_firm = group(siren)
egen fe_cartel = group(Decisions)
egen fe_industry = group(ape)
egen fe_sector = group(naf)

*---------*
* Table 3 *
*---------*
* Sample of colluders 

reghdfe inverse_markup market_share_world if collude == 1, absorb() vce(cluster fe_firm)
reghdfe inverse_markup cartel_market_share if collude == 1, absorb() vce(cluster fe_firm)
reghdfe inverse_markup market_share_world cartel_market_share if collude == 1, absorb() vce(cluster fe_firm)
reghdfe inverse_markup market_share_world cartel_market_share if collude == 1, absorb(year) vce(cluster fe_firm)
di _b[cartel_market_share]/(_b[market_share_world] + _b[cartel_market_share])
di (_b[cartel_market_share] + _b[market_share_world])

*-----------*
* Table E13 *
*-----------*

* Sample of non-colluders
reghdfe inverse_markup market_share_world if max_collude == 0, vce(cluster fe_firm)
reghdfe inverse_markup market_share_world if max_collude == 0, absorb(year) vce(cluster fe_firm)

*---------------------------------------------------------------------------------------------------------*
* Validation check: cartel market share should not be sign. for the period over which they do not collude *
*---------------------------------------------------------------------------------------------------------*
clonevar new_dec = Decisions 
bysort siren (new_dec): replace new_dec = new_dec[_N]
sort siren year 
order siren year Dec new_dec

bysort new_dec ape year: egen cartel_market_share_new = total(market_share_world)
replace cartel_market_share_new = . if new_dec == ""

*-----------*
* Table E14 *
*-----------*
reghdfe inverse_markup market_share_world cartel_market_share_new if max_collude == 1 & collude == 0, absorb() vce(cluster fe_firm)
reghdfe inverse_markup market_share_world cartel_market_share_new if max_collude == 1 & collude == 0, absorb(year) vce(cluster fe_firm)
