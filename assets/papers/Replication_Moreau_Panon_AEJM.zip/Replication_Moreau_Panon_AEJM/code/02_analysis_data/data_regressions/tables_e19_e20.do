*--------------------*
* Tables E19 and E20 *
*--------------------*
clear
cls

*cap use  "$path\data\LIFI_1994_2007_ENT.dta", clear 
cap use  "$path/data/LIFI_1994_2007_ENT.dta", clear 

keep sirtg sirlifi year contour paysorig
rename sirlifi siren 

tempfile lifi
save "`lifi'"

preserve

*cap use "$path\data\Moreau_Panon_panel.dta", clear
cap use "$path/data/Moreau_Panon_panel.dta", clear

* Generate number of firms per cartel
rename Nbr_f n_firms_cartel

* Drop one firm cartels
drop if n_firms_cartel == 1

keep siren year Collude Decisions Big_cartel
tempfile moreau_panon
save "`moreau_panon'"
restore

*cap use "$path\data\Clean_Ficus", clear
use "$path/data/Clean_Ficus", clear
merge 1:1 siren year using "`moreau_panon'"
drop if _m == 2
drop _m

replace Collude = 0 if Collude == .
rename Collude collude

order siren year Decisions ape

keep siren year Decisions ape naf catotal cafranc labor_compensation vaht collude

*-------------------------------*
* Merge with cost-share markups *
*-------------------------------*

* If required, install mmerge 
* ssc install mmerge 

*mmerge siren year using "$path\data\markups_cost_share.dta"
mmerge siren year using "$path/data/markups_cost_share.dta"

keep if _m == 3
drop _m 

bysort ape year: egen market_share_world = total(catotal)
replace market_share_world = catotal/market_share_world

*-----------------*
* Merge with lifi *
*-----------------*
mmerge siren year using "`lifi'"
drop if _m == 2
drop _m 
order sirtg 

bysort sirtg ape year: egen group_ms = total(market_share_world)
replace group_ms = 0 if sirtg == ""

*--------------------------------------*
* Generate dependent variables and FEs *
*--------------------------------------*
gen inverse_markup = 1/mu_raval_m
gen inverse_markup_l = 1/mu_raval_l
gen inverse_markup_m2 = 1/mu_m
gen inverse_markup_l2 = 1/mu_l

gen labor_share = (labor_compensation/vaht)
replace labor_share = 1 if labor_share > 1
replace labor_share = . if labor_share < 0

egen fe_firm = group(siren)
egen fe_group = group(sirtg)
egen fe_group_industry = group(sirtg ape)
egen fe_industry = group(ape)
egen fe_sector = group(naf)
bysort siren: egen max_collude_firm = max(collude)

*-----------*
* Table E19 *
*-----------*
qui reghdfe inverse_markup market_share_world group_ms if sirtg != "", absorb(fe_sector#year fe_firm) vce(cluster fe_firm)
gen sample_common = e(sample)

reghdfe inverse_markup market_share_world if sirtg != "" & sample_common == 1, absorb() vce(cluster fe_firm)
reghdfe inverse_markup group_ms if sirtg != "" & sample_common == 1, absorb() vce(cluster fe_firm)
reghdfe inverse_markup market_share_world group_ms if sirtg != "" & sample_common == 1, absorb() vce(cluster fe_firm)
reghdfe inverse_markup market_share_world group_ms if sirtg != "" & sample_common == 1, absorb(year) vce(cluster fe_firm)
reghdfe inverse_markup market_share_world group_ms if sirtg != "" & sample_common == 1, absorb(fe_sector#year) vce(cluster fe_firm)
reghdfe inverse_markup market_share_world group_ms if sirtg != "", absorb(fe_sector#year fe_firm) vce(cluster fe_firm)

*-----------*
* Table E20 *
*-----------*
* Excluding cartels
qui reghdfe inverse_markup market_share_world group_ms if sirtg != "" & max_collude_firm == 0, absorb(fe_sector#year fe_firm) vce(cluster fe_firm)
gen sample_group_no_cartel = e(sample)

reghdfe inverse_markup market_share_world if sirtg != "" & max_collude_firm == 0 & sample_group_no_cartel, absorb() vce(cluster fe_firm)
reghdfe inverse_markup group_ms if sirtg != "" & max_collude_firm == 0 & sample_group_no_cartel, absorb() vce(cluster fe_firm)
reghdfe inverse_markup market_share_world group_ms if sirtg != "" & max_collude_firm == 0 & sample_group_no_cartel, absorb() vce(cluster fe_firm)
reghdfe inverse_markup market_share_world group_ms if sirtg != "" & max_collude_firm == 0 & sample_group_no_cartel, absorb(year) vce(cluster fe_firm)
reghdfe inverse_markup market_share_world group_ms if sirtg != "" & max_collude_firm == 0 & sample_group_no_cartel, absorb(fe_sector#year) vce(cluster fe_firm)
reghdfe inverse_markup market_share_world group_ms if sirtg != "" & max_collude_firm == 0, absorb(fe_sector#year fe_firm) vce(cluster fe_firm)
