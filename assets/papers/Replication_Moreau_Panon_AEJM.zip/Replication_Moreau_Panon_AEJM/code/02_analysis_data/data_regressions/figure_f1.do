*----------------*
* Plot Figure F1 *
*----------------*

use "$path/data/figure_f1_dta.dta", clear

twoway bar count_decisions Year, barw(0.3) bcolor(blue) ///
	   xtitle("Year") ytitle("# Decisions", color(black)) ///
	   xlabel(1995(2)2018, labsize(small) tlength(2)) ///
	   ylabel(1(2)28, labsize(small) glcolor(gs15)) ///
	   graphregion(color(white)) plotregion(color(white)) ///
	   legend(off col(1) order(1) rowgap(1) symxsize(10) ///
	   label(1 "# Decisions") size(small)) ///
	   saving("$path/figure_f1", replace)
graph export "$path/figure_f1.pdf", replace
erase "$path/figure_f1.gph"
