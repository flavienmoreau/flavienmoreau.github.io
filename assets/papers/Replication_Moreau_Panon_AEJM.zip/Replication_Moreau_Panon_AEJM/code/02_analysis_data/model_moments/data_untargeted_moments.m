fprintf('...calculating data moments... \n');
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #1: Cartelized industry slope %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
slope_industry = 0.2;
Block1_data_un = slope_industry;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #2: Average cartel premium (sales) %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cartel_premium_sales_data = 2.44;
Block2_data_un = cartel_premium_sales_data;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #3: Average cartel premium (employment) %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cartel_premium_employment_data = 2.57;
Block3_data_un = cartel_premium_employment_data;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #4: Average cartel premium (labor productivity) %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cartel_premium_tfpl_data = 0.24;
Block4_data_un = cartel_premium_tfpl_data;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #5: Average cartel premium (market share) %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cartel_premium_market_share_data = 2.05;
Block5_data_un = cartel_premium_market_share_data;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #6: Standard deviation of log sales %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
std_log_sales_data = 1.37;
Block6_data_un = std_log_sales_data;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #7: Standard deviation of log employment %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
std_log_employment_data = 1.10;
Block7_data_un = std_log_employment_data;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #8: Average overcharge (in %) %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
average_overcharge_data = 10;
Block8_data_un = average_overcharge_data;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% All Untargeted Data Moments %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
all_data_untargeted_moments = [Block1_data_un; Block2_data_un; Block3_data_un; Block4_data_un; ...
                                Block5_data_un; Block6_data_un; Block7_data_un; Block8_data_un];
 
%  save data moments for future use
savefile = 'data_untargeted_moments.mat';
save(savefile, 'all_data_untargeted_moments', 'Block1_data_un', 'Block2_data_un', 'Block3_data_un', ...
     'Block4_data_un', 'Block5_data_un', 'Block6_data_un', 'Block7_data_un', 'Block8_data_un');

fprintf('...untargeted data moments saved... \n');