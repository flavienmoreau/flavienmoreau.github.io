
fprintf('...calculating data moments... \n');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #1: Aggregate Markup %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Aggregate markup 
markup_aggregate = 1.08;
Block1_data = [markup_aggregate];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #2: Median number of cartel producers %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
median_members_data = 4;
Block2_data = median_members_data;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #3: Median number of cartel producers %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
median_members_firms_data = 178;
Block3_data = median_members_firms_data;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #4: Distribution of relative sales %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cr4 = 0.38;
cr20 = 0.57;

Block4_data = [cr4,cr20];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #5: Distribution of relative sales %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cr4_bt = 0.13;
cr20_bt = 0.31;

Block5_data = [cr4_bt,cr20_bt];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block #6: Target slope parameter %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Block6_data = -0.24;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% All Data Moments (pool all data blocks %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
all_data_moments = [Block1_data Block6_data Block4_data Block5_data Block3_data Block2_data]';

%  save data moments for future use (comment out as required)

savefile = 'data_moments_1995.mat';
save(savefile,'all_data_moments', 'Block1_data', 'Block2_data', 'Block3_data', 'Block4_data', 'Block5_data', 'Block6_data');
       